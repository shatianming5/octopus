from __future__ import annotations

import json
from copy import deepcopy
from dataclasses import dataclass, field
from typing import Any, TypeVar

JSONValue = None | bool | int | float | str | list["JSONValue"] | dict[str, "JSONValue"]
T = TypeVar("T")


class CommitValidationError(ValueError):
    pass


class CommitStateError(RuntimeError):
    pass


@dataclass(frozen=True, slots=True)
class Evidence:
    source: str
    locator: str | None = None
    excerpt: str | None = None


@dataclass(frozen=True, slots=True)
class Fact:
    id: str
    predicate: str
    value: JSONValue
    evidence: tuple[Evidence, ...]


@dataclass(frozen=True, slots=True)
class Commit:
    commit_id: str
    branch_id: str
    summary: str
    facts: tuple[Fact, ...]
    artifacts: tuple[str, ...]
    actions_taken: tuple[str, ...]
    unresolved: tuple[str, ...]
    success: bool

    @classmethod
    def from_json(cls, payload: str) -> "Commit":
        try:
            data = json.loads(payload)
        except json.JSONDecodeError as exc:
            raise CommitValidationError(f"invalid commit JSON: {exc.msg}") from exc
        return cls.from_dict(data)

    @classmethod
    def from_dict(cls, data: Any) -> "Commit":
        root = _expect_object(data, "commit")
        _expect_keys(
            root,
            {
                "commit_id",
                "branch_id",
                "summary",
                "facts",
                "artifacts",
                "actions_taken",
                "unresolved",
                "success",
            },
            "commit",
        )
        facts_value = root["facts"]
        if not isinstance(facts_value, list):
            raise CommitValidationError("commit.facts must be an array")
        facts = tuple(
            _parse_fact(item, index) for index, item in enumerate(facts_value)
        )
        commit = cls(
            commit_id=_expect_nonempty_string(root["commit_id"], "commit.commit_id"),
            branch_id=_expect_nonempty_string(root["branch_id"], "commit.branch_id"),
            summary=_expect_string(root["summary"], "commit.summary"),
            facts=facts,
            artifacts=_parse_string_list(root["artifacts"], "commit.artifacts"),
            actions_taken=_parse_string_list(
                root["actions_taken"], "commit.actions_taken"
            ),
            unresolved=_parse_string_list(root["unresolved"], "commit.unresolved"),
            success=_expect_bool(root["success"], "commit.success"),
        )
        return commit

    def to_dict(self) -> dict[str, JSONValue]:
        return {
            "commit_id": self.commit_id,
            "branch_id": self.branch_id,
            "summary": self.summary,
            "facts": [
                {
                    "id": fact.id,
                    "predicate": fact.predicate,
                    "value": fact.value,
                    "evidence": [
                        {
                            "source": evidence.source,
                            "locator": evidence.locator,
                            "excerpt": evidence.excerpt,
                        }
                        for evidence in fact.evidence
                    ],
                }
                for fact in self.facts
            ],
            "artifacts": list(self.artifacts),
            "actions_taken": list(self.actions_taken),
            "unresolved": list(self.unresolved),
            "success": self.success,
        }


@dataclass(frozen=True, slots=True)
class WorldFact:
    predicate: str
    value: JSONValue
    fact_ids: tuple[str, ...]
    evidence: tuple[Evidence, ...]


@dataclass(slots=True)
class WorldState:
    facts: dict[str, list[WorldFact]] = field(default_factory=dict)
    artifacts: list[str] = field(default_factory=list)
    actions_taken: list[str] = field(default_factory=list)
    unresolved: list[str] = field(default_factory=list)
    applied_commit_ids: set[str] = field(default_factory=set)
    committed_branch_ids: set[str] = field(default_factory=set)
    failed_branch_ids: set[str] = field(default_factory=set)

    def to_dict(self) -> dict[str, JSONValue]:
        return {
            "facts": {
                predicate: [
                    {
                        "value": variant.value,
                        "fact_ids": list(variant.fact_ids),
                        "evidence": [
                            {
                                "source": item.source,
                                "locator": item.locator,
                                "excerpt": item.excerpt,
                            }
                            for item in variant.evidence
                        ],
                    }
                    for variant in variants
                ]
                for predicate, variants in sorted(self.facts.items())
            },
            "artifacts": self.artifacts,
            "actions_taken": self.actions_taken,
            "unresolved": self.unresolved,
            "failed_branch_ids": sorted(self.failed_branch_ids),
        }


class StateReducer:
    def __init__(self, state: WorldState | None = None) -> None:
        self.state = state or WorldState()

    def apply(self, commit: Commit, branch_status: str = "COMMIT_READY") -> WorldState:
        if branch_status != "COMMIT_READY":
            raise CommitStateError(
                f"branch {commit.branch_id!r} cannot commit from {branch_status}"
            )
        if commit.commit_id in self.state.applied_commit_ids:
            raise CommitStateError(f"commit {commit.commit_id!r} was already applied")
        if commit.branch_id in self.state.committed_branch_ids:
            raise CommitStateError(f"branch {commit.branch_id!r} already committed")

        for fact in commit.facts:
            self._merge_fact(fact)
        _append_unique(self.state.artifacts, commit.artifacts)
        _append_unique(self.state.actions_taken, commit.actions_taken)
        _append_unique(self.state.unresolved, commit.unresolved)
        self.state.applied_commit_ids.add(commit.commit_id)
        self.state.committed_branch_ids.add(commit.branch_id)
        if not commit.success:
            self.state.failed_branch_ids.add(commit.branch_id)
        return self.state

    def serialize_delta(self, commits: list[Commit] | tuple[Commit, ...]) -> str:
        ordered = sorted(commits, key=lambda commit: (commit.branch_id, commit.commit_id))
        payload = {
            "commits": [commit.to_dict() for commit in ordered],
            "world_state": self.state.to_dict(),
        }
        return json.dumps(payload, ensure_ascii=True, sort_keys=True, separators=(",", ":"))

    def _merge_fact(self, fact: Fact) -> None:
        variants = self.state.facts.setdefault(fact.predicate, [])
        value_key = _canonical_json(fact.value)
        for index, existing in enumerate(variants):
            if _canonical_json(existing.value) != value_key:
                continue
            variants[index] = WorldFact(
                predicate=fact.predicate,
                value=existing.value,
                fact_ids=_merged_tuple(existing.fact_ids, (fact.id,)),
                evidence=_merged_tuple(existing.evidence, fact.evidence),
            )
            return

        if variants:
            conflict = f"conflicting values for {fact.predicate}"
            if conflict not in self.state.unresolved:
                self.state.unresolved.append(conflict)
        variants.append(
            WorldFact(
                predicate=fact.predicate,
                value=fact.value,
                fact_ids=(fact.id,),
                evidence=fact.evidence,
            )
        )


COMMIT_JSON_SCHEMA: dict[str, JSONValue] = {
    "type": "object",
    "additionalProperties": False,
    "required": [
        "commit_id",
        "branch_id",
        "summary",
        "facts",
        "artifacts",
        "actions_taken",
        "unresolved",
        "success",
    ],
    "properties": {
        "commit_id": {"type": "string", "minLength": 1},
        "branch_id": {"type": "string", "minLength": 1},
        "summary": {"type": "string"},
        "facts": {
            "type": "array",
            "items": {
                "type": "object",
                "additionalProperties": False,
                "required": ["id", "predicate", "value", "evidence"],
                "properties": {
                    "id": {"type": "string", "minLength": 1},
                    "predicate": {"type": "string", "minLength": 1},
                    "value": {},
                    "evidence": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "additionalProperties": False,
                            "required": ["source", "locator", "excerpt"],
                            "properties": {
                                "source": {"type": "string", "minLength": 1},
                                "locator": {"type": ["string", "null"]},
                                "excerpt": {"type": ["string", "null"]},
                            },
                        },
                    },
                },
            },
        },
        "artifacts": {"type": "array", "items": {"type": "string"}},
        "actions_taken": {"type": "array", "items": {"type": "string"}},
        "unresolved": {"type": "array", "items": {"type": "string"}},
        "success": {"type": "boolean"},
    },
}


def commit_schema(branch_id: str) -> dict:
    """Common identity-bound schema for native and public runtime callers."""
    schema = deepcopy(COMMIT_JSON_SCHEMA)
    schema["properties"]["branch_id"] = {"const": branch_id}
    schema["properties"]["commit_id"] = {"const": f"commit-{branch_id}"}
    return schema


def semantic_delta_text(delta: str) -> str:
    return (
        "\n\n[OCTOPUS_SEMANTIC_DELTA]\n"
        f"{delta}\n"
        "[/OCTOPUS_SEMANTIC_DELTA]\n"
        "Resume the original Brain task using the committed facts. "
        "You are the Brain, not a branch; do not generate another branch Commit."
    )


def _parse_fact(data: Any, index: int) -> Fact:
    path = f"commit.facts[{index}]"
    item = _expect_object(data, path)
    _expect_keys(item, {"id", "predicate", "value", "evidence"}, path)
    _validate_json_value(item["value"], f"{path}.value")
    evidence_value = item["evidence"]
    if not isinstance(evidence_value, list):
        raise CommitValidationError(f"{path}.evidence must be an array")
    evidence = tuple(
        _parse_evidence(value, f"{path}.evidence[{evidence_index}]")
        for evidence_index, value in enumerate(evidence_value)
    )
    return Fact(
        id=_expect_nonempty_string(item["id"], f"{path}.id"),
        predicate=_expect_nonempty_string(item["predicate"], f"{path}.predicate"),
        value=item["value"],
        evidence=evidence,
    )


def _parse_evidence(data: Any, path: str) -> Evidence:
    item = _expect_object(data, path)
    _expect_keys(item, {"source", "locator", "excerpt"}, path)
    return Evidence(
        source=_expect_nonempty_string(item["source"], f"{path}.source"),
        locator=_expect_optional_string(item["locator"], f"{path}.locator"),
        excerpt=_expect_optional_string(item["excerpt"], f"{path}.excerpt"),
    )


def _expect_object(value: Any, path: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise CommitValidationError(f"{path} must be an object")
    return value


def _expect_keys(value: dict[str, Any], expected: set[str], path: str) -> None:
    actual = set(value)
    if actual != expected:
        missing = sorted(expected - actual)
        extra = sorted(actual - expected)
        raise CommitValidationError(f"{path} keys differ: missing={missing}, extra={extra}")


def _expect_string(value: Any, path: str) -> str:
    if not isinstance(value, str):
        raise CommitValidationError(f"{path} must be a string")
    return value


def _expect_nonempty_string(value: Any, path: str) -> str:
    result = _expect_string(value, path)
    if not result:
        raise CommitValidationError(f"{path} must not be empty")
    return result


def _expect_optional_string(value: Any, path: str) -> str | None:
    if value is not None and not isinstance(value, str):
        raise CommitValidationError(f"{path} must be a string or null")
    return value


def _expect_bool(value: Any, path: str) -> bool:
    if not isinstance(value, bool):
        raise CommitValidationError(f"{path} must be a boolean")
    return value


def _parse_string_list(value: Any, path: str) -> tuple[str, ...]:
    if not isinstance(value, list):
        raise CommitValidationError(f"{path} must be an array")
    return tuple(_expect_string(item, f"{path}[{index}]") for index, item in enumerate(value))


def _validate_json_value(value: Any, path: str) -> None:
    if value is None or isinstance(value, (bool, int, float, str)):
        return
    if isinstance(value, list):
        for index, item in enumerate(value):
            _validate_json_value(item, f"{path}[{index}]")
        return
    if isinstance(value, dict) and all(isinstance(key, str) for key in value):
        for key, item in value.items():
            _validate_json_value(item, f"{path}.{key}")
        return
    raise CommitValidationError(f"{path} must contain only JSON values")


def _canonical_json(value: JSONValue) -> str:
    return json.dumps(value, ensure_ascii=True, sort_keys=True, separators=(",", ":"))


def _append_unique(target: list[str], values: tuple[str, ...]) -> None:
    for value in values:
        if value not in target:
            target.append(value)


def _merged_tuple(left: tuple[T, ...], right: tuple[T, ...]) -> tuple[T, ...]:
    result = list(left)
    for value in right:
        if value not in result:
            result.append(value)
    return tuple(result)
