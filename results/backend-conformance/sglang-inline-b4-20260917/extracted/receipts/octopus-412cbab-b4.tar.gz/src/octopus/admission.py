"""CPU-only policies shared by the native allocator and fixed-event replay.

Benefits and penalties are GPU-compute seconds. Calibration is independent of
the evaluated trace; the online controller never sees an APC counterfactual.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Literal

from octopus.signals import Event, Requirement, Signals


Policy = Literal[
    "hard_pin", "apc", "ttl", "frequency", "queue_aware",
    "cost_greedy", "score", "no_eta", "fixed_price", "semantic_soft",
    "cost_greedy_semantic_gate", "semantic_future_only", "semantic_naive_pin",
    "b6_queue_aware", "b6_semantic_fixed", "b6_semantic_budgeted", "b6_semantic_value", "b6_history_blanket", "b7_semantic_online",
    "b6_model_intent",
]
POLICIES = (
    "hard_pin", "apc", "ttl", "frequency", "queue_aware",
    "cost_greedy", "score", "no_eta", "fixed_price", "semantic_soft",
    "cost_greedy_semantic_gate", "semantic_future_only", "semantic_naive_pin",
    "b6_queue_aware", "b6_semantic_fixed", "b6_semantic_budgeted", "b6_semantic_value", "b6_history_blanket", "b7_semantic_online",
    "b6_model_intent",
)
B6_POLICIES = frozenset({"b6_queue_aware", "b6_semantic_fixed", "b6_semantic_budgeted", "b6_semantic_value", "b6_history_blanket"})
SEMANTIC_PREFIX_POLICIES = B6_POLICIES | {"b7_semantic_online", "b6_model_intent"}
NO_LEASE_POLICIES = SEMANTIC_PREFIX_POLICIES | {"queue_aware", "semantic_soft", "semantic_future_only"}
SELECTIVE_POLICIES = SEMANTIC_PREFIX_POLICIES | {"apc"}


@dataclass(frozen=True, slots=True)
class Calibration:
    calibration_id: str
    prefill_tokens: tuple[int, ...]
    prefill_seconds: tuple[float, ...]
    loss_pressure: tuple[float, ...]
    loss_probability: tuple[float, ...]
    ttl_seconds: tuple[float, ...]
    selected_ttl_seconds: float
    unknown_eta_seconds: float
    reuse_probability: float
    initial_price: float
    price_learning_rate: float
    deadline_seconds: float
    risk_seconds: float
    tool_priors: dict[str, float] = field(default_factory=dict)
    prefill_contexts: tuple[dict, ...] = ()

    def __post_init__(self) -> None:
        for xs, ys in (
            (self.prefill_tokens, self.prefill_seconds),
            (self.loss_pressure, self.loss_probability),
        ):
            if len(xs) != len(ys) or not xs or sorted(set(xs)) != list(xs):
                raise ValueError("calibration curves need aligned, increasing knots")
        if not self.calibration_id:
            raise ValueError("calibration_id must identify independent measurements")
        if any(value < 0 for value in self.prefill_seconds):
            raise ValueError("prefill cost cannot be negative")
        if any(not 0 <= p <= 1 for p in self.loss_probability):
            raise ValueError("APC loss probabilities must be in [0, 1]")
        if (
            not self.ttl_seconds or min(self.ttl_seconds) <= 0
            or self.selected_ttl_seconds not in self.ttl_seconds
            or self.unknown_eta_seconds <= 0 or self.deadline_seconds <= 0
            or not 0 <= self.reuse_probability <= 1
            or min(self.initial_price, self.price_learning_rate, self.risk_seconds) < 0
        ):
            raise ValueError("invalid calibrated TTL, probability, price or deadline")

    def compute_seconds(self, tokens: int, batch: int = 1, pressure: float = 0.0) -> float:
        if self.prefill_contexts:
            context = min(
                self.prefill_contexts,
                key=lambda c: abs(c["batch"] - batch) + abs(c["pressure"] - pressure),
            )
            return interpolate(tokens, tuple(context["tokens"]), tuple(context["seconds"]))
        return interpolate(tokens, self.prefill_tokens, self.prefill_seconds)

    def loss(self, pressure: float) -> float:
        return interpolate(pressure, self.loss_pressure, self.loss_probability)


def interpolate(x: float, xs: tuple, ys: tuple) -> float:
    if x <= xs[0]:
        return ys[0]
    for i in range(1, len(xs)):
        if x <= xs[i]:
            fraction = (x - xs[i - 1]) / (xs[i] - xs[i - 1])
            return ys[i - 1] + fraction * (ys[i] - ys[i - 1])
    return ys[-1]


@dataclass(frozen=True, slots=True)
class Candidate:
    checkpoint_id: str
    blocks: frozenset[int]
    tokens: int
    captured_at: float
    expires_at: float | None
    resident: bool


@dataclass(frozen=True, slots=True)
class Snapshot:
    candidates: tuple[Candidate, ...]
    request_blocks: frozenset[int]
    total_blocks: int
    free_blocks: int
    queued_reuse: dict[str, tuple[str, ...]] = field(default_factory=dict)
    waiting_tokens: int = 0
    oldest_wait_seconds: float = 0.0
    allocation_failed: bool = False


@dataclass(frozen=True, slots=True)
class Action:
    checkpoint_id: str
    action: str
    expires_at: float | None
    benefit_seconds: float
    memory_seconds: float
    risk_seconds: float
    marginal_blocks: int
    reason: str


@dataclass(frozen=True, slots=True)
class Plan:
    actions: tuple[Action, ...]
    shadow_price: float
    budget_blocks: int
    offered_blocks: int
    decision_seconds: float


@dataclass(frozen=True, slots=True)
class FuturePreference:
    checkpoint_id: str
    consumer_ids: tuple[str, ...]
    reason: str
    benefit_proxy_seconds: float | None
    loss_proxy: float | None
    proxy_source: str | None
    estimated_adoption_at: float | None
    cached_tokens: int


class Controller:
    def __init__(self, policy: Policy, calibration: Calibration | None = None) -> None:
        if policy not in POLICIES:
            raise ValueError(f"unknown retention policy {policy!r}")
        if policy == "b7_semantic_online" and calibration is not None:
            raise ValueError("B7 uses within-trace observations, not external calibration")
        if policy not in NO_LEASE_POLICIES | {"hard_pin", "apc", "semantic_naive_pin"} and calibration is None:
            raise ValueError(f"{policy} requires independent Calibration measurements")
        self.policy = policy
        self.calibration = calibration
        self.signals = Signals(calibration.tool_priors if calibration else None)
        self.shadow_price = calibration.initial_price if calibration else 0.0
        self.last_decision_at: float | None = None

    def definite_future(self, checkpoint_id: str) -> tuple[str, ...]:
        return tuple(
            c.consumer_id for c in self.signals.consumers.values()
            if c.checkpoint_id == checkpoint_id and c.state in {"declared", "ready"}
            and c.requirement == Requirement.DEFINITE and c.advance_declared
            and (self.policy in SEMANTIC_PREFIX_POLICIES or checkpoint_id not in self.signals.closed)
        )

    def observe(self, event: Event) -> None:
        self.signals.observe(event)

    def future_preference(
        self, checkpoint_id: str, cached_tokens: int, now: float,
        pressure: float, waiting_requests: int,
    ) -> FuturePreference:
        consumers = [
            c for c in self.signals.consumers.values()
            if c.checkpoint_id == checkpoint_id and c.state in {"declared", "ready"}
            and checkpoint_id not in self.signals.closed
        ]
        reason = (
            "native_request_consumer" if any(
                c.checkpoint_id == checkpoint_id and c.state in {"queued", "active"}
                for c in self.signals.consumers.values()
            ) else "no_live_gpu_consumer" if checkpoint_id in self.signals.consumer_contracts
            else "unknown_consumer"
        )
        valid = []
        for consumer in consumers:
            estimate = self.signals.estimate(consumer, now, waiting_requests)
            reason = f"{estimate.status}_adoption_estimate"
            if estimate.status == "valid":
                valid.append(consumer)
        calibration = self.calibration
        loss = benefit = None
        source = None
        if valid:
            reason = "unknown_incremental_apc_benefit"
            if calibration is not None:
                loss = calibration.loss(pressure)
                source = calibration.calibration_id + ":pressure_loss_proxy"
                # One physical prefix, not one full cost per future consumer.
                benefit = calibration.compute_seconds(
                    cached_tokens, max(1, waiting_requests), pressure
                ) * loss * calibration.reuse_probability
                reason = "positive_apc_loss_proxy" if benefit > 0 and cached_tokens else "no_positive_cached_benefit"
        return FuturePreference(
            checkpoint_id, tuple(c.consumer_id for c in valid), reason, benefit,
            loss, source, min(
                (c.readiness_estimate.adoption_at for c in valid), default=None
            ), cached_tokens,
        )

    def decide(self, snapshot: Snapshot, now: float) -> Plan:
        started = time.perf_counter()
        calibration = self.calibration
        # Native allocator remains the final demand gate. This is only the
        # currently visible, reclaimable headroom, not prompt-size admission.
        budget = max(0, snapshot.total_blocks - len(snapshot.request_blocks))
        pressure = 1 - snapshot.free_blocks / max(1, snapshot.total_blocks)
        candidates = sorted(snapshot.candidates, key=lambda c: c.checkpoint_id)
        if self.policy == "semantic_naive_pin":
            return Plan(
                tuple(Action(
                    c.checkpoint_id, "KEEP" if self.definite_future(c.checkpoint_id) else "DROP",
                    None, 0, 0, 0, len(c.blocks - snapshot.request_blocks),
                    "definite_future_naive_pin",
                ) for c in candidates),
                0, budget, 0, time.perf_counter() - started,
            )
        if self.policy in NO_LEASE_POLICIES:
            return Plan(
                tuple(Action(
                    candidate.checkpoint_id, "DROP", None, 0, 0, 0, 0,
                    "native_free_lru_preference_no_lease",
                ) for candidate in candidates),
                0, budget, 0, time.perf_counter() - started,
            )
        selected_blocks: set[int] = set(snapshot.request_blocks)
        covered: set[tuple[str, int]] = set()
        actions: list[Action] = []
        offered: set[int] = set()
        remaining = list(candidates)
        if self.policy == "cost_greedy_semantic_gate":
            remaining = []
            for candidate in candidates:
                if candidate.checkpoint_id in self.signals.no_consumer_contracts:
                    actions.append(Action(
                        candidate.checkpoint_id, "DROP", None, 0, 0, 0, 0,
                        "explicit_none_semantic_gate",
                    ))
                else:
                    remaining.append(candidate)

        def value(candidate: Candidate) -> tuple[float, float, float, float, int, set, float]:
            state = self.signals.checkpoints[candidate.checkpoint_id]
            marginal = len(candidate.blocks - selected_blocks)
            if calibration is None:
                return 0, 0, 0, 0, marginal, set(), 0
            queued = snapshot.queued_reuse.get(candidate.checkpoint_id, ())
            episodes = [(node, 0.0) for node in queued]
            if self.policy in {"cost_greedy", "cost_greedy_semantic_gate", "score", "no_eta", "fixed_price"}:
                episodes += self.signals.episodes(candidate.checkpoint_id, now)
                if not episodes and not state.resolved:
                    episodes = [(
                        f"history:{candidate.checkpoint_id}",
                        calibration.unknown_eta_seconds,
                    )]
            elif not state.resolved and self.policy in {"ttl", "frequency"}:
                # History-only forecast is available to every non-semantic baseline.
                episodes += [(
                    f"history:{candidate.checkpoint_id}",
                    calibration.unknown_eta_seconds,
                )]
            if state.resolved:
                episodes = [(node, 0.0) for node in queued]
            episode_blocks = {
                (node, block) for node, _ in episodes for block in candidate.blocks
            } - covered
            cost_per_block = calibration.compute_seconds(
                candidate.tokens, max(1, sum(len(q) for q in snapshot.queued_reuse.values())),
                pressure,
            ) / max(
                1, len(candidate.blocks)
            )
            benefit = (
                len(episode_blocks) * cost_per_block
                * calibration.loss(pressure) * calibration.reuse_probability
            )
            if self.policy in {"cost_greedy", "cost_greedy_semantic_gate", "score", "no_eta", "fixed_price"}:
                benefit *= state.priority
            etas = [
                calibration.unknown_eta_seconds
                if eta is None or self.policy == "no_eta" else eta
                for _, eta in episodes
            ]
            eta = max(etas, default=calibration.unknown_eta_seconds)
            ttl = next(
                (t for t in sorted(calibration.ttl_seconds) if t >= eta),
                max(calibration.ttl_seconds),
            )
            if candidate.expires_at is not None:
                ttl = min(ttl, max(0.0, candidate.expires_at - now))
            memory = self.shadow_price * marginal * ttl
            # The dual resource price charges scarcity. This separate penalty
            # charges only observed overdue service, not the same queue cost twice.
            excess = max(
                0.0, snapshot.oldest_wait_seconds / calibration.deadline_seconds - 1
            )
            risk = calibration.risk_seconds * excess * marginal / max(1, budget)
            net = benefit - memory - risk
            density = net / marginal if marginal else net
            if self.policy == "score":
                density = benefit / (max(1, marginal) * (eta + min(calibration.ttl_seconds)))
            return density, benefit, memory, risk, marginal, episode_blocks, ttl

        while remaining:
            ranked = [(value(c), c) for c in remaining]
            metrics, candidate = max(ranked, key=lambda row: (row[0][0], row[1].checkpoint_id))
            remaining.remove(candidate)
            _, benefit, memory, risk, marginal, episode_blocks, ttl = metrics
            state = self.signals.checkpoints[candidate.checkpoint_id]
            expiry = candidate.expires_at
            expired = expiry is not None and now >= expiry
            reason = "nonpositive_incremental_value"
            keep = benefit > memory + risk
            if self.policy == "hard_pin":
                keep, expiry, reason = True, None, "historical_hard_pin"
            elif self.policy == "apc":
                keep, reason = False, "native_apc"
            elif self.policy in {"ttl", "frequency"}:
                assert calibration is not None
                expiry = candidate.captured_at + calibration.selected_ttl_seconds
                keep = now < expiry and not state.resolved
                if self.policy == "frequency":
                    keep = keep and state.reuse_count >= 2
                reason = "fixed_ttl" if self.policy == "ttl" else "second_hit"
            else:
                # Do not perpetually extend an existing KEEP using stale forecasts.
                expiry = min(expiry, now + ttl) if expiry is not None else now + ttl
                reason = "positive_incremental_value" if keep else reason
            if self.policy != "hard_pin" and expired:
                keep, reason = False, "ttl_expired"
            if keep:
                offered.update(candidate.blocks - snapshot.request_blocks)
                if self.policy != "hard_pin" and len(
                    (selected_blocks | candidate.blocks) - snapshot.request_blocks
                ) > budget:
                    keep, reason = False, "headroom"
            if keep:
                selected_blocks.update(candidate.blocks)
                covered.update(episode_blocks)
            actions.append(Action(
                candidate.checkpoint_id, "KEEP" if keep else "DROP",
                expiry if keep else None, benefit, memory, risk, marginal, reason,
            ))
        if calibration is not None and self.policy != "fixed_price":
            dt = 0 if self.last_decision_at is None else max(0, now - self.last_decision_at)
            # Use positive pre-clipping demand, plus actual service pressure.
            excess = len(offered) - budget
            if snapshot.waiting_tokens or snapshot.allocation_failed:
                excess = max(excess, len(offered))
            self.shadow_price = max(
                0.0, self.shadow_price + calibration.price_learning_rate * excess * dt
            )
        self.last_decision_at = now
        return Plan(
            tuple(actions), self.shadow_price, budget, len(offered),
            time.perf_counter() - started,
        )
