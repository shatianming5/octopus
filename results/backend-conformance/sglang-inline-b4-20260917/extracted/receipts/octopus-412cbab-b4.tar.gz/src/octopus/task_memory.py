"""Model-owned task plans with extractive, observation-grounded semantic commits."""
from __future__ import annotations

from copy import deepcopy
import json

from octopus.state import Commit, Evidence, Fact, StateReducer


class TaskMemoryError(ValueError):
    pass


def task_state_schema(action_schema: dict) -> dict:
    properties = {
        "plan": {
            "type": "array", "minItems": 1, "maxItems": 4,
            "items": {"type": "string", "minLength": 1, "maxLength": 160},
        },
        "evidence": {
            "type": "array", "maxItems": 2,
            "items": {
                "type": "object", "additionalProperties": False,
                "properties": {
                    "action_index": {"type": "integer", "minimum": 0},
                    "quote": {"type": "string", "minLength": 1, "maxLength": 200},
                },
                "required": ["action_index", "quote"],
            },
        },
        "reasoning": {"type": "string"},
        "action": action_schema,
    }
    return {"type": "object", "properties": properties,
            "required": list(properties), "additionalProperties": False}


class TaskMemory:
    def __init__(self, reducer: StateReducer, *, record_observations: bool = False) -> None:
        self.reducer = reducer
        self._record_observations = record_observations
        self._latest_observation: str | None = None
        self._observations: dict[int, tuple[dict, dict]] = {}
        self._predicates: dict[tuple[int, str], str] = {}
        self._plan: list[str] = []
        self._interpretation = ""

    @property
    def predicates(self) -> tuple[str, ...]:
        latest = (self._latest_observation,) if self._latest_observation is not None else ()
        return (*self._predicates.values(), *latest)

    def observe(self, index: int, action: dict, observation: dict) -> Commit | None:
        if index in self._observations:
            raise TaskMemoryError(f"observation {index} already recorded")
        self._observations[index] = deepcopy((action, observation))
        if not self._record_observations:
            return None
        predicate = f"tool_observation_{index}"
        commit = Commit(
            commit_id=f"commit-brain-observation-{index}", branch_id=f"brain-observation-{index}",
            summary="Recorded tool/controller outcome, not task correctness.",
            facts=(Fact(
                id=predicate, predicate=predicate,
                value={"action": deepcopy(action), "result": {
                    key: deepcopy(value) for key, value in observation.items() if key != "output"
                }},
                evidence=(Evidence(source=(
                    f"{action['action']}_output" if action["action"] in ("readonly_shell", "shell")
                    else "tool_observation"
                ), locator=f"action_index:{index}",
                                   excerpt=observation.get("output")),),
            ),),
            artifacts=(), actions_taken=(), unresolved=(), success=True,
        )
        self.reducer.apply(commit)
        self._latest_observation = predicate
        return commit

    def apply(self, index: int, decision: dict) -> Commit | None:
        plan, citations = decision["plan"], decision["evidence"]
        if (not isinstance(plan, list) or not 1 <= len(plan) <= 4
                or any(not isinstance(item, str) or not item.strip() or len(item) > 160
                       for item in plan)):
            raise TaskMemoryError("plan must contain 1..4 nonempty subgoals of at most 160 characters")
        if not isinstance(citations, list) or len(citations) > 2:
            raise TaskMemoryError("evidence must contain at most two observation quotes")
        pending: dict[tuple[int, str], Fact] = {}
        for citation in citations:
            if not isinstance(citation, dict) or set(citation) != {"action_index", "quote"}:
                raise TaskMemoryError("evidence requires action_index and quote")
            source, quote = citation["action_index"], citation["quote"]
            if type(source) is not int or source not in self._observations or source >= index:
                raise TaskMemoryError("evidence must cite a preceding recorded action_index")
            action, observation = self._observations[source]
            if action["action"] in ("readonly_shell", "shell"):
                raise TaskMemoryError("shell output is not trusted source evidence")
            output = observation.get("output")
            if (not isinstance(quote, str) or not quote.strip() or len(quote) > 200
                    or not isinstance(output, str) or quote not in output
                    or observation.get("action_submitted") is False):
                raise TaskMemoryError(
                    f"evidence quote must match 1..200 characters of actual tool output at action_index {source}"
                )
            key = source, quote
            if key in self._predicates or key in pending:
                continue
            predicate = f"observed_excerpt_{len(self._predicates) + len(pending)}"
            pending[key] = Fact(
                id=predicate, predicate=predicate, value=quote,
                evidence=(Evidence(
                    source="tool_observation",
                    locator=json.dumps({
                        "action_index": source, "action": action["action"],
                        "resource": action.get("path"),
                    }, sort_keys=True),
                    excerpt=quote,
                ),),
            )
        commit = None
        if pending:
            commit = Commit(
                commit_id=f"commit-brain-state-{index}", branch_id=f"brain-state-{index}",
                summary="Extractive quotes of historical tool observations; not task correctness.",
                facts=tuple(pending.values()), artifacts=(), actions_taken=(),
                unresolved=(), success=True,
            )
            self.reducer.apply(commit)
            self._predicates.update((key, fact.predicate) for key, fact in pending.items())
        self._plan = list(plan)
        self._interpretation = decision["reasoning"]
        return commit

    def to_dict(self) -> dict:
        return {
            "plan": list(self._plan),
            "model_interpretation_unverified": self._interpretation,
            "committed_evidence_predicates": list(self.predicates),
        }
