"""Immutable key snapshots on the hot path; legacy evidence at export."""
from __future__ import annotations

from dataclasses import dataclass, field


def encode(keys):
    return [(i, h.hex() if isinstance(h, bytes) else str(h)) for i, h in keys]


@dataclass(slots=True)
class DrawAudit:
    free_before: int
    native_draw: int
    queued: frozenset
    eligible_future: tuple
    future: frozenset
    selected: tuple
    budgeted: bool
    future_cap: int
    metadata: dict = field(default_factory=dict)
    _decoded: dict | None = field(default=None, init=False, repr=False)

    def decode(self, cache=None):
        if self._decoded is not None:
            return self._decoded
        cache = {} if cache is None else cache
        identity = id(self.eligible_future)
        if (identity, None) not in cache:
            cache[identity, None] = encode(self.eligible_future)
        encoded_future = cache[identity, None]
        limit = min(self.future_cap, len(encoded_future)) if self.budgeted else len(encoded_future)
        if (identity, limit) not in cache:
            cache[identity, limit] = sorted(encoded_future[:limit])
        selected = set(self.selected)
        metadata = dict(self.metadata)
        if "value_admission" in metadata:
            decision = metadata["value_admission"]
            metadata["value_admission"] = decision.decode()
            metadata["value_admission"]["native_forced_grant_evictions"] = encode(sorted(selected & decision.granted))
        self._decoded = {
            "free_before": self.free_before, "native_draw": self.native_draw,
            "queued_free_blocks": len(self.queued), "future_cap": self.future_cap,
            "budgeted": self.budgeted,
            "cap_binding": self.budgeted and len(self.eligible_future) > self.future_cap,
            "queued": encode(sorted(self.queued)),
            "eligible_future": encoded_future,
            "future": (encode(sorted(self.future)) if "value_admission" in metadata
                       else cache[identity, limit]), "selected": encode(self.selected),
            "reclaimed_queued": encode(sorted(selected & self.queued)),
            "reclaimed_future": encode(sorted(selected.intersection(self.eligible_future))),
            "reclaimed_preferred": encode(sorted(selected & (self.queued | self.future))),
            "retention_owner_blocks": 0, **metadata,
        }
        return self._decoded


@dataclass(slots=True)
class PreferenceAudit:
    at: float
    request_id: str
    ready: frozenset
    future: frozenset
    previous: tuple[frozenset, frozenset]
    snapshot_built: bool
    draws: list[DrawAudit]

    def decode(self, cache=None):
        preferred = self.ready | self.future
        previous = self.previous[0] | self.previous[1]
        return {
            "at": self.at, "kind": "allocation_preference_snapshot",
            "request_id": self.request_id,
            "ready": encode(sorted(self.ready)),
            "future": encode(sorted(self.future - self.ready)),
            "added": encode(sorted(preferred - previous)),
            "removed": encode(sorted(previous - preferred)),
            "retention_owner_blocks": 0, "physical_blocks_freed": 0,
            "snapshot_built": self.snapshot_built,
            "native_draws": [draw.decode(cache) for draw in self.draws],
        }
