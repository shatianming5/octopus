"""Unique physical-copy exposure at explicit native observation boundaries."""
from __future__ import annotations

from collections import defaultdict


class LiveFreeExposure:
    """Accumulate state-change deltas, never full per-draw audit snapshots."""

    def __init__(self):
        self.at = None
        self.active = {}
        self.started = {}
        self.segments = []
        self.block_seconds = 0.0
        self.group_seconds = defaultdict(float)
        self.events = 0
        self.transitions = 0
        self.peak_blocks = 0
        self.counts = {}
        self.last_input = None

    def advance(self, at):
        if self.at is not None:
            dt = at - self.at
            if dt < 0:
                raise ValueError("exposure clock moved backwards")
            self.block_seconds += len(self.active) * dt
            for group, count in self.counts.items():
                self.group_seconds[group] += count * dt
        self.at = at

    def observe(self, at, copies, *, cause):
        self.advance(at)
        self.events += 1
        if copies is self.last_input:
            return
        self.last_input = copies
        removed = [key for key, info in self.active.items() if copies.get(key) != info]
        added = [key for key, info in copies.items() if self.active.get(key) != info]
        for key in removed:
            info = self.active[key]
            self.segments.append({
                "block_id": key[0], "hash": key[1].hex() if isinstance(key[1], bytes) else str(key[1]),
                "start": self.started.pop(key), "end": at,
                "end_cause": cause, **info,
            })
        for key in added:
            self.started[key] = at
        if removed or added:
            self.transitions += 1
            self.active = dict(copies)
            self.counts = self._group_counts()
        self.peak_blocks = max(self.peak_blocks, len(copies))

    def _group_counts(self):
        counts = defaultdict(int)
        for info in self.active.values():
            counts[info["group"]] += 1
        return counts

    def finish(self, at):
        self.observe(at, {}, cause="measurement_end")
        return {
            "units": "physical-block-seconds",
            "block_seconds": self.block_seconds,
            "group_block_seconds": dict(self.group_seconds),
            "peak_blocks": self.peak_blocks,
            "observation_events": self.events,
            "state_transitions": self.transitions,
            "segments": self.segments,
        }


class NativePreferenceExposure:
    """Read-only, cached live-state observer for fixed/value/queue/APC adapters."""

    def __init__(self, scheduler):
        import time
        if scheduler.controller.policy not in {"b6_semantic_fixed", "b6_semantic_value", "b6_history_blanket", "b6_queue_aware", "apc"}:
            raise ValueError("native exposure supports the current fixed/value/queue/APC policies")
        self.s = scheduler
        self.clock = scheduler.clock
        self.time = time
        self.future = LiveFreeExposure()
        self.queued = LiveFreeExposure()
        self.cpu_seconds = 0.0
        self.mark_cpu_seconds = 0.0
        self.events = defaultdict(int)
        self.decisions = []
        self._saved = []
        self._depth = 0
        self._fg_signature = self._q_signature = None
        self._fg_dirty = self._q_dirty = True
        self._fg_watch, self._q_watch = set(), set()
        self._semantic, self._queued, self.future_keys = {}, {}, {}
        self._generations = defaultdict(int)
        self._rejected = frozenset()
        self.history = getattr(scheduler.value_admission, "history", None)
        self._history_version = None
        self._candidate_copies = {}
        self._candidate_states = {}
        self._support_rejected = frozenset()
        self.candidate_states = LiveFreeExposure()
        self.initial_labels = {}
        self.selection_events = []
        self.scheduled_events = []
        self.logical_requests = {}
        self._decision = None
        self._install()

    def _replace(self, owner, name, replacement):
        self._saved.append((owner, name, getattr(owner, name)))
        setattr(owner, name, replacement)

    def _mark(self, hashes, removed_block_id=None):
        started = self.time.perf_counter()
        for h in hashes:
            if removed_block_id is not None:
                self._generations[removed_block_id, h] += 1
            self._fg_dirty |= h in self._fg_watch
            self._q_dirty |= h in self._q_watch
        self.mark_cpu_seconds += self.time.perf_counter() - started

    def _install(self):
        pool = self.s.kv_cache_manager.block_pool
        insert, remove = pool._insert_block_hash, pool._remove_cached_block_hashes
        def inserted(h, block, num_tokens):
            insert(h, block, num_tokens)
            self._mark((h,))
            if not self._depth:
                self.sync(self.clock(), "cache_insert")
        def removed(block):
            hashes = remove(block)
            self._mark(hashes, block.block_id)
            if not self._depth:
                self.sync(self.clock(), "cache_remove")
            return hashes
        self._replace(pool, "_insert_block_hash", inserted)
        self._replace(pool, "_remove_cached_block_hashes", removed)
        if self.s.queue_retention is not None:
            retention = self.s.queue_retention
            select = retention._select_blocks
            def selected(n):
                blocks, needed = select(n)
                at = self.clock()
                started = self.time.process_time()
                keys = tuple((b.block_id, b.block_hash) for b in blocks)
                self.selection_events.append((
                    at, n, retention._eligible_keys, retention._future,
                    retention._queued, keys, self._decision,
                ))
                self.cpu_seconds += self.time.process_time() - started
                return blocks, needed
            self._replace(retention, "_select_blocks", selected)
            if retention.admit_future is not None:
                admit = retention.admit_future
                def admitted(*args):
                    kept, self._decision = admit(*args)
                    return kept, self._decision
                self._replace(retention, "admit_future", admitted)
            changed = retention.changed_blocks
            def membership(blocks):
                if changed is not None:
                    changed(blocks)
                self._mark(b.block_hash for b in blocks)
                if not self._depth:
                    self.sync(self.clock(), "free_membership")
            self._replace(retention, "changed_blocks", membership)
            invalidated = retention.invalidate
            def invalidate():
                invalidated()
                if not self._depth:
                    self.sync(self.clock(), "semantic_or_queue_invalidation")
            self._replace(retention, "invalidate", invalidate)
        for name in ("touch", "free_blocks", "get_new_blocks", "cache_full_blocks", "reset_prefix_cache"):
            original = getattr(pool, name)
            def operation(*args, _original=original, _name=name, **kwargs):
                self._depth += 1
                reset_ids = ([(b.block_id, b.block_hash) for b in pool.blocks if b.block_hash is not None]
                             if _name == "reset_prefix_cache" else ())
                try:
                    result = _original(*args, **kwargs)
                    if _name == "reset_prefix_cache" and result:
                        for identity in reset_ids:
                            self._generations[identity] += 1
                        self._fg_dirty = self._q_dirty = True
                    return result
                finally:
                    self._depth -= 1
                    if not self._depth:
                        self.sync(self.clock(), _name)
            self._replace(pool, name, operation)
        for name in ("_record_scheduled", "_capture_checkpoint"):
            original = getattr(self.s, name)
            def event(*args, _original=original, _name=name, **kwargs):
                result = _original(*args, **kwargs)
                self.sync(self.clock(), _name)
                return result
            self._replace(self.s, name, event)
        self.s.committed_schedule_observers.append(self._scheduled)

    def _scheduled(self, request, adoption):
        from vllm.v1.core.kv_cache_utils import make_block_hash_with_group_id
        started = self.time.process_time()
        self.scheduled_events.append(adoption)
        if adoption.adopted_prefix_tokens is not None and not adoption.preemption_episode:
            self.logical_requests[request.request_id] = {
                "initial_scheduled_at": adoption.at,
                "initial_adopted_prefix_tokens": adoption.adopted_prefix_tokens,
                "consumer_id": adoption.consumer_id,
                "checkpoint_id": adoption.checkpoint_id,
                "logical_prompt_blocks": [
                    make_block_hash_with_group_id(h, 0).hex()
                    for h in request.block_hashes[:request.num_prompt_tokens // self.s.block_size]
                ],
            }
        self.cpu_seconds += self.time.process_time() - started

    @staticmethod
    def _free(block):
        return (not block.is_null and block.block_hash is not None and block.ref_cnt == 0
                and block.prev_free_block is not None and block.next_free_block is not None)

    def _signatures(self):
        from vllm.v1.request import RequestStatus
        fg = []
        if self.s.controller.policy in {"b6_semantic_fixed", "b6_semantic_value", "b6_history_blanket"}:
            for cp, lease in self.s._checkpoints.items():
                if not lease.handle_open:
                    continue
                consumers = self.s.controller.definite_future(cp)
                required = max((
                    len(lease.checkpoint.logical_token_ids) if c.parent_prefix_tokens is None
                    else c.parent_prefix_tokens
                    for identity in consumers for c in (self.s.controller.signals.consumers[identity],)
                ), default=0)
                fg.append((cp, consumers, min(required, lease.checkpoint.shared_tokens)))
        elif self.s.controller.policy not in {"b6_queue_aware", "apc"}:
            raise ValueError("native exposure supports the current fixed/value/queue/APC policies")
        queued = []
        if self.s.controller.policy != "apc":
            for r in self.s.requests.values():
                if r.status not in {RequestStatus.WAITING, RequestStatus.PREEMPTED,
                                    RequestStatus.WAITING_FOR_STRUCTURED_OUTPUT_GRAMMAR}:
                    continue
                if r.num_stale_output_tokens and not r.drop_stale_output:
                    continue
                if self.s.kv_cache_manager.prefix_cache_lookup_enabled(r):
                    queued.append((r.request_id, r.num_tokens, len(r.block_hashes),
                                   r.block_hashes[-1] if r.block_hashes else None))
        return tuple(fg), tuple(queued)

    def sync(self, at, cause):
        from vllm.v1.core.kv_cache_utils import make_block_hash_with_group_id
        from vllm.v1.kv_cache_interface import FullAttentionSpec
        started = self.time.process_time()
        manager = self.s.kv_cache_manager
        groups = manager.kv_cache_config.kv_cache_groups
        if len(groups) != 1 or not isinstance(groups[0].kv_cache_spec, FullAttentionSpec):
            raise ValueError("native exposure requires the pinned dense single-group producer")
        size = groups[0].kv_cache_spec.block_size
        mapping = manager.block_pool.cached_block_hash_to_block
        fg, queued = self._signatures()
        fg_changed, q_changed = fg != self._fg_signature, queued != self._q_signature
        history_version = self.history.version if self.history is not None else None
        history_changed = history_version != self._history_version
        changed = False
        semantic_rebuilt = fg_changed or history_changed or self._fg_dirty
        queued_rebuilt = q_changed or self._q_dirty
        if semantic_rebuilt:
            semantic, wanted, watch, lookup = {}, defaultdict(list), set(), {}
            all_candidates = defaultdict(list)
            support = {}
            if fg_changed and self._fg_signature is not None:
                remaining = {cp for cp, _, _ in fg}
                for cp, _, _ in self._fg_signature:
                    if cp not in remaining:
                        self.decisions.append({
                            "at": at, "cause": cause, "checkpoint_id": cp,
                            "decision": "WITHDRAW", "reason": "checkpoint_closed",
                            "required_tokens": 0, "cached_leading_tokens": 0,
                            "consumer_ids": (), "value_rejection": False,
                        })
            for cp, consumers, required in fg:
                lease = self.s._checkpoints[cp]
                cached = 0
                for depth, h in enumerate(lease.block_hashes[:required // size]):
                    h = make_block_hash_with_group_id(h, 0)
                    watch.add(h)
                    block = mapping.get_one_block(h)
                    if block is None:
                        break
                    cached += size
                    key = (block.block_id, block.block_hash)
                    all_candidates[key].append((cp, depth))
                    if self._free(block):
                        wanted[key].append((cp, depth))
                        lookup[key] = h
                if fg_changed:
                    self.decisions.append({
                        "at": at, "cause": cause, "checkpoint_id": cp,
                        "decision": "KEEP" if required else "WITHDRAW",
                        "reason": "baseline_declared_future" if required else "no_remaining_future",
                        "required_tokens": required, "cached_leading_tokens": cached,
                        "consumer_ids": consumers, "value_rejection": False,
                    })
            if self.history is not None:
                pending = getattr(self.history, "pending", None)
                for endpoint, entry in self.history.prefixes.items():
                    for depth, raw in enumerate(entry["hashes"]):
                        h = make_block_hash_with_group_id(raw, 0)
                        watch.add(h)
                        block = mapping.get_one_block(h)
                        if block is None:
                            break
                        key = block.block_id, block.block_hash
                        origin = ("history:" + endpoint.hex(), depth)
                        all_candidates[key].append(origin)
                        support[h] = {
                            "history_state": ("epoch_history" if pending is None else
                                              "pending" if raw in pending else "resolved"),
                            "history_episode": getattr(self.history, "episodes", {}).get(raw, 0),
                            "outstanding_support": pending is None or raw in pending,
                        }
                        if self._free(block):
                            wanted[key].append(origin)
                            lookup[key] = h
            for key, origins in wanted.items():
                entry = mapping._cache[lookup[key]]
                copies = list(entry.values()) if isinstance(entry, dict) else [entry]
                others = [b for b in copies if b.block_id != key[0]]
                semantic[key] = {
                    "group": "leading_block" if any(d == 0 for _, d in origins) else "semantic_body",
                    "origins": tuple(origins),
                    "other_cached_copy_ids": tuple(b.block_id for b in others),
                    "other_held_copy_ids": tuple(b.block_id for b in others if b.ref_cnt > 0),
                    "other_free_copy_ids": tuple(b.block_id for b in others if self._free(b)),
                    "cache_generation": self._generations[key],
                    **support.get(key[1], {}),
                }
            candidate_copies = {}
            for representative, origins in all_candidates.items():
                entry = mapping._cache[representative[1]]
                copies = list(entry.values()) if isinstance(entry, dict) else [entry]
                for block in copies:
                    key = block.block_id, block.block_hash
                    candidate_copies[key] = {
                        "group": "candidate_union",
                        "origins": tuple(origins), "representative": key == representative,
                        "cache_generation": self._generations[key],
                        "native_state": "held" if block.ref_cnt > 0 else "free" if self._free(block) else "unlinked",
                        "ref_count": block.ref_cnt, **support.get(key[1], {}),
                    }
            self._candidate_copies = candidate_copies
            changed |= semantic != self._semantic
            self._semantic, self._fg_watch = semantic, watch
            self._fg_signature, self._fg_dirty = fg, False
            self._history_version = history_version
        if queued_rebuilt:
            preferred, watch = {}, set()
            for identity, tokens, _, _ in queued:
                for h in self.s.requests[identity].block_hashes[:(tokens - 1) // size]:
                    h = make_block_hash_with_group_id(h, 0)
                    watch.add(h)
                    block = mapping.get_one_block(h)
                    if block is None:
                        break
                    if self._free(block):
                        preferred[block.block_id, block.block_hash] = {"group": "queued_native_preference"}
            changed |= preferred != self._queued
            self._queued, self._q_watch = preferred, watch
            self._q_signature, self._q_dirty = queued, False
        rejected = (self.s.value_admission.rejected
                    if self.s.value_admission is not None else frozenset())
        if self.history is not None and hasattr(self.history, "pending"):
            # Match zero-support closure without calling (or mutating) the selector.
            if semantic_rebuilt:
                allowed = {key for key, info in self._semantic.items()
                           if any(not cp.startswith("history:") for cp, _ in info["origins"])}
                views = {}
                for endpoint, entry in self.history.prefixes.items():
                    leading = []
                    for h in entry["hashes"]:
                        block = mapping.get_one_block(make_block_hash_with_group_id(h, 0))
                        if block is None:
                            break
                        leading.append(block)
                    views[endpoint] = leading
                allowed.update(self.s.value_admission.supported_history_keys(views))
                self._support_rejected = self._semantic.keys() - allowed
            previous_zero = self.s.value_admission._zero_rejected
            rejected = (rejected - previous_zero) | self._support_rejected
        rejection_changed = rejected != self._rejected
        if changed or rejection_changed:
            self.future_keys = {k: v for k, v in self._semantic.items()
                                if k not in self._queued and k not in rejected}
        self._rejected = rejected
        # Retain derived state between mutations, not the observation clock or events.
        if semantic_rebuilt or queued_rebuilt or rejection_changed:
            states = {}
            for key, info in self._candidate_copies.items():
                queued_copy = key in self._queued
                eligible = info["native_state"] == "free" and info["representative"] and not queued_copy
                action = "DROP" if key in rejected else "KEEP"
                state = {**info, "queued": queued_copy, "eligible": eligible,
                         "decision": action if eligible else "NOT_ELIGIBLE",
                         "value_rejection": eligible and key in rejected}
                states[key] = state
                label_key = (getattr(self.history, "epoch", 0), key[1])
                if eligible and label_key not in self.initial_labels:
                    self.initial_labels[label_key] = {
                        "at": at, "block_id": key[0], "hash": key[1].hex(),
                        "epoch": label_key[0], **state,
                    }
            self._candidate_states = states
        self.candidate_states.observe(at, self._candidate_states, cause=cause)
        self.future.observe(at, self.future_keys, cause=cause)
        self.queued.observe(at, self._queued, cause=cause)
        self.events[cause] += 1
        self.cpu_seconds += self.time.process_time() - started
        return self.future_keys, self._queued

    def start(self, at):
        self.future, self.queued = LiveFreeExposure(), LiveFreeExposure()
        self.cpu_seconds = self.mark_cpu_seconds = 0.0
        self.events.clear()
        self.decisions.clear()
        self.selection_events.clear()
        self.scheduled_events.clear()
        self.logical_requests.clear()
        self.initial_labels.clear()
        self.candidate_states = LiveFreeExposure()
        self._history_version = None
        self._fg_signature = self._q_signature = None
        self._fg_dirty = self._q_dirty = True
        self._generations.clear()
        self.sync(at, "measurement_start")

    def finish(self, at):
        from dataclasses import asdict
        from octopus.retention_audit import encode
        try:
            self.sync(at, "measurement_end_state")
            decoded = self.time.process_time()
            selections = [{
                "at": when, "native_draw": n, "eligible": encode(sorted(eligible)),
                "kept": encode(sorted(kept)), "queued": encode(sorted(queued)),
                "value_rejected": encode(sorted(eligible - kept)),
                "native_forced_keep_victims": encode(sorted(set(selected) & kept)),
                "selected": encode(selected),
                "decision": decision.decode() if decision is not None else None,
            } for when, n, eligible, kept, queued, selected, decision in self.selection_events]
            schedules = [asdict(event) for event in self.scheduled_events]
            export_cpu = self.time.process_time() - decoded
            return {
                "schema": "octopus-live-free-exposure-v1",
                "future_only": self.future.finish(at),
                "queued_preference": self.queued.finish(at),
                "observer_cpu_seconds": self.cpu_seconds,
                "native_mark_elapsed_seconds": self.mark_cpu_seconds,
                "events": dict(self.events), "prospective_baseline_decisions": self.decisions,
                "candidate_information": "semantic_union_confirmed_initial_adoption" if self.history is not None else "original_policy",
                "candidate_state_episodes": self.candidate_states.finish(at)["segments"],
                "initial_eligible_labels": list(self.initial_labels.values()),
                "selection_events": selections,
                "committed_schedules": schedules,
                "logical_requests": self.logical_requests,
                "confirmed_history": self.history.events if self.history is not None else [],
                "history_support_transitions": getattr(self.history, "support_events", []),
                "deferred_export_cpu_seconds": export_cpu,
                "reference_scope": "all committed scheduled ranges and full prompt logical correspondence; prior/onward uses are not restricted to FREE intervals",
                "clock_scope": "native observation/operation boundaries; no machine-instruction timestamps invented",
                "legacy_retained_block_seconds": self.s.unique_retained_block_seconds,
            }
        finally:
            self.s.committed_schedule_observers.remove(self._scheduled)
            for owner, name, original in reversed(self._saved):
                setattr(owner, name, original)
            self._saved.clear()
