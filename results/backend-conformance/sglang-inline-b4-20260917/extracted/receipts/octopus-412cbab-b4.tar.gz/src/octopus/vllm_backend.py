from __future__ import annotations

import os
import inspect
import time
from collections import Counter
from dataclasses import asdict, dataclass, field
from typing import Any

import torch
import vllm
from vllm.config.structured_outputs import StructuredOutputsConfig
from vllm.engine.arg_utils import EngineArgs
from vllm.sampling_params import SamplingParams, StructuredOutputsParams
from vllm.v1.core.kv_cache_manager import KVCacheBlocks
from vllm.v1.core.sched.scheduler import Scheduler
from vllm.v1.engine.llm_engine import LLMEngine
from vllm.v1.request import Request, RequestStatus

from octopus.admission import (
    B6_POLICIES, SEMANTIC_PREFIX_POLICIES, NO_LEASE_POLICIES, SELECTIVE_POLICIES,
    Calibration, Candidate, Controller, Policy, Snapshot,
)
from octopus.signals import CheckpointIntent, Event, Requirement
from octopus.queue_retention import B6Retention, BlockKey, QueueRetention
from octopus.future_prefix import FuturePrefixCache
from octopus.retention_audit import PreferenceAudit
from octopus.model_intent import ModelIntent
from octopus.backend import (
    BackendConfig, Checkpoint, BackendCapabilities, GenerationConfig, GenerationEvent,
)
from octopus.context import InheritanceMode


@dataclass(slots=True)
class RequestMetrics:
    first_scheduled_at: float | None = None
    prompt_tokens: int = 0
    actual_prefill_tokens: int = 0
    actual_decode_tokens: int = 0
    inherited_tokens: int = 0
    preemptions: int = 0
    scheduled_ranges: list[tuple[int, int]] = field(default_factory=list)
    finish_status: str | None = None
    adopted_prefix_tokens: int | None = None
    checkpoint_frontier_tokens: int | None = None
    consumer_id: str | None = None
    enqueued_at: float | None = None
    selected_parent_tokens: int = 0
    capsule_tokens: int = 0
    parent_checkpoint_id: str | None = None
    last_scheduled_event: tuple[int, int, int] | None = None

    @property
    def selected_parent_recomputed_tokens(self) -> int:
        return self.trunk_recomputed_tokens(self.checkpoint_frontier_tokens or 0)

    @property
    def adopted_parent_tokens(self) -> int:
        return min(self.adopted_prefix_tokens or 0, self.checkpoint_frontier_tokens or 0)

    @property
    def capsule_prefill_tokens(self) -> int:
        start = self.selected_parent_tokens
        end = start + self.capsule_tokens
        return sum(max(0, min(b, end) - max(a, start)) for a, b in self.scheduled_ranges)

    @property
    def capsule_cached_tokens(self) -> int:
        return max(0, min(
            (self.adopted_prefix_tokens or 0) - self.selected_parent_tokens,
            self.capsule_tokens,
        ))

    def trunk_recomputed_tokens(self, shared_tokens: int) -> int:
        return sum(
            max(0, min(end, shared_tokens) - start)
            for start, end in self.scheduled_ranges
            if start < shared_tokens
        )


@dataclass(frozen=True, slots=True)
class AllocationAttempt:
    attempt_id: int
    request_id: str
    at: float
    parameters: dict[str, Any]
    free_before: int
    free_after: int
    succeeded: bool
    allocated: tuple[tuple[int, str | None], ...]
    evicted: tuple[tuple[int, str | None], ...]
    required_blocks: int | None = None


def block_identity(block: Any) -> tuple[int, str | None]:
    value = block.block_hash
    return block.block_id, value.hex() if isinstance(value, bytes) else str(value) if value is not None else None


@dataclass(frozen=True, slots=True)
class ActualAdoption:
    at: float
    request_id: str
    consumer_id: str | None
    checkpoint_id: str | None
    checkpoint_frontier_tokens: int | None
    max_probe_hit_tokens: int
    adopted_prefix_tokens: int | None
    scheduled_range: tuple[int, int]
    preemption_episode: int
    adopted_prefix_identity: tuple[tuple[tuple[int, str | None], ...], ...] | None


@dataclass(frozen=True, slots=True)
class PoolSnapshot:
    active_blocks: int
    warm_cached_blocks: int
    free_blocks: int
    total_blocks: int
    request_owned_blocks: int = 0
    retention_only_blocks: int = 0
    shared_request_retention_blocks: int = 0
    cold_free_blocks: int = 0


@dataclass(slots=True)
class _CheckpointLease:
    checkpoint: Checkpoint
    blocks: KVCacheBlocks
    lease_id: str | None
    handle_open: bool = True
    bound_request_ids: set[str] = field(default_factory=set)
    captured_at: float = 0.0
    expires_at: float | None = None
    offered: bool = False
    block_hashes: tuple = ()
    offered_at: float = 0.0


class AdmissionAllocator:
    """Engine-local adapter: native rejection, revoke, native retry.

    Freeing an owner does not evict cached blocks. No intervening allocation is
    allowed between retries; the native allocator adopts prefix hits before it
    allocates/evicts new blocks. Both scheduler allocation paths use this seam.
    """

    def __init__(self, manager: Any, reclaim: Any, observer: Any = None, owner_observer: Any = None) -> None:
        self.native = manager
        self.reclaim = reclaim
        self.observer = observer
        self.owner_observer = owner_observer
        self.free_observer: Any = None
        self.free_observer_cpu_seconds = 0.0

    def __getattr__(self, name: str) -> Any:
        return getattr(self.native, name)

    def allocate_slots(self, *args: Any, **kwargs: Any) -> KVCacheBlocks | None:
        allocate = self.native.allocate_slots
        def attempt():
            return self.observer(allocate, args, kwargs) if self.observer else allocate(*args, **kwargs)
        result = attempt()
        while result is None and self.reclaim():
            result = attempt()
        return result

    def free(self, request: Request) -> None:
        if self.free_observer is None:
            self.native.free(request)
        else:
            started = time.perf_counter()
            groups = tuple(tuple(group) for group in self.native.get_blocks(request.request_id).blocks)
            native_started = time.perf_counter()
            self.native.free(request)
            native_finished = time.perf_counter()
            self.free_observer(request, groups)
            self.free_observer_cpu_seconds += (
                native_started - started + time.perf_counter() - native_finished
            )
        if self.owner_observer is not None:
            self.owner_observer("native_free", request)


class EvictionObserver:
    """Observe native eviction without replacing the block-pool allocator."""

    def __init__(self, collector: Any) -> None:
        self.collector = collector
        self.evictions = 0
        self.identities: list[tuple[int, str | None]] | None = None

    def on_block_evicted(self, block: Any) -> None:
        self.evictions += block.block_hash is not None
        if self.identities is not None and block.block_hash is not None:
            self.identities.append(block_identity(block))
        if self.collector is not None:
            self.collector.on_block_evicted(block)

    def on_block_allocated(self, block: Any) -> None:
        if self.collector is not None:
            self.collector.on_block_allocated(block)

    def on_block_accessed(self, block: Any) -> None:
        if self.collector is not None:
            self.collector.on_block_accessed(block)

    def reset(self) -> None:
        self.evictions = 0
        if self.collector is not None:
            self.collector.reset()


class OctopusScheduler(Scheduler):
    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._capture_request_ids: dict[str, str] = {}
        self._capture_intents: dict[str, CheckpointIntent] = {}
        self._checkpoint_ids_by_request: dict[str, str] = {}
        self._checkpoints: dict[str, _CheckpointLease] = {}
        self._request_bindings: dict[str, str] = {}
        self._request_metrics: dict[str, RequestMetrics] = {}
        self._active_blocks_peak = 0
        self._request_owned_blocks_peak = 0
        self.controller = Controller("hard_pin")
        self.queue_retention: QueueRetention | None = None
        self.clock = time.perf_counter
        self.policy_decisions: list[dict[str, Any]] = []
        self._preference_decisions: list[dict | PreferenceAudit] = []
        self._future_prefix_cache: FuturePrefixCache | None = None
        self.audit_decode_cpu_seconds = 0.0
        self.allocation_attempts: list[AllocationAttempt] = []
        self.adoptions: list[ActualAdoption] = []
        self.lifecycle: list[dict[str, Any]] = []
        self.owner_changes: list[dict[str, Any]] = []
        self._owner_state: dict[str, dict] = {}
        self.adapter_cpu_seconds = 0.0
        self.preference_provider_cpu_seconds = 0.0
        self.time_origin = self.clock()
        self._last_preferred = (frozenset(), frozenset())
        self.retention_revocations = 0
        self.allocation_retries = 0
        self._retained_since = self.clock()
        self._retained_count = 0
        self._retained_block_seconds = 0.0
        self.eviction_observer = EvictionObserver(self.kv_cache_manager.block_pool.metrics_collector)
        self.kv_cache_manager.block_pool.metrics_collector = self.eviction_observer
        self.kv_cache_manager = AdmissionAllocator(
            self.kv_cache_manager, self._reclaim_for_allocation
        )

    def configure_admission(
        self, policy: Policy, calibration: Calibration | None = None, *, value_hidden_size: int | None = None,
        value_history_mode: str | None = None, adoption_audit_enabled: bool = True,
    ) -> None:
        if self._checkpoints:
            raise RuntimeError("configure admission before capturing checkpoints")
        self.controller = Controller(policy, calibration)
        if value_history_mode not in {None, "next_reuse"}:
            raise ValueError("serving value history must be the frozen next_reuse rule")
        if value_history_mode is not None and policy != "b6_semantic_value":
            raise ValueError("value_history_mode requires b6_semantic_value")
        self.committed_adoption_callback = None
        self.committed_schedule_observers = []
        self.adoption_audit_enabled = adoption_audit_enabled
        self._current_allocation_request = None
        self.value_admission = None
        self._model_intents: dict[str, ModelIntent] = {}
        if policy in {"b6_semantic_value", "b6_history_blanket"}:
            from octopus.value_admission import NativeValueAdmission
            self.value_admission = NativeValueAdmission(self, value_hidden_size)
        self._preference_decisions = []
        self.audit_decode_cpu_seconds = 0.0
        self.allocation_attempts = []
        self.adoptions = []
        self.adapter_cpu_seconds = 0.0
        self.preference_provider_cpu_seconds = 0.0
        self.time_origin = self.clock()
        self._last_preferred = (frozenset(), frozenset())
        self._allocation_signature = inspect.signature(self.kv_cache_manager.native.allocate_slots)
        self.kv_cache_manager.observer = self._observe_allocation
        self.kv_cache_manager.owner_observer = self._record_native_owner
        pool = self.kv_cache_manager.block_pool
        if self.queue_retention is not None:
            pool.free_block_queue = self.queue_retention.native
            self.queue_retention = None
        if self._future_prefix_cache is not None:
            self._future_prefix_cache.close()
            self._future_prefix_cache = None
        if policy in {"queue_aware", "semantic_soft", "semantic_future_only"}:
            self.queue_retention = QueueRetention(
                pool.free_block_queue, self._ready_waiting_prefixes,
                self._future_prefixes if policy in {"semantic_soft", "semantic_future_only"} else None,
            )
            pool.free_block_queue = self.queue_retention
        elif policy in SEMANTIC_PREFIX_POLICIES:
            if policy != "b6_queue_aware":
                self._future_prefix_cache = FuturePrefixCache(self)
            self.queue_retention = B6Retention(
                pool.free_block_queue, self._b6_queued_prefixes,
                self._b6_future_prefixes if policy != "b6_queue_aware" else lambda: (),
                blocks=pool.blocks,
                budgeted=policy in {"b6_semantic_budgeted", "b6_semantic_value", "b7_semantic_online", "b6_model_intent"},
                order_future=self._b7_order_future if policy == "b7_semantic_online" else None,
                changed_blocks=self._future_prefix_cache.changed_blocks if self._future_prefix_cache else None,
                admit_future=self.value_admission.select if self.value_admission else None,
            )
            pool.free_block_queue = self.queue_retention
        if value_history_mode is not None or policy == "b6_history_blanket":
            from octopus.history_admission import HistoryAdmission
            HistoryAdmission(self, "blanket" if policy == "b6_history_blanket" else value_history_mode)

    def apply_model_intents(self, intents: dict[str, ModelIntent]) -> None:
        if self.controller.policy != "b6_model_intent":
            raise ValueError("model intents require retention_policy='b6_model_intent'")
        for cp, intent in intents.items():
            self._get_open_checkpoint(cp)
            if not isinstance(intent, ModelIntent):
                raise ValueError("model intents must be validated ModelIntent values")
        self._model_intents.update(intents)

    @property
    def preference_decisions(self) -> list[dict]:
        started = time.perf_counter()
        cache = {}
        result = [row.decode(cache) if isinstance(row, PreferenceAudit) else row
                  for row in self._preference_decisions]
        self.audit_decode_cpu_seconds += time.perf_counter() - started
        return result

    @property
    def prefix_maintenance_cpu_seconds(self) -> float:
        semantic = self._future_prefix_cache.maintenance_cpu_seconds if self._future_prefix_cache is not None else 0.0
        return semantic + self.history_maintenance_cpu_seconds

    @property
    def history_maintenance_cpu_seconds(self) -> float:
        return getattr(self.value_admission, "maintenance_cpu_seconds", 0.0)

    def declare_gpu_consumer(
        self, checkpoint_id: str, consumer_id: str, after: tuple[str, ...] = (),
        *, requirement: Requirement = Requirement.DEFINITE,
        condition_id: str | None = None, condition_outcome: bool = True,
        parent_prefix_tokens: int | None = None,
    ) -> None:
        parent = self._get_open_checkpoint(checkpoint_id).checkpoint
        self._validate_parent_requirement(parent, parent_prefix_tokens)
        self.controller.signals.declare(
            checkpoint_id, consumer_id, after, self.clock(), requirement=requirement,
            condition_id=condition_id, condition_outcome=condition_outcome,
            parent_prefix_tokens=parent_prefix_tokens,
        )
        if self.queue_retention is not None:
            self.queue_retention.invalidate()
        if self.controller.policy == "semantic_naive_pin":
            self.reevaluate()

    def declare_no_gpu_consumers(self, checkpoint_id: str) -> None:
        self._get_open_checkpoint(checkpoint_id)
        self.controller.signals.declare_no_consumers(checkpoint_id, self.clock())
        if self.queue_retention is not None:
            self.queue_retention.invalidate()
        self.reevaluate()

    def decide_condition(self, condition_id: str, outcome: bool) -> None:
        self.controller.signals.decide_condition(condition_id, outcome, self.clock())
        if self.queue_retention is not None:
            self.queue_retention.invalidate()
        if self.controller.policy == "semantic_naive_pin":
            self.reevaluate()

    def cancel_gpu_consumer(self, consumer_id: str) -> None:
        self.controller.signals.cancel(consumer_id, self.clock())
        self._model_intents.pop(self.controller.signals.consumers[consumer_id].checkpoint_id, None)
        if self.queue_retention is not None:
            self.queue_retention.invalidate()
        if self.controller.policy == "semantic_naive_pin":
            self.reevaluate()

    def _future_prefixes(self) -> frozenset[BlockKey]:
        started = time.perf_counter()
        manager = self.kv_cache_manager
        pool = manager.block_pool
        preferred: set[BlockKey] = set()
        now = self.clock()
        for checkpoint_id, lease in self._checkpoints.items():
            if not lease.handle_open:
                continue
            groups, tokens, _ = manager.coordinator.find_longest_cache_hit(
                lease.block_hashes, lease.checkpoint.shared_tokens,
            )
            keys = {
                (b.block_id, b.block_hash) for group in groups for b in group
                if not b.is_null and b.block_hash is not None and b.ref_cnt == 0
            }
            if self.controller.policy == "semantic_future_only":
                consumers = self.controller.definite_future(checkpoint_id)
                eligible = bool(consumers)
                details = {
                    "checkpoint_id": checkpoint_id, "consumer_ids": consumers,
                    "reason": "declared_definite_future" if eligible else "no_definite_future",
                    "cached_tokens": tokens,
                }
            else:
                pressure = 1 - pool.get_num_free_blocks() / max(1, len(pool.blocks) - 1)
                decision = self.controller.future_preference(
                    checkpoint_id, tokens, now, pressure, len(self.waiting),
                )
                eligible = decision.reason == "positive_apc_loss_proxy"
                details = asdict(decision)
            added = keys - preferred if eligible else set()
            preferred.update(added)
            self._preference_decisions.append({
                "at": now, "kind": "future", **details,
                "estimates": [
                    {"consumer_id": c.consumer_id, **asdict(c.readiness_estimate)}
                    for c in self.controller.signals.consumers.values()
                    if c.checkpoint_id == checkpoint_id and c.state in {"declared", "ready"}
                    and c.readiness_estimate is not None
                ],
                "cached_free_identity": [(i, h.hex() if isinstance(h, bytes) else str(h)) for i, h in sorted(keys)],
                "unique_contribution_blocks": len(added),
                "preferred": bool(added), "retention_owner_blocks": 0,
                "physical_blocks_freed": 0,
            })
        self.preference_provider_cpu_seconds += time.perf_counter() - started
        return frozenset(preferred)

    @staticmethod
    def _validate_parent_requirement(parent: Checkpoint, tokens: int | None) -> None:
        if tokens is not None and (
            type(tokens) is not int or not 0 <= tokens <= len(parent.logical_token_ids)
        ):
            raise ValueError("declared parent prefix must be within the checkpoint")

    def _b6_future_prefixes(self) -> tuple[BlockKey, ...]:
        started = time.perf_counter()
        if self._future_prefix_cache is not None:
            result = self._future_prefix_cache.snapshot()
            self.preference_provider_cpu_seconds += time.perf_counter() - started
            return result
        # Queue-only policy exposes this diagnostic, but never calls it on a draw.
        assert self.controller.policy == "b6_queue_aware"
        ordered = []
        for checkpoint_id, lease in self._checkpoints.items():
            if not lease.handle_open:
                continue
            consumers = self.controller.definite_future(checkpoint_id)
            required = max((
                len(lease.checkpoint.logical_token_ids) if c.parent_prefix_tokens is None
                else c.parent_prefix_tokens
                for identity in consumers
                for c in (self.controller.signals.consumers[identity],)
            ), default=0)
            groups, tokens, _ = self.kv_cache_manager.coordinator.find_longest_cache_hit(
                lease.block_hashes, min(required, lease.checkpoint.shared_tokens),
            )
            for group in groups:
                for depth, block in enumerate(group):
                    if not block.is_null and block.block_hash is not None and block.ref_cnt == 0:
                        ordered.append((depth, checkpoint_id, (block.block_id, block.block_hash)))
            self._preference_decisions.append({
                "at": self.clock(), "kind": "b6_future", "checkpoint_id": checkpoint_id,
                "consumer_ids": consumers, "required_parent_tokens": required,
                "cached_tokens": tokens, "retention_owner_blocks": 0,
            })
        self.preference_provider_cpu_seconds += time.perf_counter() - started
        return tuple(dict.fromkeys(key for _, _, key in sorted(ordered)))

    def _b6_queued_prefixes(self) -> frozenset[BlockKey]:
        manager = self.kv_cache_manager
        keys = set()
        cached = []
        cache = self._future_prefix_cache
        # The registry also includes native step-local skipped requests. Never
        # change their status/order or ask a connector for remote cache state.
        for request in self.requests.values():
            if request.status not in {
                RequestStatus.WAITING, RequestStatus.PREEMPTED,
                RequestStatus.WAITING_FOR_STRUCTURED_OUTPUT_GRAMMAR,
            }:
                continue
            if request.num_stale_output_tokens and not request.drop_stale_output:
                continue
            if not manager.prefix_cache_lookup_enabled(request):
                continue
            if cache is not None and request.request_id in self._request_bindings:
                cached.append(cache.queued_prefix(request))
                continue
            groups, _, _ = manager.coordinator.find_longest_cache_hit(
                request.block_hashes, request.num_tokens - 1,
            )
            keys.update(
                (b.block_id, b.block_hash) for group in groups for b in group
                if not b.is_null and b.block_hash is not None and b.ref_cnt == 0
            )
        return cache.ready_snapshot(cached, keys) if cache is not None else frozenset(keys)

    def _b7_order_future(self, baseline, cap):
        from octopus.horizon import forecast, order_keys
        now = self.clock()
        signals = self.controller.signals
        eligible = set(baseline)
        if self.controller.calibration is not None:
            raise ValueError("B7 has no external calibration or cross-trace training")
        waiting = sum(r.status in {
            RequestStatus.WAITING, RequestStatus.PREEMPTED,
            RequestStatus.WAITING_FOR_STRUCTURED_OUTPUT_GRAMMAR,
        } for r in self.requests.values())
        horizons, records = {}, []
        for checkpoint_id, lease in self._checkpoints.items():
            if not lease.handle_open:
                continue
            for identity in self.controller.definite_future(checkpoint_id):
                consumer = signals.consumers[identity]
                record = forecast(signals, consumer, now, waiting)
                records.append(record)
                if record["status"] != "valid":
                    continue
                required = consumer.parent_prefix_tokens
                required = len(lease.checkpoint.logical_token_ids) if required is None else required
                groups, _, _ = self.kv_cache_manager.coordinator.find_longest_cache_hit(
                    lease.block_hashes, min(required, lease.checkpoint.shared_tokens),
                )
                for group in groups:
                    for block in group:
                        key = (block.block_id, block.block_hash)
                        if key in eligible:
                            horizons[key] = min(horizons.get(key, float("inf")), record["adoption_at"])
        result, evidence = order_keys(baseline, horizons, cap)
        evidence["forecasts"] = records
        return result, evidence

    def _running_prefill_commitment(self, native_draw: int) -> dict:
        manager = self.kv_cache_manager
        current = self._current_allocation_request
        requests = self._inflight_prefills | ({current} if current is not None else set())
        rows = []
        for request in sorted(requests, key=lambda r: r.request_id):
            if ((request is not current and request.status != RequestStatus.RUNNING)
                    or request.num_computed_tokens >= request.num_prompt_tokens):
                continue
            target = min(request.num_prompt_tokens, self.max_model_len)
            remaining = manager.coordinator.get_num_blocks_to_allocate(
                request_id=request.request_id,
                num_tokens=target,
                new_computed_blocks=manager.empty_kv_cache_blocks.blocks,
                num_encoder_tokens=0,
                total_computed_tokens=request.num_computed_tokens,
                num_local_computed_tokens=request.num_computed_tokens,
                num_tokens_main_model=target,
                apply_admission_cap=True,
            )
            covered = min(native_draw, remaining) if request is current else 0
            rows.append({
                "request_id": request.request_id, "prompt_tokens": request.num_prompt_tokens,
                "computed_tokens": request.num_computed_tokens,
                "request_status": request.status.name, "current_committing": request is current,
                "unallocated_prompt_blocks": remaining, "covered_by_current_draw": covered,
                "additional_blocks": remaining - covered,
            })
        return {
            "scope": "RUNNING plus current committing prompt at native draw; other waiting/future requests excluded; allocated/reused/pending slots deducted",
            "additional_blocks": sum(r["additional_blocks"] for r in rows),
            "requests": rows,
        }

    def _observe_allocation(self, allocate: Any, args: tuple, kwargs: dict) -> KVCacheBlocks | None:
        started = time.perf_counter()
        # Native readiness and cache identity may change within a schedule batch.
        if self.queue_retention is not None:
            self.queue_retention.invalidate()
        params = self._allocation_signature.bind(*args, **kwargs)
        params.apply_defaults()
        values = dict(params.arguments)
        request = values.pop("request")
        self._current_allocation_request = request
        computed = values.pop("new_computed_blocks")
        values["new_computed_blocks"] = (
            [[block_identity(b) for b in group] for group in computed.blocks]
            if computed is not None else None
        )
        pool = self.kv_cache_manager.block_pool
        before = pool.get_num_free_blocks()
        observer = self.eviction_observer
        observer.identities = []
        draw_start = len(self.queue_retention.draw_records) if isinstance(self.queue_retention, B6Retention) else 0
        native_draw = 0
        native_get_new = None
        if self.controller.policy == "apc":
            native_get_new = pool.get_new_blocks
            def count_native_draw(num_blocks):
                nonlocal native_draw
                native_draw += num_blocks
                return native_get_new(num_blocks)
            pool.get_new_blocks = count_native_draw
        try:
            result = allocate(*args, **kwargs)
            if isinstance(self.queue_retention, B6Retention):
                for draw in self.queue_retention.draw_records[draw_start:]:
                    draw.metadata.update(request_id=request.request_id, at=self.clock())
            ready = (self.queue_retention._preferred or frozenset()) if self.queue_retention else frozenset()
            future = self.queue_retention._future if self.queue_retention else frozenset()
            draws = self.queue_retention.draw_records[draw_start:] if isinstance(self.queue_retention, B6Retention) else []
            self._preference_decisions.append(PreferenceAudit(
                self.clock(), request.request_id, ready, future, self._last_preferred,
                self.queue_retention is not None and self.queue_retention._preferred is not None,
                draws,
            ))
            self._last_preferred = (ready, future)
            self.allocation_attempts.append(AllocationAttempt(
                len(self.allocation_attempts), request.request_id, self.clock(), values,
                before, pool.get_num_free_blocks(), result is not None,
                tuple(block_identity(b) for group in result.blocks for b in group) if result is not None else (),
                tuple(observer.identities),
                sum(d.native_draw for d in draws)
                if isinstance(self.queue_retention, B6Retention) and result is not None
                else native_draw if native_get_new is not None and result is not None else None,
            ))
            self._record_native_owner("native_allocate", request)
            return result
        finally:
            self._current_allocation_request = None
            if native_get_new is not None:
                pool.get_new_blocks = native_get_new
            observer.identities = None
            self.adapter_cpu_seconds += time.perf_counter() - started

    def _ready_waiting_prefixes(self) -> frozenset[BlockKey]:
        manager = self.kv_cache_manager
        preferred: set[BlockKey] = set()
        # Do not promote blocked requests, inspect skipped_waiting, or perform
        # connector I/O. Actual request order and admission remain native.
        for request in self.waiting:
            if request.status not in {RequestStatus.WAITING, RequestStatus.PREEMPTED}:
                continue
            if request.num_stale_output_tokens and not request.drop_stale_output:
                continue
            if not manager.prefix_cache_lookup_enabled(request):
                continue
            for consumer in self.controller.signals.consumers.values():
                if consumer.bound_request_id == request.request_id and consumer.runnable_at is None:
                    consumer.runnable_at = self.clock()
                    self.controller.signals._record(consumer, self.clock(), "native_runnable")
            groups, _, _ = manager.coordinator.find_longest_cache_hit(
                request.block_hashes, request.num_tokens - 1
            )
            preferred.update(
                (block.block_id, block.block_hash)
                for group in groups for block in group
                if not block.is_null and block.block_hash is not None
            )
        return frozenset(preferred)

    def observe(self, event: Event) -> None:
        self.controller.observe(event)
        self.lifecycle.append(asdict(event))
        if self.queue_retention is not None:
            self.queue_retention.invalidate()
        self.reevaluate()

    @property
    def next_policy_deadline(self) -> float | None:
        return min(
            (lease.expires_at for lease in self._checkpoints.values()
             if lease.lease_id is not None and lease.expires_at is not None),
            default=None,
        )

    def drop_checkpoint(self, checkpoint_id: str) -> None:
        lease = self._checkpoints[checkpoint_id]
        if lease.lease_id is not None:
            before = self.kv_cache_manager.block_pool.get_num_free_blocks()
            owner_id = lease.lease_id
            self.kv_cache_manager.coordinator.free(lease.lease_id)
            lease.lease_id = None
            lease.expires_at = None
            self.retention_revocations += 1
            self.lifecycle.append({
                "kind": "retention_drop", "at": self.clock(),
                "checkpoint_id": checkpoint_id, "owner_id": owner_id,
                "physical_blocks_freed": self.kv_cache_manager.block_pool.get_num_free_blocks() - before,
            })
        lease.offered = False
        self._track_retained()
        self._record_owners()

    def _record_native_owner(self, kind: str, request: Request) -> None:
        self.owner_changes.append({
            "kind": kind, "at": self.clock(), "request_id": request.request_id,
            "blocks": [] if kind == "native_free" else [
                block_identity(b)
                for group in self.kv_cache_manager.get_blocks(request.request_id).blocks
                for b in group if not b.is_null
            ],
        })
        self._record_owners()

    def _record_owners(self) -> None:
        now = self.clock()
        retention = {
            cp: self._block_set(lease) for cp, lease in self._checkpoints.items()
            if lease.lease_id is not None
        }
        counts = Counter(b for blocks in retention.values() for b in blocks)
        pool = self.kv_cache_manager.block_pool
        for cp in self._owner_state.keys() | retention.keys():
            blocks = retention.get(cp, frozenset())
            native = {b for b in blocks if pool.blocks[b].ref_cnt > counts[b]}
            other = {b for b in blocks if counts[b] > 1}
            state = {
                "retained_blocks": sorted(blocks),
                "native_shared_blocks": sorted(native),
                "other_retention_shared_blocks": sorted(other),
                "exclusive_releasable_blocks": sorted(blocks - native - other),
            }
            if self._owner_state.get(cp) != state:
                self.owner_changes.append({
                    "kind": "retention_ownership", "checkpoint_id": cp,
                    "at": now, **state,
                })
                self._owner_state[cp] = state

    def _track_retained(self) -> None:
        now = self.clock()
        self._retained_block_seconds += self._retained_count * (now - self._retained_since)
        self._retained_since = now
        self._retained_count = len(set().union(*(
            self._block_set(lease) for lease in self._checkpoints.values()
            if lease.lease_id is not None
        )))

    @property
    def unique_retained_block_seconds(self) -> float:
        return self._retained_block_seconds + self._retained_count * (self.clock() - self._retained_since)

    def _physical_owners(self) -> tuple[Counter, frozenset[int]]:
        retention: Counter = Counter()
        for lease in self._checkpoints.values():
            if lease.lease_id is not None:
                retention.update(self._block_set(lease))
        request_blocks = frozenset(
            block.block_id for block in self.kv_cache_manager.block_pool.blocks
            if not block.is_null and block.ref_cnt > retention[block.block_id]
        )
        return retention, request_blocks

    @staticmethod
    def _block_set(lease: _CheckpointLease) -> frozenset[int]:
        return frozenset(
            block.block_id for group in lease.blocks.blocks for block in group
            if not block.is_null
        )

    def admission_snapshot(self, *, allocation_failed: bool = False) -> Snapshot:
        now = self.clock()
        _, request_blocks = self._physical_owners()
        queued: dict[str, tuple[str, ...]] = {}
        waiting = list(self.waiting)
        for checkpoint_id, lease in self._checkpoints.items():
            # Queue-only baseline can inspect actual queued prefixes, including
            # requests without an explicit Octopus binding.
            queued[checkpoint_id] = tuple(
                request.request_id for request in waiting
                if tuple(request.prompt_token_ids[:lease.checkpoint.shared_tokens])
                == lease.checkpoint.logical_token_ids[:lease.checkpoint.shared_tokens]
                and lease.checkpoint.shared_tokens > 0
            )
        return Snapshot(
            candidates=tuple(
                Candidate(
                    checkpoint_id, self._block_set(lease),
                    lease.checkpoint.shared_tokens, lease.offered_at,
                    lease.expires_at, lease.lease_id is not None,
                )
                for checkpoint_id, lease in self._checkpoints.items()
                if lease.lease_id is not None or lease.offered
            ),
            request_blocks=request_blocks,
            total_blocks=len(self.kv_cache_manager.block_pool.blocks) - 1,
            free_blocks=self.kv_cache_manager.block_pool.get_num_free_blocks(),
            queued_reuse=queued,
            waiting_tokens=sum(r.num_tokens - r.num_computed_tokens for r in waiting),
            oldest_wait_seconds=max(
                (max(0.0, time.time() - r.arrival_time) for r in waiting), default=0.0
            ),
            allocation_failed=allocation_failed,
        )

    def reevaluate(self) -> None:
        from dataclasses import asdict

        now = self.clock()
        if self.controller.policy in NO_LEASE_POLICIES:
            if self.queue_retention is not None:
                self.queue_retention.invalidate()
            return
        if self.controller.policy == "semantic_naive_pin":
            for cp, lease in self._checkpoints.items():
                if lease.lease_id is not None or lease.offered or not self.controller.definite_future(cp):
                    continue
                groups, tokens, _ = self.kv_cache_manager.coordinator.find_longest_cache_hit(
                    lease.block_hashes, lease.checkpoint.shared_tokens,
                )
                # The legacy lease adoption interface requires the full frontier.
                if tokens == lease.checkpoint.shared_tokens and tokens > 0:
                    lease.blocks = KVCacheBlocks(groups)
                    lease.offered = True
                    lease.offered_at = now
        plan = self.controller.decide(self.admission_snapshot(), now)
        for action in plan.actions:
            lease = self._checkpoints[action.checkpoint_id]
            if action.action == "DROP":
                self.drop_checkpoint(action.checkpoint_id)
            elif lease.checkpoint.shared_tokens:
                if lease.lease_id is None and lease.offered:
                    lease.lease_id = f"octopus-lease:{action.checkpoint_id}"
                    self.kv_cache_manager.coordinator.allocate_new_computed_blocks(
                        lease.lease_id, lease.blocks.blocks,
                        lease.checkpoint.shared_tokens, 0,
                    )
                    self._track_retained()
                    self.lifecycle.append({
                        "kind": "retention_acquire", "checkpoint_id": action.checkpoint_id,
                        "at": self.clock(), "owner_id": lease.lease_id,
                        "blocks": sorted(self._block_set(lease)),
                    })
                    self._record_owners()
                lease.expires_at = action.expires_at
            lease.offered = False
        if plan.actions:
            self.policy_decisions.append({"at": now, **asdict(plan)})

    def _reclaim_for_allocation(self) -> bool:
        if self.controller.policy in NO_LEASE_POLICIES | {"hard_pin", "semantic_naive_pin"}:
            return False
        snapshot = self.admission_snapshot(allocation_failed=True)
        if not snapshot.candidates:
            return False
        now = self.clock()
        plan = self.controller.decide(snapshot, now)
        ranked = sorted(
            plan.actions,
            key=lambda a: (
                a.benefit_seconds - a.memory_seconds - a.risk_seconds,
                a.checkpoint_id,
            ),
        )
        for action in ranked:
            lease = self._checkpoints[action.checkpoint_id]
            if lease.lease_id is not None:
                before = self.kv_cache_manager.block_pool.get_num_free_blocks()
                self.drop_checkpoint(action.checkpoint_id)
                self.allocation_retries += 1
                self.policy_decisions.append({
                    "at": now, "checkpoint_id": action.checkpoint_id,
                    "action": "DROP", "reason": "native_allocation_rejected",
                    "reclaimed_blocks": (
                        self.kv_cache_manager.block_pool.get_num_free_blocks() - before
                    ),
                })
                return True
        return False

    def register_checkpoint_capture(
        self, request_id: str, checkpoint_id: str, capture_intent: CheckpointIntent | None = None,
    ) -> None:
        if request_id not in self.requests:
            raise KeyError(f"request {request_id!r} is not registered")
        if checkpoint_id in self._checkpoints:
            raise ValueError(f"checkpoint {checkpoint_id!r} already exists")
        if capture_intent is not None:
            # A capture cannot have a shorter logical sequence than its prompt.
            # The final exact upper bound is checked at capture, before intent registration.
            for consumer in capture_intent.consumers:
                tokens = consumer.parent_prefix_tokens
                if tokens is not None and tokens > (
                    self.requests[request_id].num_prompt_tokens
                    + self.requests[request_id].sampling_params.max_tokens
                ):
                    raise ValueError("declared parent prefix exceeds capture output limit")
        self._capture_request_ids[request_id] = checkpoint_id
        if capture_intent is not None:
            self._capture_intents[request_id] = capture_intent

    def bind_request_to_checkpoint(
        self, request_id: str, checkpoint_id: str,
        consumer_id: str | None = None, external_request_id: str | None = None,
        *, selected_parent_tokens: int | None = None, capsule_tokens: int = 0,
    ) -> None:
        if request_id not in self.requests:
            raise KeyError(f"request {request_id!r} is not registered")
        if request_id in self._request_bindings:
            raise ValueError(f"request {request_id!r} is already bound")
        lease = self._get_open_checkpoint(checkpoint_id)
        parent = lease.checkpoint
        selected = len(parent.logical_token_ids) if selected_parent_tokens is None else selected_parent_tokens
        prompt = self.requests[request_id].prompt_token_ids
        if (not 0 <= selected <= len(parent.logical_token_ids)
                or tuple(prompt[:selected]) != parent.logical_token_ids[:selected]
                or capsule_tokens < 0 or selected + capsule_tokens > len(prompt)):
            raise ValueError("selected parent must be an exact token prefix with valid capsule length")
        if (selected != len(parent.logical_token_ids) or capsule_tokens) and self.controller.policy not in SELECTIVE_POLICIES:
            raise ValueError("selective inheritance requires retention_policy='apc' or a B6 policy")
        if consumer_id is not None:
            declared = self.controller.signals.consumers[consumer_id].parent_prefix_tokens
            required = len(parent.logical_token_ids) if declared is None else declared
            if required != selected:
                raise ValueError("submitted parent prefix differs from declared requirement")
        consumer = self.controller.signals.bind(
            checkpoint_id, consumer_id, request_id, external_request_id or request_id, self.clock(),
        )
        metrics = self._metrics_for(self.requests[request_id])
        metrics.consumer_id = consumer.consumer_id
        metrics.enqueued_at = consumer.enqueued_at
        metrics.selected_parent_tokens = selected
        metrics.capsule_tokens = capsule_tokens
        metrics.parent_checkpoint_id = checkpoint_id
        metrics.checkpoint_frontier_tokens = min(
            parent.shared_tokens, selected // parent.block_size * parent.block_size,
        )
        lease.bound_request_ids.add(request_id)
        self._request_bindings[request_id] = checkpoint_id
        if self.queue_retention is not None:
            self.queue_retention.invalidate()
        if self.controller.policy == "semantic_naive_pin":
            self.reevaluate()

    def get_checkpoint_for_request(self, request_id: str) -> Checkpoint:
        checkpoint_id = self._checkpoint_ids_by_request.get(request_id)
        if checkpoint_id is None:
            raise KeyError(f"request {request_id!r} did not produce a checkpoint")
        return self._checkpoints[checkpoint_id].checkpoint

    def get_checkpoint(self, checkpoint_id: str) -> Checkpoint:
        return self._checkpoints[checkpoint_id].checkpoint

    def release_checkpoint(self, checkpoint_id: str) -> None:
        lease = self._checkpoints.get(checkpoint_id)
        if lease is None:
            raise KeyError(f"unknown checkpoint {checkpoint_id!r}")
        if not lease.handle_open:
            raise ValueError(f"checkpoint {checkpoint_id!r} was already released")
        lease.handle_open = False
        self._model_intents.pop(checkpoint_id, None)
        event = Event("release", checkpoint_id, self.clock())
        self.controller.observe(event)
        self.lifecycle.append(asdict(event))
        if self.queue_retention is not None:
            self.queue_retention.invalidate()
        if self.controller.policy != "hard_pin":
            self.drop_checkpoint(checkpoint_id)
        self._maybe_free_checkpoint(checkpoint_id)

    def release_all_checkpoints(self) -> None:
        for checkpoint_id, lease in list(self._checkpoints.items()):
            if lease.handle_open:
                self.release_checkpoint(checkpoint_id)
            else:
                self._maybe_free_checkpoint(checkpoint_id)
        if self._checkpoints:
            owners = {
                checkpoint_id: sorted(lease.bound_request_ids)
                for checkpoint_id, lease in self._checkpoints.items()
            }
            raise RuntimeError(f"checkpoint bindings remain during shutdown: {owners}")

    def request_metrics(self, request_id: str) -> RequestMetrics:
        return self._request_metrics[request_id]

    def pool_snapshot(self) -> PoolSnapshot:
        block_pool = self.kv_cache_manager.block_pool
        active = sum(
            block.ref_cnt > 0 and not block.is_null for block in block_pool.blocks
        )
        warm = sum(
            block.ref_cnt == 0
            and block.block_hash is not None
            and not block.is_null
            for block in block_pool.blocks
        )
        retention, request_blocks = self._physical_owners()
        retention_only = set(retention) - request_blocks
        return PoolSnapshot(
            active_blocks=active,
            warm_cached_blocks=warm,
            free_blocks=block_pool.get_num_free_blocks(),
            total_blocks=len(block_pool.blocks) - 1,
            request_owned_blocks=len(request_blocks),
            retention_only_blocks=len(retention_only),
            shared_request_retention_blocks=len(set(retention) & request_blocks),
            cold_free_blocks=block_pool.get_num_free_blocks() - warm,
        )

    @property
    def active_blocks_peak(self) -> int:
        return self._active_blocks_peak

    @property
    def request_owned_blocks_peak(self) -> int:
        return self._request_owned_blocks_peak

    def reset_phase_peak(self) -> None:
        snapshot = self.pool_snapshot()
        self._active_blocks_peak = snapshot.active_blocks
        self._request_owned_blocks_peak = snapshot.request_owned_blocks

    def begin_measurement(self) -> None:
        self.reset_phase_peak()
        self._retained_block_seconds = 0.0
        self._retained_since = self.clock()
        self.eviction_observer.evictions = 0
        self.policy_decisions.clear()
        self._preference_decisions.clear()
        self.allocation_attempts.clear()
        self.adoptions.clear()
        self.lifecycle[:] = [
            row for row in self.lifecycle
            if row["checkpoint_id"] in self._checkpoints
            and row["kind"] in {"capture", "resolve", "release"}
        ]
        self.owner_changes.clear()
        self._owner_state.clear()
        self._record_owners()
        self.controller.signals.consumer_records.clear()
        self.adapter_cpu_seconds = 0.0
        self.preference_provider_cpu_seconds = 0.0
        self.audit_decode_cpu_seconds = 0.0
        if self._future_prefix_cache is not None:
            self._future_prefix_cache.maintenance_cpu_seconds = 0.0
        if self.committed_adoption_callback is not None:
            self.value_admission.maintenance_cpu_seconds = 0.0
        if self.queue_retention is not None:
            self.queue_retention.begin_measurement()

    def has_checkpoint(self, checkpoint_id: str) -> bool:
        return checkpoint_id in self._checkpoints

    def _get_local_prefix_cache_hit(
        self, request: Request
    ) -> tuple[KVCacheBlocks, int, int, bool]:
        checkpoint_id = self._request_bindings.get(request.request_id)
        if checkpoint_id is not None and request.num_computed_tokens == 0:
            lease = self._checkpoints[checkpoint_id]
            self.controller.observe(Event(
                "reuse", checkpoint_id, self.clock(), node_id=request.request_id
            ))
            if lease.lease_id is not None:
                metrics = self._metrics_for(request)
                metrics.inherited_tokens = max(
                    metrics.inherited_tokens, lease.checkpoint.shared_tokens
                )
                return (lease.blocks, lease.checkpoint.shared_tokens, 0, False)

        result = super()._get_local_prefix_cache_hit(request)
        metrics = self._metrics_for(request)
        metrics.inherited_tokens = max(metrics.inherited_tokens, result[1])
        if checkpoint_id is not None:
            lease = self._checkpoints[checkpoint_id]
            if (
                lease.handle_open and lease.lease_id is None
                and metrics.checkpoint_frontier_tokens == lease.checkpoint.shared_tokens
                and self.controller.policy not in NO_LEASE_POLICIES
                and result[1] >= lease.checkpoint.shared_tokens > 0
            ):
                lease.blocks = self.kv_cache_manager.truncate_computed_blocks(
                    result[0], lease.checkpoint.shared_tokens
                )
                lease.offered = True
                lease.offered_at = self.clock()
                self.lifecycle.append({
                    "kind": "reoffer", "at": lease.offered_at, "checkpoint_id": checkpoint_id,
                })
                self.reevaluate()
        return result

    def schedule(self, *args: Any, **kwargs: Any):
        if self.queue_retention is not None:
            self.queue_retention.invalidate()
        if self.controller.policy != "hard_pin":
            self.reevaluate()
        output = super().schedule(*args, **kwargs)
        for request_id, scheduled_tokens in output.num_scheduled_tokens.items():
            request = self.requests[request_id]
            self._record_scheduled(request, scheduled_tokens)

        snapshot = self.pool_snapshot()
        self._active_blocks_peak = max(
            self._active_blocks_peak, snapshot.active_blocks
        )
        self._request_owned_blocks_peak = max(
            self._request_owned_blocks_peak, snapshot.request_owned_blocks,
        )
        return output

    def _record_scheduled(self, request: Request, scheduled_tokens: int) -> None:
        if scheduled_tokens <= 0:
            return
        metrics = self._metrics_for(request)
        end = request.num_computed_tokens
        start = end - scheduled_tokens
        event_key = request.num_preemptions, start, end
        if metrics.last_scheduled_event == event_key:
            return
        metrics.last_scheduled_event = event_key
        now = self.clock()
        adoption = (
            min(start, request.num_prompt_tokens)
            if metrics.first_scheduled_at is None or request.num_preemptions > metrics.preemptions
            else None
        )
        if scheduled_tokens > 0:
            if metrics.first_scheduled_at is None:
                checkpoint_id = self._request_bindings.get(request.request_id)
                if checkpoint_id is not None:
                    self._model_intents.pop(checkpoint_id, None)
                metrics.first_scheduled_at = now
                metrics.adopted_prefix_tokens = min(start, request.num_prompt_tokens)
            self.controller.signals.adopted(request.request_id, now)
            committed = ActualAdoption(
                now, request.request_id, metrics.consumer_id,
                self._request_bindings.get(request.request_id), metrics.checkpoint_frontier_tokens,
                metrics.inherited_tokens, adoption,
                (start, end), request.num_preemptions,
                tuple(
                    tuple(block_identity(b) for b in group[:adoption // self.block_size])
                    for group in self.kv_cache_manager.get_blocks(request.request_id).blocks
                ) if adoption is not None else None,
            )
            if self.committed_adoption_callback is not None:
                self.committed_adoption_callback(request, committed)
            for observer in self.committed_schedule_observers:
                observer(request, committed)
            if self.adoption_audit_enabled:
                self.adoptions.append(committed)
        metrics.scheduled_ranges.append((start, end))
        prompt_end = request.num_prompt_tokens
        metrics.actual_prefill_tokens += max(0, min(end, prompt_end) - min(start, prompt_end))
        metrics.actual_decode_tokens += max(0, end - max(start, prompt_end))
        metrics.preemptions = request.num_preemptions

    def _free_request(
        self, request: Request, delay_free_blocks: bool = False
    ) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
        request_id = request.request_id
        checkpoint_id = self._capture_request_ids.pop(request_id, None)
        if checkpoint_id is not None and request.status in {
            RequestStatus.FINISHED_STOPPED,
            RequestStatus.FINISHED_LENGTH_CAPPED,
        }:
            self._capture_checkpoint(request, checkpoint_id)
        else:
            self._capture_intents.pop(request_id, None)

        metrics = self._metrics_for(request)
        metrics.preemptions = request.num_preemptions
        metrics.finish_status = request.status.name
        self.controller.signals.finish_request(
            request_id, self.clock(),
            "complete" if request.status in {
                RequestStatus.FINISHED_STOPPED, RequestStatus.FINISHED_LENGTH_CAPPED,
            } else "cancelled" if request.status == RequestStatus.FINISHED_ABORTED else "failed",
        )
        result = super()._free_request(request, delay_free_blocks=delay_free_blocks)
        self._release_request_binding(request_id)
        return result

    def _capture_checkpoint(self, request: Request, checkpoint_id: str) -> None:
        logical_token_ids = tuple(request.all_token_ids)
        computed_tokens = min(request.num_computed_tokens, len(logical_token_ids))
        shared_tokens = computed_tokens // self.block_size * self.block_size
        blocks = self.kv_cache_manager.truncate_computed_blocks(
            self.kv_cache_manager.get_blocks(request.request_id),
            shared_tokens,
        )
        checkpoint = Checkpoint(
            checkpoint_id=checkpoint_id,
            logical_token_ids=logical_token_ids,
            shared_tokens=shared_tokens,
            tail_token_ids=logical_token_ids[shared_tokens:],
            block_ids=tuple(tuple(ids) for ids in blocks.get_block_ids()),
            block_size=self.block_size,
        )
        now = self.clock()
        intent = self._capture_intents.pop(request.request_id, None)
        if intent is not None:
            for consumer in intent.consumers:
                self._validate_parent_requirement(checkpoint, consumer.parent_prefix_tokens)
            self.controller.signals.register_intent(checkpoint_id, intent, now)
        self._checkpoints[checkpoint_id] = _CheckpointLease(
            checkpoint=checkpoint,
            blocks=blocks,
            lease_id=None,
            captured_at=now,
            offered_at=now,
            offered=self.controller.policy not in NO_LEASE_POLICIES,
            block_hashes=tuple(request.block_hashes),
        )
        self.controller.observe(Event(
            "capture", checkpoint_id, self.clock(),
            parent_id=self._request_bindings.get(request.request_id),
        ))
        self.lifecycle.append({
            "kind": "capture", "at": now, "checkpoint_id": checkpoint_id,
            "parent_id": self._request_bindings.get(request.request_id),
            "request_id": request.request_id, "shared_tokens": shared_tokens,
            "block_ids": checkpoint.block_ids,
            "intent": asdict(intent) if intent is not None else None,
        })
        self.reevaluate()
        self._checkpoint_ids_by_request[request.request_id] = checkpoint_id

    def _release_request_binding(self, request_id: str) -> None:
        checkpoint_id = self._request_bindings.pop(request_id, None)
        if checkpoint_id is None:
            return
        if self._request_metrics[request_id].first_scheduled_at is None:
            self._model_intents.pop(checkpoint_id, None)
        if self._future_prefix_cache is not None:
            self._future_prefix_cache.release_queued(request_id)
        lease = self._checkpoints[checkpoint_id]
        lease.bound_request_ids.remove(request_id)
        self._maybe_free_checkpoint(checkpoint_id)

    def _maybe_free_checkpoint(self, checkpoint_id: str) -> None:
        lease = self._checkpoints[checkpoint_id]
        if lease.handle_open or lease.bound_request_ids:
            return
        if lease.lease_id is not None:
            self.drop_checkpoint(checkpoint_id)
        del self._checkpoints[checkpoint_id]

    def _get_open_checkpoint(self, checkpoint_id: str) -> _CheckpointLease:
        lease = self._checkpoints.get(checkpoint_id)
        if lease is None:
            raise KeyError(f"unknown checkpoint {checkpoint_id!r}")
        if not lease.handle_open:
            raise ValueError(f"checkpoint {checkpoint_id!r} was released")
        return lease

    def _metrics_for(self, request: Request) -> RequestMetrics:
        metrics = self._request_metrics.setdefault(
            request.request_id,
            RequestMetrics(prompt_tokens=request.num_prompt_tokens),
        )
        return metrics


class VllmBackend:
    def __init__(self, config: BackendConfig) -> None:
        if config.retention_policy == "b6_model_intent" and not config.enable_prefix_caching:
            raise ValueError("b6_model_intent requires prefix caching")
        # Fail before allocating a model if the new policy is not calibrated.
        Controller(config.retention_policy, config.admission_calibration)
        os.environ["VLLM_ENABLE_V1_MULTIPROCESSING"] = "0"
        self.config = config
        model_path = (
            config.model_path
            or os.environ.get("OCTOPUS_MODEL_PATH")
            or config.model
        )
        self.model_path = model_path
        engine_args = EngineArgs(
            model=model_path,
            tokenizer=config.tokenizer_path,
            dtype=config.dtype,
            max_model_len=config.max_model_len,
            max_num_seqs=config.max_num_seqs,
            max_num_batched_tokens=config.max_num_batched_tokens,
            block_size=config.block_size,
            kv_cache_memory_bytes=config.kv_cache_memory_bytes,
            gpu_memory_utilization=config.gpu_memory_utilization,
            enable_prefix_caching=config.enable_prefix_caching,
            enable_chunked_prefill=config.enable_chunked_prefill,
            enforce_eager=config.enforce_eager,
            async_scheduling=config.async_scheduling,
            scheduler_cls=OctopusScheduler,
            seed=config.seed,
            disable_log_stats=config.disable_log_stats,
            structured_outputs_config=StructuredOutputsConfig(
                backend="xgrammar", disable_any_whitespace=True
            ),
        )
        self.engine = LLMEngine.from_engine_args(
            engine_args,
            enable_multiprocessing=False,
        )
        self.scheduler = self._get_scheduler()
        self.scheduler.configure_admission(
            config.retention_policy, config.admission_calibration,
            value_hidden_size=(self.engine.model_config.hf_config.hidden_size
                               if config.retention_policy in {"b6_semantic_value", "b6_history_blanket"} else None),
            value_history_mode=config.value_history_mode,
            adoption_audit_enabled=config.adoption_audit_enabled,
        )
        self._external_request_ids: dict[str, str] = {}
        self._request_prompts: dict[str, tuple[int, ...]] = {}

    @property
    def capabilities(self) -> BackendCapabilities:
        return BackendCapabilities(
            prefix_reuse=self.config.enable_prefix_caching,
            selective_inheritance=(self.config.enable_prefix_caching
                                   and self.config.retention_policy in SELECTIVE_POLICIES),
            dynamic_intent=self.config.retention_policy == "b6_model_intent",
            inline_intent=True, native_work_counters=True,
        )

    def validate_inheritance(self, mode: InheritanceMode) -> None:
        if mode != InheritanceMode.FULL and not self.capabilities.selective_inheritance:
            raise ValueError("selective inheritance requires retention_policy='apc' or a B6 policy with prefix caching enabled")

    @staticmethod
    def _sampling(config: GenerationConfig) -> SamplingParams:
        structured = None
        if config.schema_json is not None or config.grammar is not None:
            structured = StructuredOutputsParams(json=config.schema_json, grammar=config.grammar)
        return SamplingParams(
            temperature=config.temperature, max_tokens=config.max_tokens,
            seed=config.seed, ignore_eos=config.ignore_eos, structured_outputs=structured,
        )

    def validate_generation(self, config: GenerationConfig, *,
                            capture_intent: CheckpointIntent | None = None) -> None:
        self._sampling(config)

    def validate_checkpoint(self, checkpoint: Checkpoint) -> None:
        owned = self.scheduler._get_open_checkpoint(checkpoint.checkpoint_id).checkpoint
        if owned is not checkpoint:
            raise ValueError("operation requires this backend's checkpoint handle")

    def get_checkpoint_for_request(self, request_id: str) -> Checkpoint:
        return self.scheduler.get_checkpoint_for_request(request_id)

    def get_checkpoint(self, checkpoint_id: str) -> Checkpoint:
        return self.scheduler.get_checkpoint(checkpoint_id)

    def checkpoint_is_open(self, checkpoint_id: str) -> bool:
        return (self.scheduler.has_checkpoint(checkpoint_id)
                and checkpoint_id not in self.scheduler.controller.signals.closed)

    def release_checkpoint(self, checkpoint: Checkpoint) -> None:
        self.validate_checkpoint(checkpoint)
        self.scheduler.release_checkpoint(checkpoint.checkpoint_id)

    def observe(self, event: Event) -> None:
        self.scheduler.observe(event)

    def declare_gpu_consumer(self, checkpoint_id, consumer_id, after, **kwargs) -> None:
        self.scheduler.declare_gpu_consumer(checkpoint_id, consumer_id, after, **kwargs)

    def declare_no_gpu_consumers(self, checkpoint_id: str) -> None:
        self.scheduler.declare_no_gpu_consumers(checkpoint_id)

    def decide_condition(self, condition_id: str, outcome: bool) -> None:
        self.scheduler.decide_condition(condition_id, outcome)

    def cancel_gpu_consumer(self, consumer_id: str) -> None:
        self.scheduler.cancel_gpu_consumer(consumer_id)

    def consumer_is_terminal(self, consumer_id: str) -> bool:
        return self.scheduler.controller.signals.consumers[consumer_id].terminal

    def apply_model_intents(self, intents: dict[str, ModelIntent], *,
                            producer_request_id: str | None = None) -> None:
        self.scheduler.apply_model_intents(intents)

    def clock(self) -> float:
        return self.scheduler.clock()

    def is_request_active(self, request_id: str) -> bool:
        return request_id in self.scheduler.requests

    def add_request(
        self,
        *,
        request_id: str,
        prompt_token_ids: list[int],
        sampling_params: SamplingParams | GenerationConfig,
        checkpoint_id: str | None = None,
        capture_checkpoint_id: str | None = None,
        consumer_id: str | None = None,
        capture_intent: CheckpointIntent | None = None,
        selected_parent_tokens: int | None = None,
        capsule_tokens: int = 0,
    ) -> str:
        if isinstance(sampling_params, GenerationConfig):
            sampling_params = self._sampling(sampling_params)
        if capture_intent is not None and capture_checkpoint_id is None:
            raise ValueError("capture intent requires an output checkpoint")
        if consumer_id is not None:
            if checkpoint_id is None:
                raise ValueError("consumer binding requires a checkpoint")
            self.scheduler.controller.signals.preparing(consumer_id, self.scheduler.clock())
        internal_request_id = self.engine.add_request(
            request_id=request_id,
            prompt={"prompt_token_ids": prompt_token_ids},
            params=sampling_params,
        )
        self._external_request_ids[internal_request_id] = request_id
        self._request_prompts[internal_request_id] = tuple(prompt_token_ids)
        try:
            if checkpoint_id is not None:
                self.scheduler.bind_request_to_checkpoint(
                    internal_request_id, checkpoint_id, consumer_id, request_id,
                    selected_parent_tokens=selected_parent_tokens, capsule_tokens=capsule_tokens,
                )
            if capture_checkpoint_id is not None:
                self.scheduler.register_checkpoint_capture(
                    internal_request_id, capture_checkpoint_id, capture_intent
                )
        except Exception:
            self.engine.abort_request([internal_request_id], internal=True)
            raise
        return internal_request_id

    def external_request_id(self, internal_request_id: str) -> str:
        return self._external_request_ids[internal_request_id]

    def step(self):
        """Legacy native outputs and diagnostics remain available."""
        return self.engine.step()

    def normalize_events(self, outputs) -> list[GenerationEvent]:
        reverse = {external: internal for internal, external in self._external_request_ids.items()}
        events = []
        for output in outputs:
            if isinstance(output, GenerationEvent):
                events.append(output)
                continue
            internal = reverse[output.request_id]
            completion = output.outputs[0]
            events.append(GenerationEvent(
                output.request_id, internal, self._request_prompts[internal],
                tuple(completion.token_ids), completion.text, output.finished,
                completion.finish_reason,
                cached_tokens=getattr(output, "num_cached_tokens", None),
            ))
        return events

    def poll(self) -> list[GenerationEvent]:
        return self.normalize_events(self.step())

    def abort(self, request_id: str) -> None:
        self.engine.abort_request([request_id], internal=True)

    def has_unfinished_requests(self) -> bool:
        return self.engine.has_unfinished_requests()

    def tokenize(self, text: str) -> list[int]:
        return self.engine.get_tokenizer().encode(text, add_special_tokens=False)

    def render_chat(
        self, messages: list[dict[str, Any]], *, tools: list[dict[str, Any]] | None = None,
        add_generation_prompt: bool = False,
    ) -> str:
        return self.engine.get_tokenizer().apply_chat_template(
            messages, tools=tools, tokenize=False,
            add_generation_prompt=add_generation_prompt,
        )

    def decode(self, token_ids: list[int] | tuple[int, ...]) -> str:
        return self.engine.get_tokenizer().decode(token_ids)

    def reset_prefix_cache(self) -> bool:
        return self.engine.engine_core.reset_prefix_cache()

    def environment_metadata(self) -> dict[str, Any]:
        model_config = self.engine.model_config
        hf_config = model_config.hf_config
        tokenizer = self.engine.get_tokenizer()
        tokenizer_revision = getattr(tokenizer, "init_kwargs", {}).get("_commit_hash")
        model_revision = getattr(hf_config, "_commit_hash", None)
        if model_revision is None and "/snapshots/" in self.model_path:
            model_revision = os.path.basename(self.model_path)
        tokenizer_path = self.config.tokenizer_path or self.model_path
        if tokenizer_revision is None and "/snapshots/" in tokenizer_path:
            tokenizer_revision = os.path.basename(tokenizer_path)
        elif tokenizer_revision is None and self.config.tokenizer_path is None:
            tokenizer_revision = model_revision
        return {
            "model_id": self.config.model,
            "model_revision": model_revision,
            "tokenizer_revision": tokenizer_revision,
            "tokenizer_path": tokenizer_path,
            "vllm_version": vllm.__version__,
            "device_name": torch.cuda.get_device_name(),
            "device_uuid": str(torch.cuda.get_device_properties(torch.cuda.current_device()).uuid),
            "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),
            "effective_engine_config": {
                "dtype": str(model_config.dtype),
                "max_model_len": model_config.max_model_len,
                "max_num_seqs": self.config.max_num_seqs,
                "max_num_batched_tokens": self.config.max_num_batched_tokens,
                "block_size": self.scheduler.block_size,
                "kv_cache_memory_bytes": self.config.kv_cache_memory_bytes,
                "enable_prefix_caching": self.config.enable_prefix_caching,
                "enable_chunked_prefill": self.config.enable_chunked_prefill,
                "enforce_eager": self.config.enforce_eager,
                "async_scheduling": self.config.async_scheduling,
                "structured_outputs_backend": "xgrammar",
                "structured_outputs_disable_any_whitespace": True,
                "retention_policy": self.config.retention_policy,
                "retention_implementation": (
                    "prefix-caching-disabled" if not self.config.enable_prefix_caching
                    else "model-intent-criticality-expected-importance-budgeted-free-prefix-no-lease"
                    if self.config.retention_policy == "b6_model_intent"
                    else f"{self.config.retention_policy}-local-queued-definite-prefix-per-draw-no-lease"
                    if self.config.retention_policy in SEMANTIC_PREFIX_POLICIES
                    else "local-semantic-ready-future-free-lru-no-reservation"
                    if self.config.retention_policy == "semantic_soft"
                    else "local-definite-future-ready-free-lru-no-estimates"
                    if self.config.retention_policy == "semantic_future_only"
                    else "local-ready-waiting-free-lru-no-reservation"
                    if self.config.retention_policy == "queue_aware"
                    else "local-full-attention-second-hit-lease"
                    if self.config.retention_policy == "frequency"
                    else "stock-dense-apc-lru"
                    if self.config.retention_policy == "apc"
                    else "local-checkpoint-lease-policy"
                ),
                "upstream_vllm_tag_commit": "2cf0a6915ce544dc493a0990f2ea38d81601128a",
                "admission_calibration_id": (
                    self.config.admission_calibration.calibration_id
                    if self.config.admission_calibration else None
                ),
            },
            "kv_block_bytes": self._kv_block_bytes(),
            "semantic_value_cost": {
                "formula": "W_D(t)=D*t+t*(t+1)/2",
                "hidden_size": hf_config.hidden_size,
                "units": "analytic normalized prefill-work proxy; not measured FLOPs or seconds",
            },
            "kv_allocated_capacity_bytes": (
                self.config.kv_cache_memory_bytes if self.config.kv_cache_memory_bytes is not None
                else sum(t.size for t in self.scheduler.kv_cache_config.kv_cache_tensors)
            ),
            **({"gpu_memory_utilization": self.config.gpu_memory_utilization}
               if self.config.kv_cache_memory_bytes is None else {}),
        }

    def close(self) -> None:
        self.scheduler.release_all_checkpoints()
        self.engine.engine_core.shutdown()

    def _get_scheduler(self) -> OctopusScheduler:
        core_client = self.engine.engine_core
        engine_core = getattr(core_client, "engine_core", None)
        scheduler = getattr(engine_core, "scheduler", None)
        if not isinstance(scheduler, OctopusScheduler):
            raise RuntimeError("Octopus requires an in-process OctopusScheduler")
        return scheduler

    def _kv_block_bytes(self) -> int | None:
        config = self.scheduler.kv_cache_config
        tensor_bytes = sum(
            int(tensor.size) for tensor in config.kv_cache_tensors if tensor.size
        )
        if not tensor_bytes or not config.num_blocks:
            return None
        return tensor_bytes // config.num_blocks


def structured_commit_sampling_params(
    schema_json: str | None,
    *,
    grammar: str | None = None,
    max_tokens: int,
    seed: int,
) -> SamplingParams:
    if (schema_json is None) == (grammar is None):
        raise ValueError("provide exactly one JSON schema or grammar")
    return SamplingParams(
        temperature=0,
        max_tokens=max_tokens,
        seed=seed,
        structured_outputs=StructuredOutputsParams(json=schema_json, grammar=grammar),
    )
