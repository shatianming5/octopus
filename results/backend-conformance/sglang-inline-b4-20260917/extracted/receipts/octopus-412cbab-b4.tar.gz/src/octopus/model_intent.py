"""Producer-supplied next-reuse preferences; no runtime prediction or ownership."""
from __future__ import annotations

import json
import math
import re
from collections.abc import Iterable
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class ModelIntent:
    """Criticality marks a task-critical prerequisite, never a hard KV pin."""

    importance: float
    reuse_likelihood: float
    criticality: bool

    def __post_init__(self) -> None:
        for name in ("importance", "reuse_likelihood"):
            value = getattr(self, name)
            if type(value) not in (int, float) or not 0 <= value <= 1 or not math.isfinite(value):
                raise ValueError(f"{name} must be a finite number in [0, 1]")
        if type(self.criticality) is not bool:
            raise ValueError("criticality must be a boolean")

    @property
    def expected_importance(self) -> float:
        return self.importance * self.reuse_likelihood


def _candidate_ids(checkpoint_ids: Iterable[str]) -> tuple[str, ...]:
    ids = tuple(checkpoint_ids)
    if not ids or any(not isinstance(cp, str) or not cp for cp in ids):
        raise ValueError("candidate checkpoint IDs must be nonempty strings")
    if len(set(ids)) != len(ids):
        raise ValueError("duplicate candidate checkpoint ID")
    return ids


def model_intent_schema(checkpoint_ids: Iterable[str]) -> dict:
    """Identity-constrained structured generation; parsing still checks exact coverage."""
    ids = _candidate_ids(checkpoint_ids)
    return {
        "type": "object", "additionalProperties": False, "required": ["intents"],
        "properties": {"intents": {
            "type": "array", "minItems": len(ids), "maxItems": len(ids),
            "items": {
                "type": "object", "additionalProperties": False,
                "required": ["checkpoint_id", "importance", "reuse_likelihood", "criticality"],
                "properties": {
                    "checkpoint_id": {"type": "string", "enum": list(ids)},
                    "importance": {"type": "number", "minimum": 0, "maximum": 1},
                    "reuse_likelihood": {"type": "number", "minimum": 0, "maximum": 1},
                    "criticality": {"type": "boolean"},
                },
            },
        }},
    }


def _unique_object(pairs: list[tuple[str, object]]) -> dict:
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate JSON key {key!r}")
        result[key] = value
    return result


def _invalid_constant(value: str) -> None:
    raise ValueError(f"invalid JSON number {value}")


def parse_model_intents(payload: str, checkpoint_ids: Iterable[str]) -> dict[str, ModelIntent]:
    """Reject malformed data, duplicates and non-exact candidate coverage atomically."""
    expected = set(_candidate_ids(checkpoint_ids))
    data = json.loads(payload, object_pairs_hook=_unique_object, parse_constant=_invalid_constant)
    if not isinstance(data, dict) or set(data) != {"intents"} or not isinstance(data["intents"], list):
        raise ValueError("model response must be an object containing only an intents array")
    result = {}
    for row in data["intents"]:
        if not isinstance(row, dict) or set(row) != {
            "checkpoint_id", "importance", "reuse_likelihood", "criticality",
        }:
            raise ValueError("model intent requires exactly checkpoint_id, importance, reuse_likelihood, criticality")
        cp = row["checkpoint_id"]
        if not isinstance(cp, str) or cp not in expected:
            raise ValueError(f"unknown model checkpoint ID {cp!r}")
        if cp in result:
            raise ValueError(f"duplicate model checkpoint ID {cp!r}")
        result[cp] = ModelIntent(row["importance"], row["reuse_likelihood"], row["criticality"])
    if missing := expected - result.keys():
        raise ValueError(f"missing model checkpoint IDs: {sorted(missing)}")
    return result


def checkpoint_choice_schema(checkpoint_ids: Iterable[str]) -> dict:
    ids = _candidate_ids(checkpoint_ids)
    return {"type": "object", "additionalProperties": False, "required": ["checkpoint_id"],
            "properties": {"checkpoint_id": {"type": "string", "enum": list(ids)}}}


def parse_checkpoint_choice(payload: str, checkpoint_ids: Iterable[str]) -> str:
    expected = set(_candidate_ids(checkpoint_ids))
    data = json.loads(payload, object_pairs_hook=_unique_object, parse_constant=_invalid_constant)
    if not isinstance(data, dict) or set(data) != {"checkpoint_id"}:
        raise ValueError("choice must contain only checkpoint_id")
    choice = data["checkpoint_id"]
    if not isinstance(choice, str) or choice not in expected:
        raise ValueError("choice must name a known checkpoint")
    return choice


def choice_intent_payload(payload: str, checkpoint_ids: Iterable[str]) -> str:
    """Mechanically map the exact model choice to #19 priorities, never repair it."""
    ids = _candidate_ids(checkpoint_ids)
    choice = parse_checkpoint_choice(payload, ids)
    return json.dumps({"intents": [
        {"checkpoint_id": cp, "importance": int(cp == choice), "reuse_likelihood": 1,
         "criticality": cp == choice} for cp in ids
    ]}, sort_keys=True)


def inline_intent_schema(body_schema: dict) -> dict:
    """Require the existing normal action to expose its bounded dispatch field first."""
    if body_schema.get("type") != "object":
        raise ValueError("inline intent requires an object body schema")
    properties = body_schema.get("properties", {})
    dispatch = properties.get("dispatch_index", {})
    if (next(iter(properties), None) != "dispatch_index"
            or "dispatch_index" not in body_schema.get("required", ())
            or dispatch.get("type") != "integer" or dispatch.get("enum") != [0, 1]):
        raise ValueError("inline intent requires first required field dispatch_index: integer enum [0, 1]")
    return body_schema


class InlineIntentStream:
    """Observe the normal dispatch action itself, with no redundant choice to disagree."""

    def __init__(self, checkpoint_ids: Iterable[str]) -> None:
        self.checkpoint_ids = _candidate_ids(checkpoint_ids)
        if len(self.checkpoint_ids) != 2:
            raise ValueError("inline intent requires exactly two checkpoint IDs")
        self.checkpoint_id: str | None = None

    def read(self, text: str) -> str | None:
        # The validated generation schema permits only a single-digit 0/1 value.
        match = re.match(
            r'\s*\{\s*"dispatch_index"\s*:\s*([01])(?=\s*[,}]|\s*$)', text,
        )
        if match is None:
            return None
        choice = self.checkpoint_ids[int(match[1])]
        if self.checkpoint_id is not None:
            if choice != self.checkpoint_id:
                raise ValueError("inline choice changed during generation")
            return None
        self.checkpoint_id = choice
        return choice

    def payload(self) -> str:
        if self.checkpoint_id is None:
            raise ValueError("inline choice is not ready")
        return choice_intent_payload(
            json.dumps({"checkpoint_id": self.checkpoint_id}), self.checkpoint_ids,
        )

    def finish(self, text: str) -> dict:
        data = json.loads(text, object_pairs_hook=_unique_object, parse_constant=_invalid_constant)
        if (not isinstance(data, dict) or type(data.get("dispatch_index")) is not int
                or data["dispatch_index"] not in (0, 1)):
            raise ValueError("inline output must contain normal dispatch_index 0 or 1")
        if self.checkpoint_ids[data["dispatch_index"]] != self.checkpoint_id:
            raise ValueError("final inline choice was not observed in the stream")
        return data


@dataclass(frozen=True, slots=True)
class InlineIntentResult:
    checkpoint_id: str
    body: dict
    ready_seconds: float
    ready_output_tokens: int
    applied: bool
    native_receipt: dict | None = None
