"""CPU-only, deterministic extractive context compilation."""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from enum import Enum
from typing import Callable, Sequence

from octopus.state import Evidence, WorldState


class InheritanceMode(str, Enum):
    FULL = "FULL"
    PREFIX_CAPSULE = "PREFIX_CAPSULE"
    CAPSULE = "CAPSULE"


class ContextBudgetError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class Inheritance:
    mode: InheritanceMode = InheritanceMode.FULL
    mandatory_prefix_tokens: int = 0
    prefix_tokens: int | None = None
    legal_prefix_tokens: tuple[int, ...] = ()
    predicates: tuple[str, ...] = ()
    evidence: tuple[Evidence, ...] = ()
    constraints: tuple[str, ...] = ()
    optional_evidence: tuple[Evidence, ...] = ()
    context_token_budget: int | None = None


@dataclass(frozen=True, slots=True)
class CompiledContext:
    prompt_token_ids: tuple[int, ...]
    selected_parent_tokens: int
    parent_cacheable_frontier: int | None
    mandatory_prefix_tokens: int
    parent_tokens: int
    capsule_json: str
    capsule_token_ids: tuple[int, ...]
    omitted_optional_evidence: int = 0

    @property
    def capsule_tokens(self) -> int:
        return len(self.capsule_token_ids)

    @property
    def history_fraction(self) -> float | None:
        history = self.parent_tokens - self.mandatory_prefix_tokens
        return ((self.selected_parent_tokens - self.mandatory_prefix_tokens) / history
                if history else None)


def compile_context(
    parent_token_ids: Sequence[int], suffix_token_ids: Sequence[int],
    inheritance: Inheritance, state: WorldState, *,
    tokenize: Callable[[str], Sequence[int]], shared_tokens: int | None,
    block_size: int | None, max_model_len: int, max_new_tokens: int,
) -> CompiledContext:
    mode = InheritanceMode(inheritance.mode)
    if mode != InheritanceMode.FULL and (shared_tokens is None or block_size is None):
        raise ValueError("selective inheritance requires an observed cache frontier and alignment")
    length = len(parent_token_ids)
    h = inheritance.mandatory_prefix_tokens
    if not 0 <= h <= length:
        raise ValueError("mandatory prefix boundary is outside parent tokens")
    if max_new_tokens < 1:
        raise ContextBudgetError("output reserve must be positive")
    limit = max_model_len - max_new_tokens
    if inheritance.context_token_budget is not None:
        limit = min(limit, inheritance.context_token_budget)
    if mode == InheritanceMode.FULL:
        k = length
    elif mode == InheritanceMode.CAPSULE:
        k = h
    else:
        k = inheritance.prefix_tokens
        if k is None or k not in inheritance.legal_prefix_tokens or not h <= k <= length:
            raise ValueError("selected prefix must be a declared legal boundary within parent")

    payload = {}
    capsule_json = ""
    capsule: tuple[int, ...] = ()
    if mode != InheritanceMode.FULL:
        missing = set(inheritance.predicates) - state.facts.keys()
        if missing:
            raise ValueError(f"required predicate missing: {sorted(missing)}")
        snapshot = state.to_dict()
        payload = {
            "facts": {p: snapshot["facts"][p] for p in sorted(set(inheritance.predicates))},
            "evidence": [asdict(e) for e in inheritance.evidence],
            "constraints": list(inheritance.constraints),
            "unresolved": list(state.unresolved),
        }

        def encode():
            text = json.dumps(payload, ensure_ascii=True, sort_keys=True, separators=(",", ":"))
            return text, tuple(tokenize("\n[OCTOPUS_CAPSULE]\n" + text + "\n[/OCTOPUS_CAPSULE]\n"))

        capsule_json, capsule = encode()
    if k + len(capsule) + len(suffix_token_ids) > limit:
        raise ContextBudgetError(
            f"mandatory context needs {k + len(capsule) + len(suffix_token_ids)} tokens; "
            f"available {limit} after output reserve {max_new_tokens}"
        )
    included = 0
    if mode != InheritanceMode.FULL:
        for evidence in inheritance.optional_evidence:
            payload["evidence"].append(asdict(evidence))
            next_json, next_tokens = encode()
            if k + len(next_tokens) + len(suffix_token_ids) > limit:
                break
            capsule_json, capsule = next_json, next_tokens
            included += 1
    return CompiledContext(
        (*parent_token_ids[:k], *capsule, *suffix_token_ids),
        k, (min(shared_tokens, k // block_size * block_size)
            if shared_tokens is not None and block_size is not None else None), h, length,
        capsule_json, capsule,
        len(inheritance.optional_evidence) - included if mode != InheritanceMode.FULL else 0,
    )
