"""Causal checkpoint dependencies; no workload tape or future completion times."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Literal


ConsumerState = Literal["declared", "ready", "queued", "active", "complete", "cancelled", "failed"]


class Requirement(str, Enum):
    DEFINITE = "definite"
    CONDITIONAL = "conditional"


@dataclass(frozen=True, slots=True)
class ConsumerIntent:
    consumer_id: str
    prerequisite_ids: tuple[str, ...] = ()
    requirement: Requirement = Requirement.DEFINITE
    condition_id: str | None = None
    condition_outcome: bool = True
    parent_prefix_tokens: int | None = None

    def __post_init__(self) -> None:
        if not self.consumer_id:
            raise ValueError("consumer identity must be nonempty")
        if (self.requirement == Requirement.CONDITIONAL) != (self.condition_id is not None):
            raise ValueError("only conditional consumers require a condition_id")
        if self.requirement not in (Requirement.DEFINITE, Requirement.CONDITIONAL):
            raise ValueError("unsupported consumer requirement")
        if self.parent_prefix_tokens is not None and (
            type(self.parent_prefix_tokens) is not int or self.parent_prefix_tokens < 0
        ):
            raise ValueError("parent_prefix_tokens must be a nonnegative integer")


@dataclass(frozen=True, slots=True)
class CheckpointIntent:
    """Complete empty intent is NONE; absent/incomplete intent is UNKNOWN."""
    consumers: tuple[ConsumerIntent, ...] = ()
    complete: bool = True


@dataclass(frozen=True, slots=True)
class ReadinessEstimate:
    adoption_at: float | None
    source: str
    status: Literal["valid", "unknown", "overdue"]
    prerequisites_at: float | None = None
    preparation_seconds: float | None = None
    queue_seconds: float | None = None


@dataclass(slots=True)
class GPUConsumer:
    consumer_id: str
    checkpoint_id: str
    prerequisite_ids: tuple[str, ...]
    declared_at: float
    state: ConsumerState = "declared"
    bound_request_id: str | None = None
    external_request_id: str | None = None
    ready_at: float | None = None
    preparing_at: float | None = None
    enqueued_at: float | None = None
    runnable_at: float | None = None
    adopted_at: float | None = None
    finished_at: float | None = None
    advance_declared: bool = True
    readiness_estimate: ReadinessEstimate | None = None
    requirement: Requirement = Requirement.DEFINITE
    condition_id: str | None = None
    condition_outcome: bool = True
    parent_prefix_tokens: int | None = None

    @property
    def terminal(self) -> bool:
        return self.state in {"complete", "cancelled", "failed"}


@dataclass(frozen=True, slots=True)
class Event:
    kind: str
    checkpoint_id: str
    at: float
    node_id: str = ""
    parent_id: str | None = None
    tool_kind: str = ""
    eta_seconds: float | None = None
    priority: float = 1.0


@dataclass(slots=True)
class Dependency:
    checkpoint_id: str
    started_at: float
    tool_kind: str
    eta_seconds: float | None
    source: str


@dataclass(slots=True)
class CheckpointSignal:
    parent_id: str | None = None
    priority: float = 1.0
    resolved: bool = False
    reuse_count: int = 0
    active: set[str] = field(default_factory=set)
    observed_reuses: set[str] = field(default_factory=set)


class Signals:
    def __init__(self, tool_priors: dict[str, float] | None = None) -> None:
        self.checkpoints: dict[str, CheckpointSignal] = {}
        self.dependencies: dict[str, Dependency] = {}
        self.tool_history = dict(tool_priors or {})
        self.prediction_errors: list[dict[str, float | str]] = []
        self.consumers: dict[str, GPUConsumer] = {}
        self.consumer_contracts: set[str] = set()
        self.no_consumer_contracts: set[str] = set()
        self.condition_outcomes: dict[str, bool] = {}
        self.closed: set[str] = set()
        self.completed_dependencies: dict[str, float] = {}
        self.failed_dependencies: set[str] = set()
        self.consumer_records: list[dict] = []
        self.preparation_history: list[float] = []
        self.queue_history: list[float] = []

    def _record(self, consumer: GPUConsumer, at: float, kind: str) -> None:
        self.consumer_records.append({"at": at, "kind": kind, **asdict(consumer)})

    def declare(
        self, checkpoint_id: str, consumer_id: str, after: tuple[str, ...], at: float,
        *, requirement: Requirement = Requirement.DEFINITE,
        condition_id: str | None = None, condition_outcome: bool = True,
        parent_prefix_tokens: int | None = None,
    ) -> GPUConsumer:
        ConsumerIntent(consumer_id, after, requirement, condition_id, condition_outcome, parent_prefix_tokens)
        if checkpoint_id in self.closed:
            raise ValueError(f"checkpoint {checkpoint_id!r} is closed")
        if consumer_id in self.consumers:
            raise ValueError(f"consumer {consumer_id!r} already declared")
        consumer = GPUConsumer(
            consumer_id, checkpoint_id, after, at, requirement=requirement,
            condition_id=condition_id, condition_outcome=condition_outcome,
            parent_prefix_tokens=parent_prefix_tokens,
        )
        self.consumers[consumer_id] = consumer
        self.consumer_contracts.add(checkpoint_id)
        self.no_consumer_contracts.discard(checkpoint_id)
        if condition_id in self.condition_outcomes:
            self._apply_condition(consumer, self.condition_outcomes[condition_id], at)
        self._refresh_ready(consumer, at)
        self._record(consumer, at, "declare")
        return consumer

    def register_intent(self, checkpoint_id: str, intent: CheckpointIntent, at: float) -> None:
        identities = [c.consumer_id for c in intent.consumers]
        if len(set(identities)) != len(identities) or any(i in self.consumers for i in identities):
            raise ValueError("consumer already declared in capture intent")
        if checkpoint_id in self.closed:
            raise ValueError(f"checkpoint {checkpoint_id!r} is closed")
        for c in intent.consumers:
            self.declare(
                checkpoint_id, c.consumer_id, c.prerequisite_ids, at,
                requirement=c.requirement, condition_id=c.condition_id,
                condition_outcome=c.condition_outcome,
                parent_prefix_tokens=c.parent_prefix_tokens,
            )
        if intent.complete:
            self.consumer_contracts.add(checkpoint_id)
            if not intent.consumers:
                self.declare_no_consumers(checkpoint_id, at)
        else:
            self.consumer_contracts.discard(checkpoint_id)

    def _apply_condition(self, consumer: GPUConsumer, outcome: bool, at: float) -> None:
        if consumer.terminal or consumer.bound_request_id is not None:
            return
        if outcome == consumer.condition_outcome:
            consumer.requirement = Requirement.DEFINITE
            self._refresh_ready(consumer, at)
            self._record(consumer, at, "condition_selected")
        else:
            self.cancel(consumer.consumer_id, at)

    def decide_condition(self, condition_id: str, outcome: bool, at: float) -> None:
        if not isinstance(outcome, bool):
            raise ValueError("condition outcome must be an explicit boolean")
        if condition_id in self.condition_outcomes:
            raise ValueError(f"condition {condition_id!r} already decided")
        self.condition_outcomes[condition_id] = outcome
        self.consumer_records.append({
            "kind": "condition_outcome", "condition_id": condition_id,
            "outcome": outcome, "at": at,
        })
        for consumer in list(self.consumers.values()):
            if consumer.condition_id == condition_id:
                self._apply_condition(consumer, outcome, at)

    def declare_no_consumers(self, checkpoint_id: str, at: float) -> None:
        if checkpoint_id in self.closed:
            raise ValueError(f"checkpoint {checkpoint_id!r} is closed")
        if any(c.checkpoint_id == checkpoint_id and c.state in {"declared", "ready"}
               for c in self.consumers.values()):
            raise ValueError("checkpoint has live future GPU consumers")
        self.consumer_contracts.add(checkpoint_id)
        self.no_consumer_contracts.add(checkpoint_id)
        self.consumer_records.append({
            "at": at, "kind": "no_live_gpu_consumer", "checkpoint_id": checkpoint_id,
        })

    def _refresh_ready(self, consumer: GPUConsumer, at: float) -> None:
        if consumer.state != "declared":
            return
        if any(node in self.failed_dependencies for node in consumer.prerequisite_ids):
            self.cancel(consumer.consumer_id, at)
        elif consumer.requirement == Requirement.DEFINITE and all(
            node in self.completed_dependencies for node in consumer.prerequisite_ids
        ):
            consumer.state = "ready"
            consumer.ready_at = at

    def dependency_done(self, node: str, at: float, *, failed: bool = False) -> None:
        if failed:
            self.failed_dependencies.add(node)
        else:
            self.completed_dependencies[node] = at
        for consumer in self.consumers.values():
            if node not in consumer.prerequisite_ids or consumer.state not in {"declared", "ready"}:
                continue
            if failed:
                self.cancel(consumer.consumer_id, at)
            else:
                self._refresh_ready(consumer, at)
            self._record(consumer, at, "dependency")

    def preparing(self, consumer_id: str, at: float) -> None:
        consumer = self.consumers[consumer_id]
        consumer.preparing_at = at
        self._record(consumer, at, "preparing")

    def bind(
        self, checkpoint_id: str, consumer_id: str | None, request_id: str,
        external_id: str, at: float,
    ) -> GPUConsumer:
        identity = consumer_id or f"request:{request_id}"
        consumer = self.consumers.get(identity)
        if consumer is None:
            if consumer_id is not None:
                raise ValueError(f"consumer {consumer_id!r} was not declared")
            consumer = GPUConsumer(
                identity, checkpoint_id, (), at, ready_at=at, advance_declared=False,
            )
            self.consumers[identity] = consumer
        if (consumer.checkpoint_id != checkpoint_id or consumer.bound_request_id is not None
                or consumer.terminal or consumer.requirement != Requirement.DEFINITE):
            raise ValueError(f"conflicting consumer binding {identity!r}")
        consumer.bound_request_id = request_id
        consumer.external_request_id = external_id
        consumer.enqueued_at = at
        consumer.state = "queued"
        self._record(consumer, at, "enqueue")
        return consumer

    def adopted(self, request_id: str, at: float) -> None:
        for consumer in self.consumers.values():
            if consumer.bound_request_id == request_id and not consumer.terminal:
                if consumer.adopted_at is None:
                    consumer.adopted_at = at
                    consumer.runnable_at = at if consumer.runnable_at is None else consumer.runnable_at
                    consumer.state = "active"
                    self._record(consumer, at, "adoption")
                consumer.state = "active"

    def finish_request(self, request_id: str, at: float, state: ConsumerState) -> None:
        for consumer in self.consumers.values():
            if consumer.bound_request_id == request_id and not consumer.terminal:
                consumer.state = state
                consumer.finished_at = at
                if state == "complete" and consumer.adopted_at is not None and consumer.enqueued_at is not None:
                    self.queue_history.append(consumer.adopted_at - consumer.enqueued_at)
                    if consumer.ready_at is not None:
                        self.preparation_history.append(consumer.enqueued_at - consumer.ready_at)
                self._record(consumer, at, "finish")
                self.dependency_done(consumer.consumer_id, at, failed=state != "complete")

    def cancel(self, consumer_id: str, at: float) -> None:
        consumer = self.consumers[consumer_id]
        if consumer.terminal:
            return
        if consumer.bound_request_id is not None:
            raise ValueError("cancel an accepted request through its native request lifecycle")
        consumer.state = "cancelled"
        consumer.finished_at = at
        self._record(consumer, at, "cancel")
        self.dependency_done(consumer_id, at, failed=True)

    def estimate(
        self, consumer: GPUConsumer, now: float, waiting_requests: int,
    ) -> ReadinessEstimate:
        ready = consumer.ready_at
        source = "completed_stage_history+visible_queue+dependency_priors"
        if ready is None:
            deadlines = []
            for node in consumer.prerequisite_ids:
                if node in self.completed_dependencies:
                    deadlines.append(self.completed_dependencies[node])
                elif node in self.dependencies and self.dependencies[node].eta_seconds is not None:
                    dependency = self.dependencies[node]
                    deadlines.append(dependency.started_at + dependency.eta_seconds)
                else:
                    deadlines = []
                    break
            ready = max(deadlines) if deadlines else None
        prep = (
            sum(self.preparation_history) / len(self.preparation_history)
            if self.preparation_history else None
        )
        queue = (
            sum(self.queue_history) / len(self.queue_history) * max(1, waiting_requests)
            if self.queue_history else None
        )
        adoption = None if ready is None or prep is None or queue is None else ready + prep + queue
        status = "unknown" if adoption is None else "overdue" if (
            adoption <= now or (consumer.ready_at is None and ready <= now)
        ) else "valid"
        estimate = ReadinessEstimate(adoption, source, status, ready, prep, queue)
        consumer.readiness_estimate = estimate
        return estimate

    def observe(self, event: Event) -> None:
        state = self.checkpoints.setdefault(event.checkpoint_id, CheckpointSignal())
        if event.kind == "capture":
            state.parent_id = event.parent_id
            state.priority = event.priority
        elif event.kind == "fork":
            state.active.add(event.node_id)
        elif event.kind == "reuse":
            if not event.node_id or event.node_id not in state.observed_reuses:
                state.reuse_count += 1
                state.observed_reuses.add(event.node_id)
        elif event.kind in {"complete", "abort", "fail"}:
            state.active.discard(event.node_id)
            self.dependency_done(event.node_id, event.at, failed=event.kind != "complete")
        elif event.kind in {"tool_start", "stage_start"}:
            eta = event.eta_seconds
            source = "caller_hint" if eta is not None else "completed_history"
            if eta is None:
                eta = self.tool_history.get(event.tool_kind)
            if eta is None:
                source = "unknown"
            self.dependencies[event.node_id] = Dependency(
                event.checkpoint_id, event.at, event.tool_kind, eta, source
            )
        elif event.kind in {"tool_complete", "tool_cancel", "tool_fail", "stage_complete", "stage_fail"}:
            dependency = self.dependencies.pop(event.node_id)
            if event.kind in {"tool_complete", "stage_complete"}:
                duration = event.at - dependency.started_at
                old = self.tool_history.get(dependency.tool_kind, duration)
                self.tool_history[dependency.tool_kind] = (old + duration) / 2
                if dependency.eta_seconds is not None:
                    self.prediction_errors.append({
                        "node_id": event.node_id,
                        "predicted_seconds": dependency.eta_seconds,
                        "observed_seconds": duration,
                        "error_seconds": duration - dependency.eta_seconds,
                    })
            self.dependency_done(event.node_id, event.at, failed=event.kind not in {"tool_complete", "stage_complete"})
        elif event.kind in {"resolve", "release"}:
            state.resolved = True
            self.closed.add(event.checkpoint_id)
            if event.kind == "release":
                for consumer in list(self.consumers.values()):
                    if consumer.checkpoint_id == event.checkpoint_id and consumer.bound_request_id is None and not consumer.terminal:
                        self.cancel(consumer.consumer_id, event.at)
        else:
            raise ValueError(f"unsupported signal event {event.kind!r}")

    def episodes(self, checkpoint_id: str, now: float) -> list[tuple[str, float | None]]:
        state = self.checkpoints[checkpoint_id]
        if state.resolved:
            return []
        # A node represents one reuse wave, not each branch in its fanout.
        return [
            (
                node_id,
                None if dependency.eta_seconds is None else max(
                    0.0, dependency.started_at + dependency.eta_seconds - now
                ),
            )
            for node_id, dependency in sorted(self.dependencies.items())
            if dependency.checkpoint_id == checkpoint_id
        ]
