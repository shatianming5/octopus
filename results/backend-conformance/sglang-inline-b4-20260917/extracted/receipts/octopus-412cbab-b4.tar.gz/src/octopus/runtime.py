from __future__ import annotations

import json
import time
import uuid
from dataclasses import dataclass
from enum import Enum
from typing import Iterable

from octopus.state import Commit, CommitValidationError, StateReducer, commit_schema, semantic_delta_text
from octopus.context import CompiledContext, Inheritance, InheritanceMode, compile_context
from octopus.signals import CheckpointIntent, Event, Requirement
from octopus.model_intent import (
    InlineIntentResult, InlineIntentStream, ModelIntent, inline_intent_schema,
    parse_model_intents,
)
from octopus.backend import (
    BackendConfig, Checkpoint, GenerationConfig, GenerationEvent,
    InferenceBackend, UnsupportedBackendFeature, default_backend,
)


class BranchStatus(str, Enum):
    QUEUED = "QUEUED"
    RUNNING = "RUNNING"
    COMMIT_READY = "COMMIT_READY"
    COMMITTED = "COMMITTED"
    ABORTED = "ABORTED"
    FAILED = "FAILED"


@dataclass(frozen=True, slots=True)
class BranchTask:
    suffix_token_ids: tuple[int, ...]
    max_new_tokens: int
    branch_id: str | None = None
    structured_commit: bool = False
    ignore_eos: bool = False
    capture_checkpoint: bool = False
    consumer_id: str | None = None
    capture_intent: CheckpointIntent | None = None
    inheritance: Inheritance = Inheritance()
    commit_schema_json: str | None = None


@dataclass(frozen=True, slots=True)
class PreparedBranch:
    task: BranchTask
    branch_id: str
    context: CompiledContext
    sampling_params: GenerationConfig
    checkpoint_id: str
    parent_checkpoint: Checkpoint


@dataclass(slots=True)
class Branch:
    branch_id: str
    request_id: str
    checkpoint_id: str
    status: BranchStatus
    created_at: float
    structured_commit: bool
    output_token_ids: tuple[int, ...] = ()
    text: str = ""
    finish_reason: str | None = None
    commit: Commit | None = None
    error: str | None = None
    output_checkpoint: Checkpoint | None = None
    capture_checkpoint_id: str | None = None
    context: CompiledContext | None = None


@dataclass(frozen=True, slots=True)
class BrainResult:
    request_id: str
    output_token_ids: tuple[int, ...]
    text: str
    finish_reason: str | None
    checkpoint: Checkpoint
    inline_intent: InlineIntentResult | None = None


@dataclass(slots=True)
class _PendingInlineIntent:
    stream: InlineIntentStream
    checkpoints: tuple[Checkpoint, ...]
    submitted_at: float
    ready: tuple[float, int] | None = None
    applied: bool = False
    native_receipt: dict | None = None


class Octopus:
    def __init__(self, config: BackendConfig | None = None, *,
                 backend: InferenceBackend | None = None) -> None:
        if config is not None and backend is not None:
            raise ValueError("supply either config or backend, not both")
        self.backend = backend if backend is not None else default_backend(config)
        self.reducer = StateReducer()
        self.branches: dict[str, Branch] = {}
        self._request_to_branch: dict[str, str] = {}
        self._checkpoints: dict[str, Checkpoint] = {}
        self._inline_requests: dict[str, _PendingInlineIntent] = {}
        self._closed = False

    def __enter__(self) -> "Octopus":
        return self

    def __exit__(self, exc_type, exc, traceback) -> None:
        self.close()

    def run_brain(
        self,
        prompt_token_ids: list[int] | tuple[int, ...],
        *,
        max_new_tokens: int,
        ignore_eos: bool = False,
        capture_intent: CheckpointIntent | None = None,
        schema_json: str | None = None,
        grammar: str | None = None,
        inline_intent_checkpoints: Iterable[Checkpoint] | None = None,
    ) -> BrainResult:
        self._require_no_pending_branches()
        return self._run_captured_request(
            list(prompt_token_ids),
            max_new_tokens=max_new_tokens,
            ignore_eos=ignore_eos,
            capture_intent=capture_intent,
            schema_json=schema_json,
            grammar=grammar,
            inline_intent_checkpoints=inline_intent_checkpoints,
        )

    def apply_model_intents(
        self, payload: str, *, checkpoints: Iterable[Checkpoint],
        producer_request_id: str | None = None,
    ) -> dict[str, ModelIntent]:
        """Atomically apply exact producer JSON to open checkpoints for their next bound use."""
        candidates = tuple(checkpoints)
        intents = parse_model_intents(payload, (cp.checkpoint_id for cp in candidates))
        self._validate_model_checkpoints(candidates)
        self._last_intent_receipt = self.backend.apply_model_intents(
            intents, producer_request_id=producer_request_id,
        )
        return intents

    def _validate_model_checkpoints(self, candidates: Iterable[Checkpoint]) -> None:
        for cp in candidates:
            self.backend.validate_checkpoint(cp)

    def fork(
        self,
        checkpoint: Checkpoint,
        tasks: Iterable[BranchTask],
    ) -> list[Branch]:
        return self.fork_prepared(checkpoint, self.prepare_fork(checkpoint, tasks))

    def prepare_fork(
        self, checkpoint: Checkpoint, tasks: Iterable[BranchTask],
    ) -> list[PreparedBranch]:
        self._require_open()
        self.backend.validate_checkpoint(checkpoint)
        prepared = []
        branch_ids = set(self.branches)
        for task in tasks:
            branch_id = task.branch_id or f"branch-{uuid.uuid4().hex}"
            if branch_id in branch_ids:
                raise ValueError(f"branch {branch_id!r} already exists")
            branch_ids.add(branch_id)
            self.backend.validate_inheritance(task.inheritance.mode)
            if task.capture_intent is not None and not task.capture_checkpoint:
                raise ValueError("capture intent requires an output checkpoint")
            if task.commit_schema_json is not None and not task.structured_commit:
                raise ValueError("commit schema requires structured_commit")
            context = compile_context(
                checkpoint.logical_token_ids, task.suffix_token_ids, task.inheritance,
                self.reducer.state, tokenize=self.backend.tokenize,
                shared_tokens=checkpoint.shared_tokens, block_size=checkpoint.block_size,
                max_model_len=self.backend.config.max_model_len,
                max_new_tokens=task.max_new_tokens,
            )
            if task.structured_commit:
                sampling_params = GenerationConfig(
                    schema_json=task.commit_schema_json or json.dumps(commit_schema(branch_id), sort_keys=True),
                    max_tokens=task.max_new_tokens,
                    seed=self.backend.config.seed,
                    ignore_eos=task.ignore_eos,
                )
            else:
                sampling_params = GenerationConfig(
                    temperature=0,
                    max_tokens=task.max_new_tokens,
                    ignore_eos=task.ignore_eos,
                    seed=self.backend.config.seed,
                )
            self.backend.validate_generation(sampling_params, capture_intent=task.capture_intent)
            prepared.append(PreparedBranch(task, branch_id, context, sampling_params,
                                           checkpoint.checkpoint_id, checkpoint))
        return prepared

    def fork_prepared(
        self, checkpoint: Checkpoint, prepared: Iterable[PreparedBranch],
    ) -> list[Branch]:
        self._require_open()
        created: list[Branch] = []
        self.backend.validate_checkpoint(checkpoint)
        items = tuple(prepared)
        branch_ids = set(self.branches)
        for item in items:
            if (item.parent_checkpoint is not checkpoint
                    or item.checkpoint_id != checkpoint.checkpoint_id
                    or item.branch_id in branch_ids):
                raise ValueError("prepared branch parent mismatch or duplicate submission")
            branch_ids.add(item.branch_id)
            self.backend.validate_generation(item.sampling_params, capture_intent=item.task.capture_intent)
        for item in items:
            task, branch_id, context = item.task, item.branch_id, item.context
            request_id = self.backend.add_request(
                request_id=branch_id,
                prompt_token_ids=list(context.prompt_token_ids),
                sampling_params=item.sampling_params,
                checkpoint_id=checkpoint.checkpoint_id,
                selected_parent_tokens=context.selected_parent_tokens,
                capsule_tokens=context.capsule_tokens,
                consumer_id=task.consumer_id,
                capture_intent=task.capture_intent,
                capture_checkpoint_id=(
                    f"checkpoint:{branch_id}" if task.capture_checkpoint else None
                ),
            )
            branch = Branch(
                branch_id=branch_id,
                request_id=request_id,
                checkpoint_id=checkpoint.checkpoint_id,
                status=BranchStatus.QUEUED,
                created_at=time.perf_counter(),
                structured_commit=task.structured_commit,
                context=context,
                capture_checkpoint_id=(
                    f"checkpoint:{branch_id}" if task.capture_checkpoint else None
                ),
            )
            self.branches[branch_id] = branch
            self._request_to_branch[request_id] = branch_id
            created.append(branch)
            self._branch_submitted(branch)
        return created

    def _branch_submitted(self, branch: Branch) -> None:
        self.observe(Event(
            "fork", branch.checkpoint_id, time.perf_counter(),
            node_id=branch.branch_id,
        ))

    def has_pending_branches(self) -> bool:
        return any(
            branch.status in {BranchStatus.QUEUED, BranchStatus.RUNNING}
            for branch in self.branches.values()
        )

    def step(self) -> list[Branch]:
        return self.accept_outputs(self.backend.poll())

    def accept_outputs(self, outputs) -> list[Branch]:
        """Route a shared engine step without stepping or consuming other owners."""
        changed: list[Branch] = []
        for output in self.backend.normalize_events(outputs):
            branch_id = self._request_to_branch.get(output.internal_request_id)
            if branch_id is None:
                continue
            branch = self.branches[branch_id]
            if branch.status not in {BranchStatus.QUEUED, BranchStatus.RUNNING}:
                continue
            branch.output_token_ids = output.token_ids
            branch.text = output.text
            branch.finish_reason = output.finish_reason
            if not output.finished:
                if branch.status == BranchStatus.QUEUED:
                    branch.status = BranchStatus.RUNNING
                    changed.append(branch)
                continue

            if output.error is not None:
                branch.status = BranchStatus.FAILED
                branch.error = output.error
            elif output.finish_reason == "abort":
                branch.status = BranchStatus.ABORTED
            elif self._expects_structured_commit(branch):
                try:
                    commit = Commit.from_json(branch.text)
                    if commit.branch_id != branch.branch_id:
                        raise CommitValidationError(
                            "commit.branch_id does not match the branch"
                        )
                    branch.commit = commit
                    branch.status = BranchStatus.COMMIT_READY
                except CommitValidationError as exc:
                    branch.status = BranchStatus.FAILED
                    branch.error = str(exc)
            else:
                branch.status = BranchStatus.COMMIT_READY
            if branch.capture_checkpoint_id is not None and output.error is None and output.finish_reason != "abort":
                branch.output_checkpoint = self.backend.get_checkpoint_for_request(
                    branch.request_id
                )
                self._checkpoints[branch.output_checkpoint.checkpoint_id] = branch.output_checkpoint
            self.observe(Event(
                "fail" if branch.status == BranchStatus.FAILED else "complete",
                branch.checkpoint_id, time.perf_counter(), node_id=branch.branch_id,
            ))
            changed.append(branch)
        return changed

    def abort(self, branch: Branch | str) -> None:
        branch_id = branch if isinstance(branch, str) else branch.branch_id
        record = self.branches[branch_id]
        if record.status not in {BranchStatus.QUEUED, BranchStatus.RUNNING}:
            raise ValueError(
                f"branch {branch_id!r} cannot abort from {record.status.value}"
            )
        self.backend.abort(record.request_id)
        record.status = BranchStatus.ABORTED
        self.observe(Event(
            "abort", record.checkpoint_id, time.perf_counter(), node_id=branch_id
        ))

    def observe(self, event: Event) -> None:
        """Submit a causal tool/dependency observation, never a hidden finish time."""
        self.backend.observe(event)

    def declare_gpu_consumer(
        self, checkpoint: Checkpoint, *, consumer_id: str, after: tuple[str, ...] = (),
        requirement: Requirement = Requirement.DEFINITE,
        condition_id: str | None = None, condition_outcome: bool = True,
        parent_prefix_tokens: int | None = None,
    ) -> None:
        self.backend.validate_checkpoint(checkpoint)
        self.backend.declare_gpu_consumer(
            checkpoint.checkpoint_id, consumer_id, after, requirement=requirement,
            condition_id=condition_id, condition_outcome=condition_outcome,
            parent_prefix_tokens=parent_prefix_tokens,
        )

    def decide_condition(self, condition_id: str, outcome: bool) -> None:
        self.backend.decide_condition(condition_id, outcome)

    def declare_no_gpu_consumers(self, checkpoint: Checkpoint) -> None:
        self.backend.validate_checkpoint(checkpoint)
        self.backend.declare_no_gpu_consumers(checkpoint.checkpoint_id)

    def cancel_gpu_consumer(self, consumer_id: str) -> None:
        self.backend.cancel_gpu_consumer(consumer_id)

    def resolve(self, checkpoint: Checkpoint) -> None:
        self.observe(Event("resolve", checkpoint.checkpoint_id, time.perf_counter()))

    def collect_commits(self, branches: Iterable[Branch]) -> list[Commit]:
        commits: list[Commit] = []
        for branch in branches:
            if branch.status != BranchStatus.COMMIT_READY or branch.commit is None:
                raise ValueError(f"branch {branch.branch_id!r} has no ready commit")
            commits.append(branch.commit)
        return commits

    def commit(
        self,
        checkpoint: Checkpoint,
        commits: Iterable[Commit],
        *,
        max_new_tokens: int,
        consumer_id: str | None = None,
        capture_intent: CheckpointIntent | None = None,
        final_schema_json: str | None = None,
        inline_intent_checkpoints: Iterable[Checkpoint] | None = None,
    ) -> BrainResult:
        self._require_inline_support(inline_intent_checkpoints)
        self.backend.validate_generation(GenerationConfig(
            max_new_tokens, seed=self.backend.config.seed, schema_json=final_schema_json,
        ), capture_intent=capture_intent)
        prompt_token_ids = self._commit_prompt(checkpoint, commits)
        return self._run_captured_request(
            prompt_token_ids, max_new_tokens=max_new_tokens, checkpoint=checkpoint,
            consumer_id=consumer_id, capture_intent=capture_intent,
            schema_json=final_schema_json,
            inline_intent_checkpoints=inline_intent_checkpoints,
        )

    def _commit_prompt(self, checkpoint: Checkpoint, commits: Iterable[Commit]) -> list[int]:
        self._require_no_pending_branches()
        self.backend.validate_checkpoint(checkpoint)
        commit_list = list(commits)
        for commit in commit_list:
            branch = self.branches.get(commit.branch_id)
            if branch is None:
                raise KeyError(f"unknown branch {commit.branch_id!r}")
            if branch.checkpoint_id != checkpoint.checkpoint_id:
                raise ValueError("commit branch belongs to a different parent checkpoint")
            self.reducer.apply(commit, branch.status.value)
            branch.status = BranchStatus.COMMITTED

        delta = self.reducer.serialize_delta(commit_list)
        self.resolve(checkpoint)
        delta_text = semantic_delta_text(delta)
        prompt_token_ids = [
            *checkpoint.logical_token_ids,
            *self.backend.tokenize(delta_text),
        ]
        return prompt_token_ids

    def release(self, checkpoint: Checkpoint) -> None:
        self.backend.release_checkpoint(checkpoint)
        self._checkpoints.pop(checkpoint.checkpoint_id, None)

    def close(self) -> None:
        if self._closed:
            return
        try:
            for branch in self.branches.values():
                if branch.status in {BranchStatus.QUEUED, BranchStatus.RUNNING}:
                    self.backend.abort(branch.request_id)
                    branch.status = BranchStatus.ABORTED
        finally:
            try:
                self.backend.close()
            finally:
                self._checkpoints.clear()
                self._inline_requests.clear()
                self._closed = True

    def _run_captured_request(
        self, prompt_token_ids: list[int], **kwargs,
    ) -> BrainResult:
        internal_request_id = self._submit_captured_request(prompt_token_ids, **kwargs)
        output = self._wait_for_request(internal_request_id)
        return self._captured_result(internal_request_id, output)

    def _submit_captured_request(
        self,
        prompt_token_ids: list[int],
        *,
        max_new_tokens: int,
        ignore_eos: bool = False,
        checkpoint: Checkpoint | None = None,
        consumer_id: str | None = None,
        capture_intent: CheckpointIntent | None = None,
        schema_json: str | None = None,
        grammar: str | None = None,
        request_id: str | None = None,
        capture_checkpoint_id: str | None = None,
        inline_intent_checkpoints: Iterable[Checkpoint] | None = None,
    ) -> str:
        self._require_open()
        if grammar is not None and (schema_json is not None or inline_intent_checkpoints is not None):
            raise ValueError("grammar cannot be combined with a JSON schema or inline intent")
        if checkpoint is not None:
            self.backend.validate_checkpoint(checkpoint)
        inline = None
        if inline_intent_checkpoints is not None:
            self._require_inline_support(inline_intent_checkpoints)
            candidates = tuple(inline_intent_checkpoints)
            stream = InlineIntentStream(cp.checkpoint_id for cp in candidates)
            self._validate_model_checkpoints(candidates)
            if schema_json is None:
                raise ValueError("inline intent requires a normal Brain body schema")
            schema_json = json.dumps(inline_intent_schema(json.loads(schema_json)))
            inline = _PendingInlineIntent(stream, candidates, time.perf_counter())
        request_id = request_id or f"brain-{uuid.uuid4().hex}"
        checkpoint_id = capture_checkpoint_id or f"checkpoint-{uuid.uuid4().hex}"
        internal_request_id = self.backend.add_request(
            request_id=request_id,
            prompt_token_ids=prompt_token_ids,
            sampling_params=GenerationConfig(
                temperature=0,
                max_tokens=max_new_tokens,
                ignore_eos=ignore_eos,
                seed=self.backend.config.seed,
                schema_json=schema_json, grammar=grammar,
            ),
            checkpoint_id=checkpoint.checkpoint_id if checkpoint else None,
            capture_checkpoint_id=checkpoint_id,
            consumer_id=consumer_id,
            capture_intent=capture_intent,
        )
        if inline is not None:
            self._inline_requests[internal_request_id] = inline
        return internal_request_id

    def _captured_result(self, internal_request_id, output) -> BrainResult:
        if output.error is not None or output.finish_reason == "abort":
            self._inline_requests.pop(internal_request_id, None)
            raise RuntimeError(output.error or f"request {internal_request_id!r} aborted")
        completion = output
        inline_result = None
        if inline := self._inline_requests.get(internal_request_id):
            body = inline.stream.finish(completion.text)
            if inline.ready is None or inline.stream.checkpoint_id is None:
                raise ValueError("inline choice was not observed in the stream")
            inline_result = InlineIntentResult(
                inline.stream.checkpoint_id, body, *inline.ready, inline.applied,
                inline.native_receipt,
            )
            del self._inline_requests[internal_request_id]
        captured = self.backend.get_checkpoint_for_request(
            internal_request_id
        )
        self._checkpoints[captured.checkpoint_id] = captured
        return BrainResult(
            request_id=internal_request_id,
            output_token_ids=tuple(completion.token_ids),
            text=completion.text,
            finish_reason=completion.finish_reason,
            checkpoint=captured,
            inline_intent=inline_result,
        )

    def _accept_inline_output(self, request_id: str, output) -> None:
        inline = self._inline_requests.get(request_id)
        if inline is None:
            return
        completion = output
        if inline.stream.read(completion.text) is not None:
            inline.ready = (time.perf_counter() - inline.submitted_at, len(completion.token_ids))
            if self.backend.capabilities.dynamic_intent:
                self.apply_model_intents(inline.stream.payload(), checkpoints=inline.checkpoints,
                                         producer_request_id=request_id)
                inline.applied = True
                inline.native_receipt = self._last_intent_receipt

    def _wait_for_request(self, request_id: str):
        while self.backend.has_unfinished_requests():
            for output in self.backend.poll():
                if output.internal_request_id == request_id:
                    self._accept_inline_output(request_id, output)
                    if output.finished:
                        return output
        raise RuntimeError(f"request {request_id!r} ended without a final output")

    def _require_inline_support(self, checkpoints) -> None:
        if checkpoints is not None and not self.backend.capabilities.inline_intent:
            raise UnsupportedBackendFeature("this backend does not support inline intent")

    def _require_no_pending_branches(self) -> None:
        self._require_open()
        if self.has_pending_branches():
            raise RuntimeError("Brain execution requires all branches to terminate")

    def _require_open(self) -> None:
        if self._closed:
            raise RuntimeError("runtime is closed")

    def _expects_structured_commit(self, branch: Branch) -> bool:
        return branch.structured_commit


class CaseSession(Octopus):
    """Explicit cooperative logical owner on a shared backend, never its engine owner.

    The caller alone steps the engine and broadcasts outputs to accept_outputs.
    Legacy Octopus's global commit barrier and engine ownership are unchanged.
    """

    def __init__(self, backend: InferenceBackend, case_id: str) -> None:
        self.backend = backend
        self.case_id = case_id
        self.reducer = StateReducer()
        self.branches = {}
        self._request_to_branch = {}
        self._checkpoints = {}
        self._inline_requests = {}
        self._closed = False
        self.request_ids: set[str] = set()
        self._pending_brain: str | None = None
        self._brain_output = None
        self._brain_sequence = 0
        self._capture_checkpoint_ids: set[str] = set()

    def _submit_captured_request(self, prompt_token_ids, **kwargs):
        name = f"{self.case_id}-brain-{self._brain_sequence}"
        self._brain_sequence += 1
        request_id = super()._submit_captured_request(
            prompt_token_ids, request_id=name, capture_checkpoint_id=f"checkpoint:{name}", **kwargs,
        )
        self._capture_checkpoint_ids.add(f"checkpoint:{name}")
        return request_id

    def start_brain(self, prompt, **kwargs) -> None:
        self._require_no_pending_branches()
        if self._pending_brain is not None:
            raise RuntimeError("case already has a pending Brain request")
        self._pending_brain = self._submit_captured_request(list(prompt), **kwargs)
        self.request_ids.add(self._pending_brain)

    def start_commit(self, checkpoint, commits, *, final_schema_json, **kwargs) -> None:
        self._require_inline_support(kwargs.get("inline_intent_checkpoints"))
        self.backend.validate_generation(GenerationConfig(
            kwargs["max_new_tokens"], seed=self.backend.config.seed,
            schema_json=final_schema_json, grammar=kwargs.get("grammar"),
            ignore_eos=kwargs.get("ignore_eos", False),
        ), capture_intent=kwargs.get("capture_intent"))
        self.start_brain(
            self._commit_prompt(checkpoint, commits), checkpoint=checkpoint,
            schema_json=final_schema_json, **kwargs,
        )

    def take_brain(self) -> BrainResult | None:
        if self._brain_output is None:
            return None
        result = self._captured_result(self._pending_brain, self._brain_output)
        self._pending_brain = self._brain_output = None
        return result

    def _branch_submitted(self, branch: Branch) -> None:
        self.request_ids.add(branch.request_id)
        if branch.capture_checkpoint_id is not None:
            self._capture_checkpoint_ids.add(branch.capture_checkpoint_id)
        super()._branch_submitted(branch)
        stage = branch.branch_id.removeprefix(self.case_id + "-")
        self.observe(Event("stage_start", branch.checkpoint_id,
                           self.backend.clock(), node_id=branch.branch_id,
                           tool_kind=f"gpu-branch:{stage}"))

    def accept_outputs(self, outputs):
        outputs = self.backend.normalize_events(outputs)
        if self._pending_brain is not None:
            for output in outputs:
                if output.internal_request_id == self._pending_brain:
                    self._accept_inline_output(self._pending_brain, output)
                    if output.finished:
                        self._brain_output = output
        changed = super().accept_outputs(outputs)
        for branch in changed:
            if branch.status in {BranchStatus.COMMIT_READY, BranchStatus.FAILED}:
                self.observe(Event(
                    "stage_complete" if branch.status == BranchStatus.COMMIT_READY else "stage_fail",
                    branch.checkpoint_id, self.backend.clock(), node_id=branch.branch_id,
                ))
        return changed

    def step(self):
        raise RuntimeError("CaseSession cannot step a shared engine; use accept_outputs")

    def run_brain(self, *args, **kwargs):
        raise RuntimeError("CaseSession requires cooperative start_brain/take_brain")

    def commit(self, *args, **kwargs):
        raise RuntimeError("CaseSession requires cooperative start_commit/take_brain")

    def release(self, checkpoint):
        super().release(checkpoint)
        self._capture_checkpoint_ids.discard(checkpoint.checkpoint_id)

    def close(self):
        if self._closed:
            return
        for rid in self.request_ids:
            if self.backend.is_request_active(rid):
                self.backend.abort(rid)
        for branch in self.branches.values():
            if branch.status in {BranchStatus.QUEUED, BranchStatus.RUNNING}:
                branch.status = BranchStatus.ABORTED
        for checkpoint_id in tuple(self._capture_checkpoint_ids):
            if self.backend.checkpoint_is_open(checkpoint_id):
                self.release(self.backend.get_checkpoint(checkpoint_id))
        self._capture_checkpoint_ids.clear()
        self._inline_requests.clear()
        self._pending_brain = self._brain_output = None
        self._closed = True
