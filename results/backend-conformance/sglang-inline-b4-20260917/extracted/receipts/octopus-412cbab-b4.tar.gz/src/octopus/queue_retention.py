"""Local dense-APC free-LRU preference, informed only by ready waiting prefixes.

Inspired by the semantics of the unmerged vllm-project/vllm#54366, not a
backport or an assertion that vLLM 0.28.0 ships that feature.
"""
from __future__ import annotations

import time
from collections.abc import Callable, Hashable, Sequence
from typing import Any

from vllm.v1.core.kv_cache_utils import FreeKVCacheBlockQueue, KVCacheBlock

from octopus.retention_audit import DrawAudit

BlockKey = tuple[int, Hashable]


class QueueRetention:
    def __init__(
        self,
        native: FreeKVCacheBlockQueue,
        ready_prefixes: Callable[[], frozenset[BlockKey]],
        future_prefixes: Callable[[], frozenset[BlockKey]] | None = None,
    ) -> None:
        self.native = native
        self.ready_prefixes = ready_prefixes
        self.future_prefixes = future_prefixes
        self._future: frozenset[BlockKey] = frozenset()
        self._preferred: frozenset[BlockKey] | None = None
        self.snapshot_count = 0
        self.preferred_blocks_taken = 0
        self.cpu_seconds = 0.0

    def __getattr__(self, name: str) -> Any:
        return getattr(self.native, name)

    def invalidate(self) -> None:
        self._preferred = None
        self._future = frozenset()

    def begin_measurement(self) -> None:
        self.invalidate()
        self.snapshot_count = 0
        self.preferred_blocks_taken = 0
        self.cpu_seconds = 0.0

    def _select_blocks(self, n: int) -> tuple[list[KVCacheBlock], int]:
        assert self._preferred is not None
        selected, future, deferred = [], [], []
        block = self.native.fake_free_list_head.next_free_block
        tail = self.native.fake_free_list_tail
        while block is not tail and len(selected) < n:
            assert block is not None
            key = (block.block_id, block.block_hash)
            if key in self._preferred:
                deferred.append(block)
            elif key in self._future:
                future.append(block)
            else:
                selected.append(block)
            block = block.next_free_block
        needed = n - len(selected)
        selected.extend((future + deferred)[:needed])
        return selected, needed

    def popleft(self) -> KVCacheBlock:
        if not self.native.num_free_blocks:
            return self.native.popleft()
        return self.popleft_n(1)[0]

    def popleft_n(self, n: int) -> list[KVCacheBlock]:
        if n == 0:
            return self.native.popleft_n(n)
        started = time.perf_counter()
        try:
            assert self.native.num_free_blocks >= n
            head = self.native.fake_free_list_head
            tail = self.native.fake_free_list_tail
            if self._preferred is None:
                # Do not inspect waiting requests when ordinary cold allocation
                # cannot evict a prefix.
                block = head.next_free_block
                for _ in range(n):
                    assert block is not None and block is not tail
                    if block.block_hash is not None:
                        break
                    block = block.next_free_block
                else:
                    return self.native.popleft_n(n)
                self._preferred = self.ready_prefixes()
                self._future = self.future_prefixes() if self.future_prefixes else frozenset()
                self.snapshot_count += 1
            if not self._preferred and not self._future:
                return self.native.popleft_n(n)
            selected, needed = self._select_blocks(n)
            self.preferred_blocks_taken += needed
            # remove() preserves every remaining block's original LRU position.
            # No touch/ref increment occurs here; native get_new_blocks owns it.
            for block in selected:
                self.native.remove(block)
            return selected
        finally:
            self.cpu_seconds += time.perf_counter() - started


class B6Retention(QueueRetention):
    """Per-native-draw FREE preference: queued > future > ordinary LRU."""

    def __init__(
        self, native: FreeKVCacheBlockQueue,
        queued_prefixes: Callable[[], frozenset[BlockKey]],
        future_prefixes: Callable[[], tuple[BlockKey, ...]],
        *, blocks: Sequence[KVCacheBlock], budgeted: bool,
        order_future: Callable[[tuple[BlockKey, ...], int], tuple[tuple[BlockKey, ...], dict]] | None = None,
        changed_blocks: Callable[[Sequence[KVCacheBlock]], None] | None = None,
        admit_future: Callable | None = None,
    ) -> None:
        super().__init__(native, queued_prefixes)
        self.blocks = blocks
        self.ordered_future_prefixes = future_prefixes
        self.budgeted = budgeted
        self.order_future = order_future
        self.changed_blocks = changed_blocks
        self.admit_future = admit_future
        self.draw_records: list[DrawAudit] = []
        self.audit_decode_cpu_seconds = 0.0
        self._future_input: tuple[BlockKey, ...] | None = None
        self._input_keys: frozenset[BlockKey] = frozenset()
        self._eligible_future: tuple[BlockKey, ...] = ()
        self._eligible_keys: frozenset[BlockKey] = frozenset()
        self._queued: frozenset[BlockKey] = frozenset()
        self._queued_input: frozenset[BlockKey] | None = None
        self._queued_membership_dirty = True
        self._membership_dirty = True
        self._selection_future: frozenset[BlockKey] = frozenset()
        self._cursor: KVCacheBlock | None = None

    @property
    def draws(self) -> list[dict]:
        started = time.perf_counter()
        cache = {}
        result = [draw.decode(cache) for draw in self.draw_records]
        self.audit_decode_cpu_seconds += time.perf_counter() - started
        return result

    def _changed(self, blocks: Sequence[KVCacheBlock], *, prepend: bool = False) -> None:
        if self.changed_blocks is not None:
            self.changed_blocks(blocks)
        for block in blocks:
            key = (block.block_id, block.block_hash)
            if key in self._input_keys:
                self._membership_dirty = True
            if self._queued_input and key in self._queued_input:
                self._queued_membership_dirty = True
            if block is self._cursor:
                self._cursor = None
        if prepend:
            self._cursor = None

    def remove(self, block: KVCacheBlock) -> None:
        self.native.remove(block)
        self._changed((block,))

    def append(self, block: KVCacheBlock) -> None:
        self.native.append(block)
        self._changed((block,))

    def append_n(self, blocks: list[KVCacheBlock]) -> None:
        self.native.append_n(blocks)
        if blocks:
            self._changed(blocks)

    def prepend_n(self, blocks: list[KVCacheBlock]) -> None:
        self.native.prepend_n(blocks)
        if blocks:
            self._changed(blocks, prepend=True)

    def _is_free_key(self, key: BlockKey) -> bool:
        identity, block_hash = key
        if not 0 <= identity < len(self.blocks):
            return False
        block = self.blocks[identity]
        return (block.prev_free_block is not None and block.next_free_block is not None
                and block.block_hash == block_hash)

    def begin_measurement(self) -> None:
        super().begin_measurement()
        self.draw_records.clear()
        self.audit_decode_cpu_seconds = 0.0

    def _select_blocks(self, n: int) -> tuple[list[KVCacheBlock], int]:
        selected = []
        cursor = self._cursor
        block = cursor.next_free_block if cursor is not None else self.native.fake_free_list_head.next_free_block
        tail = self.native.fake_free_list_tail
        while block is not tail and len(selected) < n:
            assert block is not None
            key = (block.block_id, block.block_hash)
            if key in self._preferred or key in self._future:
                cursor = block
            else:
                selected.append(block)
            block = block.next_free_block
        if len(selected) < n:
            self._cursor = None
            return super()._select_blocks(n)
        self._cursor = cursor
        return selected, 0

    def popleft_n(self, n: int) -> list[KVCacheBlock]:
        if n == 0:
            return self.native.popleft_n(n)
        started = time.perf_counter()
        try:
            free = self.native.num_free_blocks
            assert free >= n
            queued_input = self.ready_prefixes()
            if queued_input is not self._queued_input or self._queued_membership_dirty:
                queued = frozenset(key for key in queued_input if self._is_free_key(key))
                self._queued_input = queued_input
                self._queued_membership_dirty = False
            else:
                queued = self._queued
            future_input = self.ordered_future_prefixes()
            if future_input is not self._future_input or self._membership_dirty or queued != self._queued:
                self._input_keys = frozenset(future_input)
                self._eligible_future = tuple(dict.fromkeys(
                    key for key in future_input if self._is_free_key(key) and key not in queued
                ))
                self._eligible_keys = frozenset(self._eligible_future)
                self._future_input = future_input
                self._membership_dirty = False
                self._cursor = None
            self._queued = queued
            future = self._eligible_future
            cap = max(0, free - n - len(queued))
            evidence = {}
            if self.order_future is not None:
                blocks = self.native.get_all_free_blocks()
                baseline = set(future[:cap])
                counterfactual = sorted(blocks, key=lambda b: (
                    2 if (b.block_id, b.block_hash) in queued else
                    1 if (b.block_id, b.block_hash) in baseline else 0
                ))[:n]
                future, evidence = self.order_future(future, cap)
                evidence["b6_counterfactual_reclaimed"] = [
                    (b.block_id, b.block_hash.hex() if isinstance(b.block_hash, bytes) else str(b.block_hash))
                    for b in counterfactual
                ]
            self._preferred = queued
            self._future = (
                frozenset(future[:cap]) if self.budgeted and len(future) > cap
                else self._eligible_keys
            )
            if self.admit_future is not None:
                self._future, decision = self.admit_future(
                    future, self._eligible_keys, queued, free, n, cap,
                )
                cap = decision.capacity
                evidence["value_admission"] = decision
            if self._selection_future != self._future:
                self._cursor = None
            self._selection_future = self._future
            self.snapshot_count += 1
            selected, _ = self._select_blocks(n)
            selected_keys = tuple((b.block_id, b.block_hash) for b in selected)
            taken = sum(key in queued or key in self._future for key in selected_keys)
            self.preferred_blocks_taken += taken
            self.draw_records.append(DrawAudit(
                free, n, queued, future, self._future, selected_keys,
                self.budgeted, cap, evidence,
            ))
            for block in selected:
                self.native.remove(block)
            if taken or (self.budgeted and any(key in self._input_keys for key in selected_keys)):
                self._membership_dirty = True
                self._queued_membership_dirty = True
                self._cursor = None
                if self.changed_blocks is not None:
                    self.changed_blocks(selected)
            return selected
        finally:
            self.cpu_seconds += time.perf_counter() - started
