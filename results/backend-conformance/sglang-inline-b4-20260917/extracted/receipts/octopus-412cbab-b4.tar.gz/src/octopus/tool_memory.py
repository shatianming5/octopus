"""Persistent tool observations and episode-local failed-action constraints."""
from __future__ import annotations

import hashlib
import json
import posixpath
from copy import deepcopy
from dataclasses import asdict, dataclass, field
from typing import Callable

from octopus.state import JSONValue

Action = dict[str, JSONValue]
Observation = dict[str, JSONValue]


def action_hash(action: Action) -> str:
    canonical = json.dumps(action, sort_keys=True, ensure_ascii=True, separators=(",", ":"))
    return hashlib.sha256(canonical.encode()).hexdigest()


def _resource(action: Action) -> str | None:
    path = action.get("path")
    return posixpath.normpath(path) if isinstance(path, str) else None


@dataclass(frozen=True, slots=True)
class ToolRecord:
    action_hash: str
    success: bool
    error_type: str | None
    affected_resource: str | None


@dataclass(slots=True)
class FailureMemory:
    records: list[ToolRecord] = field(default_factory=list)
    rejected_proposals: int = 0
    _failed: dict[str, dict[str, JSONValue]] = field(default_factory=dict)
    _failure_history: list[dict[str, JSONValue]] = field(default_factory=list, init=False)
    _refresh_required: set[str] = field(default_factory=set)
    recover_missing_paths: bool = False
    _path_discovery_required: bool = field(default=False, init=False)
    require_successful_verification: bool = False
    verification_required: bool = field(default=False, init=False)
    canonicalize_action: Callable[[Action], Action] | None = field(default=None, repr=False)
    state_scoped_failures: bool = False
    _workspace_revision: int = field(default=0, init=False)
    _resource_revisions: dict[str, int] = field(default_factory=dict, init=False)

    @property
    def path_discovery_required(self) -> bool:
        return self._path_discovery_required

    @property
    def recovery_resources(self) -> tuple[str, ...]:
        return tuple(sorted(self._refresh_required))

    def _fingerprint(self, action: Action) -> str:
        return action_hash(self.canonicalize_action(action) if self.canonicalize_action else action)

    def _certificate_is_active(self, certificate: dict[str, JSONValue]) -> bool:
        if not self.state_scoped_failures:
            return True
        scope = certificate["failure_scope"]
        if scope == "workspace":
            return certificate["failure_revision"] == self._workspace_revision
        if scope == "resource":
            resource = certificate["affected_resource"]
            return (
                isinstance(resource, str)
                and certificate["failure_revision"] == self._resource_revisions.get(resource, 0)
            )
        return True

    def _active_failure(self, fingerprint: str) -> dict[str, JSONValue] | None:
        certificate = self._failed.get(fingerprint)
        if certificate is None or not self._certificate_is_active(certificate):
            return None
        return certificate

    def _is_path_inspection(self, action: Action) -> bool:
        resource = _resource(action)
        kinds = ("list", "search", "read", "view", "find") if self.state_scoped_failures else ("list", "search")
        return (
            resource is not None and action["action"] in kinds
            and (self.state_scoped_failures or resource == ".")
        )

    def rejection_reason(self, action: Action) -> str | None:
        if self._active_failure(self._fingerprint(action)) is not None:
            return "repeated_failed_action"
        if self._path_discovery_required and not self._is_path_inspection(action):
            return "path_discovery_required"
        if self._refresh_required:
            inspections = ("read", "search", "view") if self.state_scoped_failures else ("read", "search")
            if action["action"] not in inspections:
                return "evidence_refresh_required"
            if self.state_scoped_failures and _resource(action) not in self._refresh_required:
                return "evidence_refresh_required"
        if self.verification_required and action["action"] == "done":
            return "verification_required"
        return None

    def execute(
        self, action: Action, tool: Callable[[Action], Observation],
    ) -> Observation:
        fingerprint = self._fingerprint(action)
        proposal_hash = action_hash(action)
        proposal_metadata = {"proposal_hash": proposal_hash} if proposal_hash != fingerprint else {}
        reason = self.rejection_reason(action)
        if reason is not None:
            self.rejected_proposals += 1
            active_failure = self._active_failure(fingerprint)
            if (
                self.recover_missing_paths
                and reason == "repeated_failed_action"
                and active_failure is not None
                and active_failure["error_type"] == "missing_path"
            ):
                self._path_discovery_required = True
            return {
                "tool_error": True,
                "action_rejected": True,
                "action_submitted": False,
                "action_hash": fingerprint,
                **proposal_metadata,
                "error_type": reason,
                "error": (
                    f"This {'effective' if self.canonicalize_action else 'exact'} action already failed "
                    "and cannot be submitted again."
                    if reason == "repeated_failed_action" else
                    (
                        "Inspect an existing repository file or directory successfully before another action."
                        if self.state_scoped_failures else
                        "Discover repository paths using list/search at the repository root '.' first."
                    )
                    if reason == "path_discovery_required" else
                    "A changed workspace or failed test needs a successful test before done."
                    if reason == "verification_required" else
                    (
                        "Read, search, or view the affected file successfully before another action."
                        if self.state_scoped_failures else
                        "Read or search the affected file successfully before another action."
                    )
                ),
                "recovery_resources": list(self.recovery_resources),
            }

        observation = tool(action)
        if type(observation["tool_error"]) is not bool:
            raise ValueError("tool observation requires a boolean tool_error")
        error_type = self._error_type(action, observation)
        resource = _resource(action)
        # This field comes from the trusted tool controller, never parsed shell stdout.
        changes = observation.get("changed_resources")
        if changes is not None:
            if not isinstance(changes, list) or any(not isinstance(path, str) for path in changes):
                raise ValueError("controller changed_resources must be a list of paths")
            mutated = set(changes)
        else:
            mutated = ({resource} if resource is not None and error_type is None
                       and self._is_workspace_mutation(action, resource) else set())
        if mutated:
            self._workspace_revision += 1
            for changed in mutated:
                self._resource_revisions[changed] = self._resource_revisions.get(changed, 0) + 1
            if self.state_scoped_failures:
                self._path_discovery_required = False
        record = ToolRecord(fingerprint, error_type is None, error_type, resource)
        self.records.append(record)
        if error_type is not None:
            failure = {**asdict(record), "action": deepcopy(action)}
            if self.canonicalize_action:
                execution_action = self.canonicalize_action(action)
                if execution_action != action:
                    failure["execution_action"] = deepcopy(execution_action)
            if self.state_scoped_failures:
                scope, revision = self._failure_scope(error_type, action, resource)
                failure["failure_scope"] = scope
                failure["failure_revision"] = revision
                self._failure_history.append(failure)
            self._failed[fingerprint] = failure
            if error_type == "edit_precondition_mismatch" and resource is not None:
                self._refresh_required.add(resource)
            if error_type == "missing_path" and self.recover_missing_paths:
                self._path_discovery_required = True
        elif self._is_successful_refresh(action, observation, resource):
            self._refresh_required.discard(resource)
        if (
            error_type is None
            and self._is_path_inspection(action)
            and observation.get("output")
            and (
                action["action"] != "view"
                or observation.get("view_kind") == "directory"
                or (self.state_scoped_failures and resource != "."
                    and observation.get("view_kind") == "file"
                    and observation.get("returned_lines", 1) != 0)
            )
        ):
            self._path_discovery_required = False
        if self.require_successful_verification:
            if action["action"] == "test":
                self.verification_required = not record.success
            elif (bool(mutated) if changes is not None else
                  record.success and action["action"] in ("edit", "write")):
                self.verification_required = True
        return {
            **observation,
            "action_submitted": observation.get("action_submitted", True),
            "action_rejected": False,
            "action_hash": fingerprint,
            **proposal_metadata,
            "success": record.success,
            "error_type": error_type,
            "affected_resource": resource,
        }

    def _failure_scope(
        self, error_type: str, action: Action, resource: str | None,
    ) -> tuple[str, int | None]:
        if error_type in ("test_failure", "tool_timeout") and action["action"] == "test":
            return "workspace", self._workspace_revision
        if action["action"] == "shell":
            return "workspace", self._workspace_revision
        if error_type in ("edit_precondition_mismatch", "view_range_out_of_bounds") and resource is not None:
            return "resource", self._resource_revisions.get(resource, 0)
        if error_type == "missing_path":
            return "workspace", self._workspace_revision
        return "permanent", None

    def _is_successful_refresh(
        self, action: Action, observation: Observation, resource: str | None,
    ) -> bool:
        if resource is None or not observation.get("output"):
            return False
        if action["action"] in ("read", "search"):
            return not (
                action["action"] == "search" and observation.get("search_result_format") == "matching_files_v1"
            )
        return (
            self.state_scoped_failures
            and action["action"] == "view"
            and observation.get("view_kind") == "file"
            and observation.get("returned_lines", 1) != 0
        )

    @staticmethod
    def _is_workspace_mutation(action: Action, resource: str | None) -> bool:
        if resource is None:
            return False
        if action["action"] == "write":
            return True
        return (
            action["action"] == "edit"
            and isinstance(action.get("old"), str)
            and isinstance(action.get("new"), str)
            and action["old"] != action["new"]
        )

    @staticmethod
    def _error_type(action: Action, observation: Observation) -> str | None:
        if observation["tool_error"]:
            if observation.get("timed_out"):
                return "tool_timeout"
            explicit = observation.get("error_type")
            if isinstance(explicit, str) and explicit:
                return explicit
            error = observation.get("error", "")
            if (
                action["action"] == "edit"
                and error == "ValueError: edit old text must match exactly once"
            ):
                return "edit_precondition_mismatch"
            if isinstance(error, str) and error.startswith("FileNotFoundError:"):
                return "missing_path"
            return "tool_error"
        if action["action"] == "test":
            if observation.get("timed_out"):
                return "tool_timeout"
            if observation["exit_code"] != 0:
                return "test_failure"
        return None

    def to_dict(self) -> dict[str, JSONValue]:
        state: dict[str, JSONValue] = {
            "observations": [asdict(record) for record in self.records],
            "failed_actions": deepcopy(
                self._failure_history if self.state_scoped_failures else list(self._failed.values())
            ),
            "recovery_resources": list(self.recovery_resources),
            "rejected_proposals": self.rejected_proposals,
        }
        if self.state_scoped_failures:
            state["workspace_revision"] = self._workspace_revision
            state["resource_revisions"] = deepcopy(self._resource_revisions)
        if self.recover_missing_paths:
            state["path_discovery_required"] = self._path_discovery_required
        if self.require_successful_verification:
            state["verification_required"] = self.verification_required
        return state

    def prompt_state(self) -> dict[str, JSONValue]:
        if not self.state_scoped_failures:
            return self.to_dict()
        state: dict[str, JSONValue] = {
            "failed_actions": deepcopy([
                failure for failure in self._failure_history
                if self._certificate_is_active(failure)
            ]),
            "recovery_resources": list(self.recovery_resources),
            "workspace_revision": self._workspace_revision,
            "resource_revisions": deepcopy(self._resource_revisions),
        }
        if self.recover_missing_paths:
            state["path_discovery_required"] = self._path_discovery_required
        if self.require_successful_verification:
            state["verification_required"] = self.verification_required
        return state
