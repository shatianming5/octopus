"""Native admission learned only from committed initial cached adoption."""
from dataclasses import dataclass, field
import time

from octopus.retention_audit import encode
from octopus.value_admission import ValueDecision, ValueNode, allocate_prefixes, project_native_preferences


def live_free(block):
    return (not block.is_null and block.block_hash is not None and block.ref_cnt == 0
            and block.prev_free_block is not None and block.next_free_block is not None)


class ConfirmedHistory:
    def __init__(self, scheduler):
        self.s = scheduler
        self.prefixes = {}
        self.seen_requests = set()
        self.version = 0
        self.events = []

    def reset(self):
        self.prefixes.clear()
        self.seen_requests.clear()
        self.version += 1

    def observe(self, request, adoption):
        tokens = adoption.adopted_prefix_tokens
        if (tokens is None or adoption.preemption_episode
                or request.request_id in self.seen_requests):
            return
        self.seen_requests.add(request.request_id)
        if tokens <= 0:
            return
        size = self.s.block_size
        hashes = tuple(request.block_hashes[:tokens // size])
        if not hashes:
            return
        endpoint = hashes[-1]
        entry = self.prefixes.setdefault(endpoint, {"hashes": hashes, "adopters": set()})
        entry["adopters"].add(request.request_id)
        self.version += 1
        self.events.append({
            "at": adoption.at, "request_id": request.request_id,
            "adopted_prefix_tokens": len(hashes) * size,
            "endpoint": endpoint.hex(), "source": "confirmed_initial_cached_adoption",
        })

    def native_views(self):
        from vllm.v1.core.kv_cache_utils import make_block_hash_with_group_id
        from vllm.v1.kv_cache_interface import FullAttentionSpec
        manager = self.s.kv_cache_manager
        groups = manager.kv_cache_config.kv_cache_groups
        if len(groups) != 1 or not isinstance(groups[0].kv_cache_spec, FullAttentionSpec):
            raise ValueError("history family requires the pinned dense single-group producer")
        mapping = manager.block_pool.cached_block_hash_to_block
        views, signature = {}, []
        for endpoint, entry in self.prefixes.items():
            blocks = []
            for h in entry["hashes"]:
                grouped = make_block_hash_with_group_id(h, 0)
                block = mapping.get_one_block(grouped)
                if block is None:
                    break
                blocks.append(block)
                copies = mapping._cache[grouped]
                copies = list(copies.values()) if isinstance(copies, dict) else [copies]
                signature.append((grouped, block.block_id,
                                  tuple((b.block_id, b.ref_cnt > 0, live_free(b)) for b in copies)))
            views[endpoint] = tuple(blocks)
        return views, tuple(signature)


class NextReuseHistory(ConfirmedHistory):
    """Keep observations, but consume each block's outstanding support once."""

    def __init__(self, scheduler):
        super().__init__(scheduler)
        self.pending = {}
        self.episodes = {}
        self.support_events = []
        self.epoch = 0

    def reset(self):
        self.support_events.append({
            "kind": "reset", "at": self.s.clock(), "epoch": self.epoch,
            "cleared": [[h.hex(), episode] for h, episode in self.pending.items()],
        })
        super().reset()
        self.pending.clear()
        self.episodes.clear()
        self.epoch += 1

    def observe(self, request, adoption):
        tokens = adoption.adopted_prefix_tokens
        if (tokens is None or adoption.preemption_episode
                or request.request_id in self.seen_requests):
            return
        size = self.s.block_size
        prompt = request.block_hashes[:request.num_prompt_tokens // size]
        consumed = {h: self.pending.pop(h) for h in prompt if h in self.pending}
        opened, reopened = {}, {}
        for h in request.block_hashes[:tokens // size]:
            if h in consumed:
                continue
            episode = self.episodes.get(h, 0) + 1
            self.episodes[h] = self.pending[h] = episode
            (reopened if episode > 1 else opened)[h] = episode
        super().observe(request, adoption)
        if consumed or opened or reopened:
            self.version += 1
            adopted = set(request.block_hashes[:tokens // size])
            self.support_events.append({
                "kind": "initial_scheduled_use", "at": adoption.at,
                "request_id": request.request_id, "epoch": self.epoch,
                "opened": [[h.hex(), episode] for h, episode in opened.items()],
                "reopened": [[h.hex(), episode] for h, episode in reopened.items()],
                "consumed": [
                    {"logical_hash": h.hex(), "episode": episode, "cached": h in adopted}
                    for h, episode in consumed.items()
                ],
            })


@dataclass
class HistoryDecision(ValueDecision):
    history_metadata: dict = field(default_factory=dict)

    def decode(self):
        result = super().decode()
        result.update(self.history_metadata)
        zero = {tuple(key) for key in self.history_metadata.get("zero_support_rejected_keys", ())}
        for node in result["nodes"]:
            if tuple(node["key"]) in zero:
                node["drop_reason"] = "resolved_history_support"
        return result


class HistoryAdmission:
    """Same candidate information, either blanket preference or one value rule."""

    def __init__(self, scheduler, mode):
        if mode not in {"blanket", "selective", "next_reuse"}:
            raise ValueError("history mode must be blanket, selective or next_reuse")
        self.s, self.mode = scheduler, mode
        self.base = scheduler.value_admission
        self.history = NextReuseHistory(scheduler) if mode == "next_reuse" else ConfirmedHistory(scheduler)
        self.history_grants = {}
        self.support_grants = {}
        self._zero_rejected = frozenset()
        self.rejected = frozenset()
        self._semantic_provider = scheduler.queue_retention.ordered_future_prefixes
        self.maintenance_cpu_seconds = 0.0
        self._ordered = ()
        self._signature = self._semantic = None
        self._views = {}
        self._node_input = None
        self._nodes = ()
        self._users = self._sources = {}
        scheduler.value_admission = self
        scheduler.queue_retention.ordered_future_prefixes = self.provider
        scheduler.queue_retention.admit_future = self.select
        scheduler.queue_retention.budgeted = mode != "blanket"
        scheduler.committed_adoption_callback = self.observe_scheduled

    def observe_scheduled(self, request, adoption):
        started = time.process_time()
        try:
            self.history.observe(request, adoption)
            if self.mode == "next_reuse":
                self.support_grants = {
                    h: episode for h, episode in self.support_grants.items()
                    if self.history.pending.get(h) == episode
                }
        finally:
            self.maintenance_cpu_seconds += time.process_time() - started

    def reset(self):
        started = time.process_time()
        self.base.reset()
        self.history.reset()
        self.history_grants.clear()
        self.support_grants.clear()
        self._zero_rejected = frozenset()
        self.rejected = frozenset()
        self._signature = self._semantic = self._node_input = None
        self.maintenance_cpu_seconds += time.process_time() - started

    def provider(self):
        semantic = self._semantic_provider()
        views, native_signature = self.history.native_views()
        signature = (self.history.version, native_signature)
        if semantic is not self._semantic or signature != self._signature:
            keys = dict.fromkeys(semantic)
            for blocks in views.values():
                for block in blocks:
                    if live_free(block):
                        keys[block.block_id, block.block_hash] = None
            self._ordered = tuple(keys)
            self._views, self._semantic, self._signature = views, semantic, signature
            if self.mode == "next_reuse":
                allowed = set(semantic) | self.supported_history_keys(views)
                zero = frozenset(keys.keys() - allowed)
                self.rejected = (self.rejected - self._zero_rejected) | zero
                self._zero_rejected = zero
        return self._ordered

    def supported_history_keys(self, views):
        allowed = set()
        for endpoint, blocks in views.items():
            hashes = self.history.prefixes[endpoint]["hashes"]
            limit = max((i + 1 for i in range(len(blocks))
                         if hashes[i] in self.history.pending), default=0)
            allowed.update((b.block_id, b.block_hash) for b in blocks[:limit] if live_free(b))
        return allowed

    def _has_held_alternative(self, key):
        entry = self.s.kv_cache_manager.block_pool.cached_block_hash_to_block._cache[key[1]]
        return isinstance(entry, dict) and any(b.ref_cnt > 0 for b in entry.values())

    def _granted(self, future, eligible):
        keys = set(self.base._live_granted_keys(future, eligible))
        if self.mode == "next_reuse":
            for endpoint, blocks in self._views.items():
                hashes = self.history.prefixes[endpoint]["hashes"]
                limit = max((i + 1 for i in range(len(blocks))
                             if hashes[i] in self.support_grants
                             and self.support_grants[hashes[i]] == self.history.pending.get(hashes[i])), default=0)
                for block in blocks[:limit]:
                    key = block.block_id, block.block_hash
                    if key in eligible and not self._has_held_alternative(key):
                        keys.add(key)
            return frozenset(keys)
        for endpoint, limit in self.history_grants.items():
            for block in self._views.get(endpoint, ())[:limit]:
                key = block.block_id, block.block_hash
                if key in eligible and not self._has_held_alternative(key):
                    keys.add(key)
        return frozenset(keys)

    def _combined_nodes(self, future, eligible):
        if future is self._node_input:
            return self._nodes, self._users, self._sources
        nodes = list(self.base._binding_nodes(future, eligible))
        indices = {node.key: i for i, node in enumerate(nodes)}
        users, sources = {}, {}
        mapping = self.s.kv_cache_manager.block_pool.cached_block_hash_to_block
        size = self.s.block_size
        for endpoint, blocks in self._views.items():
            parent = None
            for depth, block in enumerate(blocks):
                key = block.block_id, block.block_hash
                if self.mode == "next_reuse":
                    h = self.history.prefixes[endpoint]["hashes"][depth]
                    users.setdefault(key, set()).update((h,) if h in self.history.pending else ())
                else:
                    users.setdefault(key, set()).update(self.history.prefixes[endpoint]["adopters"])
                sources.setdefault(key, {})[endpoint] = depth + 1
                if key not in indices:
                    entry = mapping._cache[key[1]]
                    copies = list(entry.values()) if isinstance(entry, dict) else [entry]
                    others = [b for b in copies if b.block_id != block.block_id]
                    held = tuple(b.block_id for b in others if b.ref_cnt > 0)
                    free = tuple(b.block_id for b in others if live_free(b))
                    end, start = (depth + 1) * size, depth * size
                    indices[key] = len(nodes)
                    nodes.append(ValueNode(
                        key, parent, depth, set(), key in eligible,
                        key not in eligible or bool(held), held, free,
                        self.base.hidden_size * size + (end * (end + 1) - start * (start + 1)) // 2,
                    ))
                parent = indices[key]
        self._node_input, self._nodes = future, tuple(nodes)
        self._users, self._sources = users, sources
        return self._nodes, users, sources

    def _register_grants(self, nodes, kept, sources):
        logical_new = self.base._admit(nodes, kept)
        new_support_grants = []
        for key in kept:
            for endpoint, depth in sources.get(key, {}).items():
                if self.mode == "next_reuse":
                    h = self.history.prefixes[endpoint]["hashes"][depth - 1]
                    episode = self.history.pending.get(h)
                    if episode is not None and self.support_grants.get(h) != episode:
                        self.support_grants[h] = episode
                        new_support_grants.append([h.hex(), episode])
                else:
                    self.history_grants[endpoint] = max(self.history_grants.get(endpoint, 0), depth)
        return logical_new, new_support_grants

    def select(self, future, eligible, queued, free, draw, capacity):
        commitment = self.s._running_prefill_commitment(draw)
        capacity = max(0, capacity - commitment["additional_blocks"])
        metadata = {
            "candidate_information_family": "confirmed_adoption_history_union_v1",
            "history_control": self.mode,
            "history_prefixes": [
                {"endpoint": h.hex(), "prefix_tokens": len(e["hashes"]) * self.s.block_size,
                 "distinct_initial_adopters": len(e["adopters"])}
                for h, e in self.history.prefixes.items()
            ],
            "history_value_rule": "W increment times max(remaining definite consumers,distinct observed initial adopters); no summed double count",
        }
        resolving = self.mode == "next_reuse"
        selectable = eligible - self._zero_rejected if resolving else eligible
        granted = self._granted(future, selectable) if self.mode != "blanket" else frozenset()
        if resolving:
            metadata.update({
                "history_value_rule": "W increment times max(remaining definite consumers,outstanding next-reuse support0or1)",
                "history_lifetime": "next_initial_scheduled_use; hit_or_miss; no_same_event_renewal; later_hit_can_reopen",
                "support_epoch": self.history.epoch, "support_version": self.history.version,
                "outstanding_support_blocks": len(self.history.pending),
                "zero_support_rejected_keys": encode(sorted(eligible - selectable)),
                "nonbinding_action": "REJECT_UNSUPPORTED_HISTORY_KEEP_SUPPORTED",
                "positive_keep_continuity": "same_soft_grant_on_binding_and_nonbinding_KEEP",
                "native_shortage_policy": "native_priority_tier_LRU",
                "support_binding": len(selectable) > capacity,
            })
        if self.mode == "blanket" or (len(selectable) if resolving else len(future)) <= capacity:
            new, logical_new = frozenset(), ()
            if resolving:
                new = selectable - granted
                new_support_grants = []
                if new:
                    nodes, _, sources = self._combined_nodes(future, eligible)
                    logical_new, new_support_grants = self._register_grants(nodes, new, sources)
                metadata["new_history_episode_grants"] = new_support_grants
                metadata["granted_history_episodes"] = len(self.support_grants)
                granted = selectable
            self.rejected = eligible - selectable
            return selectable, HistoryDecision(
                self.s.clock(), self.base.hidden_size, free, draw, len(queued), capacity,
                len(future), selectable, prefill_commitment=commitment, granted=granted,
                new_admissions=new, logical_grants=self.base._grant_snapshot,
                new_logical_grants=logical_new, reset_epoch=self.base.reset_epoch,
                history_metadata=metadata,
            )
        nodes, users, sources = self._combined_nodes(future, eligible)
        weights = {i: n.work_per_use * max(len(n.consumers), len(users.get(n.key, ())))
                   for i, n in enumerate(nodes)}
        room = max(0, capacity - len(granted))
        evaluate = len(selectable) > len(granted) and room > 0
        selected, rewards, packages = allocate_prefixes(
            nodes, room, granted, weights, allowed=selectable if resolving else None,
        ) if evaluate else (set(), {}, [])
        if resolving and selected:
            useful = set()
            for i in selected:
                if rewards[i] <= 0:
                    continue
                while i in selected and i not in useful:
                    useful.add(i)
                    i = nodes[i].parent
            selected = useful
            packages = [package for package in packages if package[1] > 0]
        new = frozenset(nodes[i].key for i in selected)
        kept = granted | new
        if not kept <= eligible:
            raise AssertionError("history selection expanded its matched candidate universe")
        logical_new, new_support_grants = self._register_grants(nodes, kept, sources)
        before = kept
        hard_packages = ()
        if not resolving:
            kept, hard_packages = project_native_preferences(
                nodes, before, max(0, free - draw - len(queued)), weights,
            )
        self.rejected = eligible - kept
        metadata["history_grants"] = [{"endpoint": h.hex(), "prefix_blocks": n} for h, n in self.history_grants.items()]
        if resolving:
            metadata["new_history_episode_grants"] = new_support_grants
            metadata["granted_history_episodes"] = len(self.support_grants)
        metadata["historical_node_evidence"] = [{
            "node": i, "distinct_observed_initial_adopters": len(set().union(*(
                self.history.prefixes[h]["adopters"] for h in sources.get(n.key, {})
            ))) if resolving else len(users.get(n.key, ())),
            "effective_value_units": max(len(n.consumers), len(users.get(n.key, ()))),
        } for i, n in enumerate(nodes) if n.key in users]
        return kept, HistoryDecision(
            self.s.clock(), self.base.hidden_size, free, draw, len(queued), capacity,
            len(future), kept, nodes, rewards, tuple(packages), commitment,
            before, new, self.base._grant_snapshot, evaluate, self.base.reset_epoch,
            logical_new, before, hard_packages, metadata,
        )
