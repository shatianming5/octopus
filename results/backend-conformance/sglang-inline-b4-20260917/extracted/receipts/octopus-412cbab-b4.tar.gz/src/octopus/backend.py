"""Inference seam: logical handles and cumulative events, never native KV objects."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable, Protocol

from octopus.admission import Calibration, Policy
from octopus.context import InheritanceMode
from octopus.model_intent import ModelIntent
from octopus.signals import CheckpointIntent, Event, Requirement


class UnsupportedBackendFeature(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class Checkpoint:
    """Logical restore handle. Native fields are snapshots, not residency.

    None means the engine cannot observe that physical fact. Handle identity
    and openness are validated by the owning adapter, not by dataclass equality.
    """
    checkpoint_id: str
    logical_token_ids: tuple[int, ...]
    shared_tokens: int | None
    tail_token_ids: tuple[int, ...] | None
    block_ids: tuple[tuple[int, ...], ...] | None
    block_size: int | None


@dataclass(frozen=True, slots=True)
class BackendConfig:
    """Legacy vLLM configuration, importable without installing an engine."""
    model: str = "Qwen/Qwen2.5-7B-Instruct"
    model_path: str | None = None
    dtype: str = "bfloat16"
    max_model_len: int = 32768
    max_num_seqs: int = 8
    max_num_batched_tokens: int = 8192
    block_size: int = 16
    kv_cache_memory_bytes: int | None = 8 * 1024**3
    gpu_memory_utilization: float = 0.9
    enable_prefix_caching: bool = True
    enable_chunked_prefill: bool = True
    enforce_eager: bool = True
    async_scheduling: bool = False
    seed: int = 17
    disable_log_stats: bool = True
    retention_policy: Policy = "hard_pin"
    admission_calibration: Calibration | None = None
    value_history_mode: str | None = None
    adoption_audit_enabled: bool = True
    tokenizer_path: str | None = None


class EngineConfig(Protocol):
    @property
    def max_model_len(self) -> int: ...
    @property
    def seed(self) -> int: ...


@dataclass(frozen=True, slots=True)
class GenerationConfig:
    max_tokens: int
    temperature: float = 0
    seed: int = 17
    ignore_eos: bool = False
    schema_json: str | None = None
    grammar: str | None = None

    def __post_init__(self) -> None:
        if self.max_tokens < 1:
            raise ValueError("max_tokens must be positive")
        if self.schema_json is not None and self.grammar is not None:
            raise ValueError("provide only one JSON schema or grammar")


@dataclass(frozen=True, slots=True)
class GenerationEvent:
    request_id: str
    internal_request_id: str
    prompt_token_ids: tuple[int, ...]
    token_ids: tuple[int, ...]
    text: str
    finished: bool
    finish_reason: str | None = None
    error: str | None = None
    cached_tokens: int | None = None


@dataclass(frozen=True, slots=True)
class BackendCapabilities:
    prefix_reuse: bool
    selective_inheritance: bool
    dynamic_intent: bool
    inline_intent: bool
    native_work_counters: bool
    session_cache_refs: bool = False


class InferenceBackend(Protocol):
    config: EngineConfig
    @property
    def capabilities(self) -> BackendCapabilities: ...
    def tokenize(self, text: str) -> list[int]: ...
    def render_chat(self, messages: list[dict[str, Any]], *,
                    tools: list[dict[str, Any]] | None = None,
                    add_generation_prompt: bool = False) -> str: ...
    def decode(self, token_ids: list[int] | tuple[int, ...]) -> str: ...
    def validate_generation(self, config: GenerationConfig, *,
                            capture_intent: CheckpointIntent | None = None) -> None: ...
    def validate_inheritance(self, mode: InheritanceMode) -> None: ...
    def validate_checkpoint(self, checkpoint: Checkpoint) -> None: ...
    def add_request(self, *, request_id: str, prompt_token_ids: list[int],
                    sampling_params: GenerationConfig, checkpoint_id: str | None = None,
                    capture_checkpoint_id: str | None = None,
                    consumer_id: str | None = None,
                    capture_intent: CheckpointIntent | None = None,
                    selected_parent_tokens: int | None = None,
                    capsule_tokens: int = 0) -> str: ...
    def poll(self) -> list[GenerationEvent]: ...
    def normalize_events(self, outputs: Iterable[Any]) -> list[GenerationEvent]: ...
    def external_request_id(self, internal_request_id: str) -> str: ...
    def has_unfinished_requests(self) -> bool: ...
    def is_request_active(self, request_id: str) -> bool: ...
    def abort(self, request_id: str) -> None: ...
    def get_checkpoint_for_request(self, request_id: str) -> Checkpoint: ...
    def get_checkpoint(self, checkpoint_id: str) -> Checkpoint: ...
    def checkpoint_is_open(self, checkpoint_id: str) -> bool: ...
    def release_checkpoint(self, checkpoint: Checkpoint) -> None: ...
    def observe(self, event: Event) -> None: ...
    def declare_gpu_consumer(self, checkpoint_id: str, consumer_id: str,
                             after: tuple[str, ...], *,
                             requirement: Requirement = Requirement.DEFINITE,
                             condition_id: str | None = None, condition_outcome: bool = True,
                             parent_prefix_tokens: int | None = None) -> None: ...
    def declare_no_gpu_consumers(self, checkpoint_id: str) -> None: ...
    def decide_condition(self, condition_id: str, outcome: bool) -> None: ...
    def cancel_gpu_consumer(self, consumer_id: str) -> None: ...
    def consumer_is_terminal(self, consumer_id: str) -> bool: ...
    def apply_model_intents(self, intents: dict[str, ModelIntent], *,
                            producer_request_id: str | None = None) -> dict | None: ...
    def clock(self) -> float: ...
    def close(self) -> None: ...


def default_backend(config: BackendConfig | None = None) -> InferenceBackend:
    try:
        from octopus.vllm_backend import VllmBackend
    except ImportError as exc:
        raise ImportError(
            "The selected vLLM backend is unavailable. Install its isolated "
            "environment with `uv sync --extra vllm` (do not combine engine extras)."
        ) from exc
    return VllmBackend(config or BackendConfig())
