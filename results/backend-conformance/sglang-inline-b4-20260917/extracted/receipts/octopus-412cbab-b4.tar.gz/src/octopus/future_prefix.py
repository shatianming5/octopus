"""Incremental B6 checkpoint prefixes over the pinned native cache lifecycle."""
from __future__ import annotations

import time
from dataclasses import dataclass

from vllm.v1.core.kv_cache_utils import make_block_hash_with_group_id, resolve_block_hashes


@dataclass(slots=True)
class _QueuedPrefix:
    signature: tuple
    keys: frozenset
    hashes: tuple


class FuturePrefixCache:
    def __init__(self, scheduler):
        self.scheduler = scheduler
        self.pool = scheduler.kv_cache_manager.block_pool
        self.watched = {}
        self.signatures = {}
        self.entries = {}
        self.dirty = set()
        self.ordered = ()
        self.queued_entries = {}
        self.queued_watched = {}
        self.queued_dirty = set()
        self._queued_parts = ()
        self._other_queued = frozenset()
        self._ready = frozenset()
        self.maintenance_cpu_seconds = 0.0
        self._insert = self.pool._insert_block_hash
        self._remove = self.pool._remove_cached_block_hashes
        self._reset = self.pool.reset_prefix_cache
        self.pool._insert_block_hash = self.insert
        self.pool._remove_cached_block_hashes = self.remove
        self.pool.reset_prefix_cache = self.reset

    def close(self):
        self.pool._insert_block_hash = self._insert
        self.pool._remove_cached_block_hashes = self._remove
        self.pool.reset_prefix_cache = self._reset

    def insert(self, block_hash_with_group_id, block, num_tokens):
        self._insert(block_hash_with_group_id, block, num_tokens)
        started = time.perf_counter()
        self._dirty_hash(block_hash_with_group_id)
        self.maintenance_cpu_seconds += time.perf_counter() - started

    def remove(self, block):
        removed = self._remove(block)
        started = time.perf_counter()
        for block_hash in removed:
            self._dirty_hash(block_hash)
        self.maintenance_cpu_seconds += time.perf_counter() - started
        return removed

    def reset(self):
        result = self._reset()
        if result:
            self.scheduler._model_intents.clear()
            self.dirty.update(self.entries)
            self.queued_dirty.update(self.queued_entries)
            if self.scheduler.value_admission is not None:
                self.scheduler.value_admission.reset()
        return result

    def _dirty_hash(self, block_hash):
        affected = self.watched.get(block_hash)
        if affected:
            self.dirty.update(affected)
        affected = self.queued_watched.get(block_hash)
        if affected:
            self.queued_dirty.update(affected)

    def changed_blocks(self, blocks):
        started = time.perf_counter()
        for block in blocks:
            self._dirty_hash(block.block_hash)
        if self.pool.cached_block_hashes_by_block:
            for block in blocks:
                for alias in self.pool.cached_block_hashes_by_block.get(block.block_id, ()):
                    self._dirty_hash(alias)
        self.maintenance_cpu_seconds += time.perf_counter() - started

    def _prefix_hashes(self, block_hashes, tokens):
        for group_id, group in enumerate(self.scheduler.kv_cache_manager.kv_cache_config.kv_cache_groups):
            size = group.kv_cache_spec.block_size
            hashes = resolve_block_hashes(block_hashes, self.pool.hash_block_size, size)
            for h in hashes[:tokens // size]:
                yield make_block_hash_with_group_id(h, group_id)

    def release_queued(self, request_id):
        entry = self.queued_entries.pop(request_id, None)
        if entry is not None:
            for h in entry.hashes:
                watchers = self.queued_watched[h]
                watchers.remove(request_id)
                if not watchers:
                    del self.queued_watched[h]
        self.queued_dirty.discard(request_id)

    def queued_prefix(self, request):
        identity = request.request_id
        # Native hashes are chained; the frontier also detects changed query content.
        signature = (request.num_tokens, len(request.block_hashes),
                     request.block_hashes[-1] if request.block_hashes else None)
        entry = self.queued_entries.get(identity)
        if entry is None or entry.signature != signature:
            self.release_queued(identity)
            hashes = tuple(self._prefix_hashes(request.block_hashes, request.num_tokens - 1))
            for h in hashes:
                self.queued_watched.setdefault(h, set()).add(identity)
            entry = _QueuedPrefix(signature, frozenset(), hashes)
            self.queued_entries[identity] = entry
            self.queued_dirty.add(identity)
        if identity in self.queued_dirty:
            groups, _, _ = self.scheduler.kv_cache_manager.coordinator.find_longest_cache_hit(
                request.block_hashes, request.num_tokens - 1,
            )
            entry.keys = frozenset(
                (b.block_id, b.block_hash) for group in groups for b in group
                if not b.is_null and b.block_hash is not None and b.ref_cnt == 0
                and b.prev_free_block is not None and b.next_free_block is not None
            )
            self.queued_dirty.remove(identity)
        return entry.keys

    def ready_snapshot(self, parts, other):
        parts = tuple(parts)
        if parts != self._queued_parts or other != self._other_queued:
            self._queued_parts = parts
            self._other_queued = frozenset(other)
            self._ready = frozenset().union(*parts, other)
        return self._ready

    def snapshot(self):
        s = self.scheduler
        manager = s.kv_cache_manager
        signatures = {}
        model_intents = s.controller.policy == "b6_model_intent"
        for cp, lease in s._checkpoints.items():
            if lease.handle_open:
                if model_intents:
                    intent = s._model_intents.get(cp)
                    if intent is not None and intent.expected_importance > 0:
                        signatures[cp] = (intent, lease.checkpoint.shared_tokens)
                    continue
                consumers = s.controller.definite_future(cp)
                required = max((
                    len(lease.checkpoint.logical_token_ids) if c.parent_prefix_tokens is None
                    else c.parent_prefix_tokens
                    for identity in consumers
                    for c in (s.controller.signals.consumers[identity],)
                ), default=0)
                signatures[cp] = (consumers, required)
        changed = signatures != self.signatures
        if changed:
            self.dirty.update(cp for cp, sig in signatures.items() if self.signatures.get(cp) != sig)
            self.entries = {cp: entry for cp, entry in self.entries.items() if cp in signatures}
            self.watched.clear()
            for cp, (_, required) in signatures.items():
                lease = s._checkpoints[cp]
                for key in self._prefix_hashes(lease.block_hashes, min(required, lease.checkpoint.shared_tokens)):
                    self.watched.setdefault(key, set()).add(cp)
            self.signatures = signatures
        changed = changed or bool(self.dirty)
        for cp in self.dirty & signatures.keys():
            lease = s._checkpoints[cp]
            consumers, required = signatures[cp]
            groups, tokens, _ = manager.coordinator.find_longest_cache_hit(
                lease.block_hashes, min(required, lease.checkpoint.shared_tokens),
            )
            ordered = tuple(
                (depth, cp, (b.block_id, b.block_hash))
                for group in groups for depth, b in enumerate(group)
                if not b.is_null and b.block_hash is not None and b.ref_cnt == 0
                and b.prev_free_block is not None and b.next_free_block is not None
            )
            details = {
                "kind": "b6_future", "checkpoint_id": cp, "consumer_ids": consumers,
                "required_parent_tokens": required, "cached_tokens": tokens,
                "retention_owner_blocks": 0,
            } if not model_intents else {
                "kind": "model_intent_future", "checkpoint_id": cp,
                "importance": consumers.importance, "reuse_likelihood": consumers.reuse_likelihood,
                "criticality": consumers.criticality,
                "expected_importance": consumers.expected_importance,
                "cached_tokens": tokens, "retention_owner_blocks": 0,
            }
            self.entries[cp] = (ordered, details)
        self.dirty.clear()
        if changed:
            if model_intents:
                ranked = sorted(signatures, key=lambda cp: (
                    not signatures[cp][0].criticality,
                    -signatures[cp][0].expected_importance, cp,
                ))
                items = (item for cp in ranked for item in self.entries[cp][0])
            else:
                items = sorted(item for entry, _ in self.entries.values() for item in entry)
            self.ordered = tuple(dict.fromkeys(key for _, _, key in items))
        for cp in signatures:
            s._preference_decisions.append({"at": s.clock(), **self.entries[cp][1]})
        return self.ordered
