"""FULL logical checkpoint reuse through an isolated asynchronous SGLang engine."""
from __future__ import annotations

import json
import os
import queue
import signal
import socket
import subprocess
import sys
import threading
import time
import uuid
from collections import deque
from dataclasses import asdict, dataclass
from pathlib import Path

from octopus.backend import (
    BackendCapabilities, Checkpoint, GenerationConfig, GenerationEvent,
    UnsupportedBackendFeature,
)
from octopus.context import InheritanceMode
from octopus.signals import CheckpointIntent, Event, Requirement, Signals
from octopus.sglang_worker import RELEASE, RELEASE_COMMIT


@dataclass(frozen=True, slots=True)
class SglangConfig:
    model_path: str
    tokenizer_path: str | None = None
    dtype: str = "bfloat16"
    max_model_len: int = 32768
    max_running_requests: int = 8
    max_total_tokens: int | None = None
    mem_fraction_static: float = 0.8
    chunked_prefill_size: int = 8192
    seed: int = 17
    disable_cuda_graph: bool = True
    enable_prefix_caching: bool = True
    incremental_streaming_output: bool = True
    dynamic_intent: bool = False
    python_executable: str = sys.executable
    startup_timeout: float = 300
    shutdown_timeout: float = 90

    def engine_options(self) -> dict:
        options = {
            "model_path": self.model_path, "tokenizer_path": self.tokenizer_path,
            "dtype": self.dtype, "context_length": self.max_model_len,
            "max_running_requests": self.max_running_requests,
            "max_total_tokens": self.max_total_tokens,
            "mem_fraction_static": self.mem_fraction_static,
            "chunked_prefill_size": self.chunked_prefill_size,
            "random_seed": self.seed, "disable_cuda_graph": self.disable_cuda_graph,
            "disable_radix_cache": not self.enable_prefix_caching,
            "incremental_streaming_output": self.incremental_streaming_output,
            "grammar_backend": "xgrammar",
            "constrained_json_disable_any_whitespace": True,
        }
        if self.dynamic_intent:
            options["radix_cache_backend"] = "octopus-intent"
        return options


def sampling_dict(config: GenerationConfig) -> dict:
    result = {
        "max_new_tokens": config.max_tokens, "temperature": config.temperature,
        "sampling_seed": config.seed, "ignore_eos": config.ignore_eos,
    }
    if config.schema_json is not None:
        result["json_schema"] = config.schema_json
    if config.grammar is not None:
        result["ebnf"] = config.grammar
    return result


@dataclass(slots=True)
class _Request:
    external_id: str
    prompt: tuple[int, ...]
    checkpoint_id: str | None
    capture_id: str | None
    capture_intent: CheckpointIntent | None
    aborting: bool = False


class SglangBackend:
    """Cooperative owner: submit many requests, then poll cumulative events.

    No native work/residency counters or dynamic cache-intent semantics are
    inferred from logical tokens. Released handles need not retain radix nodes.
    """

    def __init__(self, config: SglangConfig, *, _engine_factory: str | None = None):
        self.config = config
        self._engine_factory = _engine_factory
        self._intent_owner = uuid.uuid4().hex
        self._native_intent_enabled = False
        self._checkpoint_generations: dict[str, int] = {}
        self._capture_generation = 0
        self._requests: dict[str, _Request] = {}
        self._active: set[str] = set()
        self._checkpoints: dict[str, Checkpoint] = {}
        self._captures: dict[str, str] = {}
        self._signals = Signals()
        self._events: deque[GenerationEvent] = deque()
        self._incoming: queue.Queue = queue.Queue()
        self._closed = False
        self._failure: str | None = None
        self._owned_children: dict[int, str] = {}
        self._rpc_sequence = 0
        self._socket, child = socket.socketpair()
        command = [
            config.python_executable, "-m", "octopus.sglang_worker",
            "--fd", str(child.fileno()), "--control-timeout", str(config.shutdown_timeout),
        ]
        if _engine_factory is not None:
            command += ["--factory", _engine_factory]
        if config.dynamic_intent:
            command += ["--intent-owner", self._intent_owner]
        env = dict(os.environ)
        env["PYTHONPATH"] = os.pathsep.join(filter(None, (
            str(Path(__file__).resolve().parent.parent), env.get("PYTHONPATH"),
        )))
        if config.dynamic_intent:
            env["SGLANG_UNIFIED_RADIX_TREE_CORE_BACKEND"] = "python"
        try:
            self._process = subprocess.Popen(
                command, pass_fds=(child.fileno(),), env=env, start_new_session=True,
            )
        except Exception:
            self._socket.close()
            raise
        finally:
            child.close()
        self._reader = threading.Thread(target=self._read_messages, daemon=True)
        self._reader.start()
        try:
            self._send(config.engine_options())
            message = self._receive(config.startup_timeout)
            if message["type"] != "ready":
                raise RuntimeError(f"unexpected SGLang startup message: {message}")
            self._effective_engine_config = message["engine_options"]
            if config.dynamic_intent:
                receipt = message["intent_handshake"]
                if (receipt["protocol"] != 1 or receipt["source_commit"] != RELEASE_COMMIT
                        or receipt["scheduler_pid"] == self._process.pid):
                    raise RuntimeError("dynamic intent requires the actual pinned scheduler-process extension")
                self._native_intent_enabled = True
            self._owned_children = {
                pid: identity[2] for pid in message["child_pids"]
                if (identity := self._process_identity(pid)) is not None
            }
        except Exception:
            self._terminate()
            raise

    @property
    def capabilities(self) -> BackendCapabilities:
        return BackendCapabilities(
            prefix_reuse=self.config.enable_prefix_caching,
            selective_inheritance=False, dynamic_intent=self._native_intent_enabled,
            inline_intent=self._native_intent_enabled, native_work_counters=False,
        )

    def _read_messages(self):
        try:
            with self._socket.makefile("rb") as stream:
                while header := stream.read(4):
                    if len(header) != 4:
                        raise ValueError("truncated frame header")
                    size = int.from_bytes(header, "big")
                    data = stream.read(size)
                    if len(data) != size:
                        raise ValueError("truncated frame body")
                    self._incoming.put(json.loads(data))
        except (OSError, ValueError) as exc:
            self._incoming.put({"type": "fatal", "error": f"worker protocol: {exc}"})
        finally:
            self._incoming.put({"type": "fatal", "error": "SGLang worker disconnected"})

    def _send(self, message):
        if self._closed:
            raise RuntimeError("SGLang backend is closed")
        if self._failure is not None:
            raise RuntimeError(self._failure)
        data = json.dumps(message).encode()
        self._socket.sendall(len(data).to_bytes(4, "big") + data)

    def _receive(self, timeout):
        try:
            message = self._incoming.get(timeout=timeout)
        except queue.Empty as exc:
            raise TimeoutError("SGLang worker response timed out") from exc
        if message["type"] == "fatal":
            self._failure = message["error"]
            raise RuntimeError(self._failure)
        return message

    def _rpc(self, op, **kwargs):
        self._rpc_sequence += 1
        identity = self._rpc_sequence
        self._send({"op": op, "id": identity, **kwargs})
        deadline = time.monotonic() + self.config.shutdown_timeout
        while True:
            message = self._receive(max(0, deadline - time.monotonic()))
            if message["type"] == "event":
                self._accept_event(message)
                continue
            if message["type"] != "reply" or message["id"] != identity:
                raise RuntimeError(f"unexpected worker reply: {message}")
            if "error" in message:
                raise RuntimeError(message["error"])
            return message["value"]

    def validate_generation(self, config: GenerationConfig, *,
                            capture_intent: CheckpointIntent | None = None) -> None:
        if not isinstance(config, GenerationConfig):
            raise TypeError("SGLang requires neutral GenerationConfig, not native sampling parameters")
        if config.temperature != 0:
            raise UnsupportedBackendFeature("SGLang foundation supports greedy generation only")
        if config.schema_json is not None:
            json.loads(config.schema_json)
        if capture_intent is not None and any(
            c.parent_prefix_tokens is not None for c in capture_intent.consumers
        ):
            raise UnsupportedBackendFeature(
                "SGLang foundation does not support selective capture consumers; "
                "use an implicit FULL prefix"
            )

    def validate_inheritance(self, mode: InheritanceMode) -> None:
        if mode != InheritanceMode.FULL:
            raise UnsupportedBackendFeature("SGLang foundation does not support selective inheritance")

    def validate_checkpoint(self, checkpoint: Checkpoint) -> None:
        owned = self._checkpoints.get(checkpoint.checkpoint_id)
        if owned is None:
            raise ValueError(f"unknown or released checkpoint {checkpoint.checkpoint_id!r}")
        if owned is not checkpoint:
            raise ValueError("operation requires this backend's checkpoint handle")

    def add_request(
        self, *, request_id, prompt_token_ids, sampling_params,
        checkpoint_id=None, capture_checkpoint_id=None, consumer_id=None,
        capture_intent=None, selected_parent_tokens=None, capsule_tokens=0,
    ) -> str:
        self.validate_generation(sampling_params, capture_intent=capture_intent)
        if self._closed or self._failure is not None:
            raise RuntimeError(self._failure or "SGLang backend is closed")
        if any(r.external_id == request_id for r in self._requests.values()):
            raise ValueError(f"request {request_id!r} already exists")
        if not prompt_token_ids or len(prompt_token_ids) + sampling_params.max_tokens > self.config.max_model_len:
            raise ValueError("request requires a nonempty prompt within the configured context limit")
        if capture_intent is not None and capture_checkpoint_id is None:
            raise ValueError("capture intent requires an output checkpoint")
        if capture_checkpoint_id is not None and (
            capture_checkpoint_id in self._captures.values()
            or any(r.capture_id == capture_checkpoint_id for r in self._requests.values())
        ):
            raise ValueError("capture checkpoint already exists")
        if checkpoint_id is not None:
            parent = self.get_checkpoint(checkpoint_id)
            selected = len(parent.logical_token_ids)
            if capsule_tokens or selected_parent_tokens not in (None, selected):
                raise UnsupportedBackendFeature("SGLang foundation does not support selective inheritance")
            if tuple(prompt_token_ids[:selected]) != parent.logical_token_ids:
                raise ValueError("parent must be an exact token prefix")
        elif consumer_id is not None:
            raise ValueError("consumer binding requires a checkpoint")
        if capture_intent is not None:
            reserved = {
                c.consumer_id for rid in self._active
                if (intent := self._requests[rid].capture_intent) is not None
                for c in intent.consumers
            }
            ids = [c.consumer_id for c in capture_intent.consumers]
            if len(ids) != len(set(ids)) or set(ids) & (reserved | self._signals.consumers.keys()):
                raise ValueError("consumer already declared in capture intent")
        # Fixed-width UUIDs cannot prefix-match sibling native request IDs.
        rid = uuid.uuid4().hex
        if consumer_id is not None:
            consumer = self._signals.consumers[consumer_id]
            if consumer.parent_prefix_tokens not in (None, len(parent.logical_token_ids)):
                raise ValueError("submitted parent prefix differs from declared requirement")
        if checkpoint_id is not None:
            self._signals.bind(checkpoint_id, consumer_id, rid, request_id, self.clock())
        self._requests[rid] = _Request(
            request_id, tuple(prompt_token_ids), checkpoint_id,
            capture_checkpoint_id, capture_intent,
        )
        self._active.add(rid)
        try:
            self._send({"op": "submit", "rid": rid, "input_ids": prompt_token_ids,
                        "sampling": sampling_dict(sampling_params),
                        "checkpoint": (self._intent_checkpoint(checkpoint_id)
                                       if self._native_intent_enabled and checkpoint_id is not None else None)})
        except Exception:
            self._active.remove(rid)
            self._signals.finish_request(rid, self.clock(), "failed")
            raise
        return rid

    def _accept_event(self, message):
        rid = message["rid"]
        request = self._requests[rid]
        event = GenerationEvent(
            request.external_id, rid, request.prompt, tuple(message["token_ids"]),
            message["text"], message["finished"],
            "abort" if request.aborting and message["finished"] else message["finish_reason"],
            None if request.aborting else message["error"], message["cached_tokens"],
        )
        if event.finished:
            self._active.discard(rid)
            failed = event.error is not None or event.finish_reason == "abort"
            self._signals.finish_request(rid, self.clock(), "failed" if failed else "complete")
            if request.capture_id is not None and not failed:
                logical = (*request.prompt, *event.token_ids)
                if request.capture_intent is not None:
                    self._signals.register_intent(request.capture_id, request.capture_intent, self.clock())
                checkpoint = Checkpoint(request.capture_id, logical, None, None, None, None)
                self._checkpoints[request.capture_id] = checkpoint
                self._capture_generation += 1
                self._checkpoint_generations[request.capture_id] = self._capture_generation
                self._captures[rid] = request.capture_id
                self.observe(Event("capture", request.capture_id, self.clock(),
                                   parent_id=request.checkpoint_id))
        self._events.append(event)

    def normalize_events(self, outputs) -> list[GenerationEvent]:
        events = list(outputs)
        if any(not isinstance(event, GenerationEvent) for event in events):
            raise TypeError("SGLang requires normalized GenerationEvent outputs")
        return events

    def poll(self) -> list[GenerationEvent]:
        if self._failure is not None:
            raise RuntimeError(self._failure)
        if not self._events and self._active:
            try:
                message = self._receive(0.1)
            except TimeoutError:
                return []
            self._accept_event(message)
        while not self._incoming.empty():
            message = self._receive(0)
            self._accept_event(message)
        result = list(self._events)
        self._events.clear()
        return result

    def step(self) -> list[GenerationEvent]:
        return self.poll()

    def has_unfinished_requests(self) -> bool:
        return bool(self._active or self._events)

    def is_request_active(self, request_id: str) -> bool:
        return request_id in self._active

    def external_request_id(self, internal_request_id: str) -> str:
        return self._requests[internal_request_id].external_id

    def abort(self, request_id: str) -> None:
        if request_id not in self._active:
            return
        self._requests[request_id].aborting = True
        self._rpc("abort", rid=request_id)

    def tokenize(self, text: str) -> list[int]:
        return self._rpc("tokenize", text=text)

    def decode(self, token_ids) -> str:
        return self._rpc("decode", token_ids=list(token_ids))

    def render_chat(self, messages, *, tools=None, add_generation_prompt=False) -> str:
        return self._rpc("render_chat", messages=messages, tools=tools,
                         add_generation_prompt=add_generation_prompt)

    def reset_prefix_cache(self) -> bool:
        if self._active:
            raise RuntimeError("cache reset requires no in-flight requests")
        return self._rpc("flush_cache")

    def get_checkpoint_for_request(self, request_id: str) -> Checkpoint:
        return self.get_checkpoint(self._captures[request_id])

    def get_checkpoint(self, checkpoint_id: str) -> Checkpoint:
        return self._checkpoints[checkpoint_id]

    def checkpoint_is_open(self, checkpoint_id: str) -> bool:
        return checkpoint_id in self._checkpoints

    def release_checkpoint(self, checkpoint: Checkpoint) -> None:
        self.validate_checkpoint(checkpoint)
        if self._native_intent_enabled:
            self._rpc("intent", payload={
                "op": "release", "checkpoint": self._intent_checkpoint(checkpoint.checkpoint_id),
            })
        del self._checkpoints[checkpoint.checkpoint_id]
        self._checkpoint_generations.pop(checkpoint.checkpoint_id, None)
        self.observe(Event("release", checkpoint.checkpoint_id, self.clock()))

    def observe(self, event: Event) -> None:
        self._signals.observe(event)

    def declare_gpu_consumer(self, checkpoint_id, consumer_id, after, *,
                             requirement=Requirement.DEFINITE, condition_id=None,
                             condition_outcome=True, parent_prefix_tokens=None):
        checkpoint = self.get_checkpoint(checkpoint_id)
        if parent_prefix_tokens not in (None, len(checkpoint.logical_token_ids)):
            raise UnsupportedBackendFeature("SGLang foundation does not support selective consumers")
        self._signals.declare(
            checkpoint_id, consumer_id, after, self.clock(), requirement=requirement,
            condition_id=condition_id, condition_outcome=condition_outcome,
            parent_prefix_tokens=parent_prefix_tokens,
        )

    def declare_no_gpu_consumers(self, checkpoint_id):
        self.get_checkpoint(checkpoint_id)
        self._signals.declare_no_consumers(checkpoint_id, self.clock())

    def decide_condition(self, condition_id, outcome):
        self._signals.decide_condition(condition_id, outcome, self.clock())

    def cancel_gpu_consumer(self, consumer_id):
        if self._native_intent_enabled:
            consumer = self._signals.consumers[consumer_id]
            if consumer.terminal:
                return
            if consumer.bound_request_id is not None:
                raise ValueError("cancel an accepted request through its native request lifecycle")
            self._rpc("intent", payload={
                "op": "cancel", "checkpoint": self._intent_checkpoint(consumer.checkpoint_id),
            })
        self._signals.cancel(consumer_id, self.clock())

    def consumer_is_terminal(self, consumer_id):
        return self._signals.consumers[consumer_id].terminal

    def _intent_checkpoint(self, checkpoint_id):
        checkpoint = self.get_checkpoint(checkpoint_id)
        return {"checkpoint_id": checkpoint_id,
                "generation": self._checkpoint_generations[checkpoint_id],
                "token_ids": list(checkpoint.logical_token_ids)}

    def apply_model_intents(self, intents, *, producer_request_id=None):
        if not self._native_intent_enabled:
            raise UnsupportedBackendFeature("SGLang requires its explicitly enabled native dynamic intent extension")
        states = [{**self._intent_checkpoint(cp), "intent": asdict(intent)}
                  for cp, intent in intents.items()]
        return self._rpc("intent", payload={
            "op": "update", "states": states, "producer_request_id": producer_request_id,
        })

    def intent_state(self, *, since=0):
        if not self._native_intent_enabled:
            raise UnsupportedBackendFeature("native dynamic intent is not enabled")
        return self._rpc("intent", payload={"op": "snapshot", "since": since})

    @staticmethod
    def clock() -> float:
        return time.perf_counter()

    def environment_metadata(self) -> dict:
        return {
            "backend": "sglang",
            "sglang_version": RELEASE if self._engine_factory is None else None,
            "fixture_engine": self._engine_factory,
            "native_intent_enabled": self._native_intent_enabled,
            "upstream_commit": RELEASE_COMMIT, "worker_pid": self._process.pid,
            "worker_python": self.config.python_executable,
            "requested_engine_config": self.config.engine_options(),
            "effective_engine_config": self._effective_engine_config,
            "capabilities": asdict(self.capabilities),
            "native_work_counters": None, "physical_cache_frontier": None,
            "kv_residency": None,
        }

    @staticmethod
    def _process_identity(pid):
        try:
            fields = Path(f"/proc/{pid}/stat").read_text().rsplit(") ", 1)[1].split()
        except FileNotFoundError:
            return None
        return fields[0], int(fields[2]), fields[19]

    def _terminate(self):
        owned = dict(self._owned_children)
        for path in Path("/proc").iterdir():
            if path.name.isdecimal():
                identity = self._process_identity(int(path.name))
                if identity is not None and identity[1] == self._process.pid:
                    owned[int(path.name)] = identity[2]
        # This exact process group was created by this adapter, never a tool's.
        try:
            os.killpg(self._process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        for pid, start in owned.items():
            identity = self._process_identity(pid)
            if identity is not None and identity[2] == start and identity[0] != "Z":
                try:
                    os.kill(pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
        self._process.wait(timeout=5)
        self._socket.close()
        self._reader.join(timeout=5)
        deadline = time.monotonic() + 5
        while any((identity := self._process_identity(pid)) is not None
                  and identity[2] == start and identity[0] != "Z"
                  for pid, start in owned.items()):
            if time.monotonic() >= deadline:
                raise TimeoutError("SGLang owned processes did not terminate")
            time.sleep(0.01)
        self._active.clear()
        self._events.clear()
        self._checkpoints.clear()
        self._closed = True

    def close(self):
        if self._closed:
            return
        try:
            self._send({"op": "close"})
            self._process.wait(timeout=self.config.shutdown_timeout)
            if self._process.returncode != 0:
                raise RuntimeError(f"SGLang worker exited with status {self._process.returncode}")
        except Exception:
            self._terminate()
            raise
        self._socket.close()
        self._reader.join(timeout=5)
        self._active.clear()
        self._events.clear()
        self._checkpoints.clear()
        self._closed = True
