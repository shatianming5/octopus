"""Completed-history readiness ordering; no workload tape or trained model.

Reuses Signals' sourced EWMA stage history and completed prep/queue means.
Unknown/overdue keys keep their exact B6 positions, not an invented ETA zero.
"""
from dataclasses import asdict

PROVENANCE = "signals-completed-within-trace-stage-ewma-preparation-queue-means-v1"


def forecast(signals, consumer, now, waiting):
    dependencies = {
        node: asdict(signals.dependencies[node])
        for node in consumer.prerequisite_ids if node in signals.dependencies
    }
    if any(d["source"] not in {"unknown", "completed_history"} for d in dependencies.values()):
        raise ValueError("B7 rejects caller hints and external dependency priors")
    estimate = signals.estimate(consumer, now, waiting)
    # Missing observations remain neutral even if a different legacy caller
    # supplied priors to Signals. B7's Controller never supplies calibration.
    cold = not signals.preparation_history or not signals.queue_history
    status = "cold_start" if estimate.status == "unknown" and cold else estimate.status
    return {
        "consumer_id": consumer.consumer_id, "checkpoint_id": consumer.checkpoint_id,
        "at": now, **asdict(estimate), "source": PROVENANCE,
        "status": status, "dependencies": dependencies,
        "completed_dependencies": {
            node: signals.completed_dependencies[node]
            for node in consumer.prerequisite_ids if node in signals.completed_dependencies
        },
        "preparation_sample_count": len(signals.preparation_history),
        "queue_sample_count": len(signals.queue_history),
        "completed_sample_consumers": [
            c.consumer_id for c in signals.consumers.values()
            if c.state == "complete" and c.adopted_at is not None and c.enqueued_at is not None
        ],
        "visible_waiting_requests": waiting, "provenance": PROVENANCE,
    }


def order_keys(baseline, horizons, cap):
    known = [key for key in baseline if key in horizons]
    ordered = iter(sorted(known, key=lambda key: horizons[key]))
    result = tuple(next(ordered) if key in horizons else key for key in baseline)
    encode = lambda keys: [(i, h.hex() if isinstance(h, bytes) else str(h)) for i, h in keys]
    changed = set(result[:cap]) != set(baseline[:cap])
    return result, {
        "b6_future_order": encode(baseline),
        "b7_evidence": {
            "forecast_provenance": PROVENANCE,
            "causal_ranking_changed": changed,
            "decision_bearing": False, "adopted_tokens": 0,
        },
        "newly_preferred": encode(key for key in result[:cap] if key not in baseline[:cap]),
    }
