"""Causal prefix allocation at actual native pressure, in analytic proxy units."""
from __future__ import annotations

from dataclasses import dataclass

from octopus.retention_audit import encode


FORMULA = "W_D(t)=D*t+t*(t+1)/2; remaining-definite-use-weighted marginal proxy work per additional physical copy"


@dataclass
class ValueNode:
    key: tuple
    parent: int | None
    depth: int
    consumers: set
    eligible: bool
    mandatory: bool
    other_held_copies: tuple
    other_free_copies: tuple
    work_per_use: int


def allocate_prefixes(nodes, capacity, covered=frozenset(), weights=None, allowed=None):
    """Greedy best-density ancestor bundles; mandatory native coverage costs zero."""
    anchors, parents, rewards = {}, {}, {}
    blocked = set()
    for i, node in enumerate(nodes):
        if (node.parent in blocked
                or (allowed is not None and not node.mandatory
                    and node.key not in covered and node.key not in allowed)):
            blocked.add(i)
            continue
        value = node.work_per_use * len(node.consumers) if weights is None else weights[i]
        parent = anchors.get(node.parent)
        if node.mandatory or node.key in covered:
            anchors[i] = parent
            if parent is not None:
                rewards[parent] += value
        else:
            anchors[i] = i
            parents[i] = parent
            rewards[i] = value
    kept, packages = set(), []
    while len(kept) < capacity:
        costs, gains = {}, {}
        best = None
        for i, parent in parents.items():
            costs[i] = 0 if i in kept else 1 + costs.get(parent, 0)
            gains[i] = 0 if i in kept else rewards[i] + gains.get(parent, 0)
            if not 0 < costs[i] <= capacity - len(kept):
                continue
            rank = (gains[i] / costs[i], gains[i], -i)
            if best is None or rank > best[0]:
                best = (rank, i)
        if best is None:
            break
        _, tip = best
        packages.append((tip, gains[tip], costs[tip]))
        while tip is not None and tip not in kept:
            kept.add(tip)
            tip = parents[tip]
    return kept, rewards, packages


def project_native_preferences(nodes, preferred, native_capacity, weights=None):
    """Reclaim only physically impossible soft preference, preserving ancestry."""
    if len(preferred) <= native_capacity:
        return preferred, ()
    selected, _, packages = allocate_prefixes(
        nodes, native_capacity, weights=weights, allowed=preferred,
    )
    return frozenset(nodes[i].key for i in selected), tuple(packages)


@dataclass
class ValueDecision:
    at: float
    hidden_size: int
    free: int
    draw: int
    queued: int
    capacity: int
    eligible: int
    kept: frozenset
    nodes: tuple = ()
    rewards: dict | None = None
    packages: tuple = ()
    prefill_commitment: dict | None = None
    granted: frozenset = frozenset()
    new_admissions: frozenset = frozenset()
    logical_grants: tuple = ()
    ranking_evaluated: bool = False
    reset_epoch: int = 0
    new_logical_grants: tuple = ()
    pre_native_projection: frozenset | None = None
    hard_projection_packages: tuple = ()

    def decode(self):
        before = self.kept if self.pre_native_projection is None else self.pre_native_projection
        hard_demoted = before - self.kept
        return {
            "schema": "octopus-physical-pressure-value-v1",
            "at": self.at, "formula": FORMULA,
            "units": "analytic normalized prefill-work proxy; not measured FLOPs or seconds",
            "hidden_size": self.hidden_size, "free_before": self.free,
            "native_draw": self.draw, "queued_free_blocks": self.queued,
            "physical_future_capacity": self.capacity, "eligible_future_copies": self.eligible,
            "forecast_admission_capacity": self.capacity,
            "forecast_cap_is_total_protection_limit": False,
            "hard_native_projection": bool(hard_demoted),
            "pre_native_projection_copies": len(before),
            "hard_native_demoted_keys": encode(sorted(hard_demoted)),
            "valid_grant_forecast_excess_blocks": max(0, len(self.granted) - self.capacity),
            "binding": self.eligible > self.capacity,
            "native_draw_capacity": max(0, self.free - self.draw - self.queued),
            "prefill_commitment": self.prefill_commitment,
            "soft_grant_copies": len(self.granted),
            "reused_grant_copies": len(self.granted - self.new_admissions),
            "new_admission_copies": len(self.new_admissions),
            "new_admission_keys": encode(sorted(self.new_admissions)),
            "forecast_excess_blocks": max(0, len(self.kept) - self.capacity),
            "ranking_evaluated": self.ranking_evaluated,
            "grant_reset_epoch": self.reset_epoch,
            "logical_grants": [
                {"checkpoint_id": cp, "consumer_id": cid, "prefix_blocks": blocks}
                for (cp, cid), blocks in self.logical_grants
            ],
            "new_logical_grants": [
                {"checkpoint_id": cp, "consumer_id": cid, "prefix_blocks": blocks}
                for (cp, cid), blocks in self.new_logical_grants
            ],
            "kept_future_copies": len(self.kept), "dropped_future_copies": self.eligible - len(self.kept),
            "nonbinding_action": "KEEP_ALL_FIXED" if self.eligible <= self.capacity else None,
            "nodes": [{
                "key": encode((node.key,))[0], "parent": node.parent,
                "depth": node.depth, "consumer_ids": sorted(node.consumers),
                "remaining_definite_uses": len(node.consumers),
                "eligible_future_copy": node.eligible,
                "work_per_use": node.work_per_use,
                "marginal_bundle_reward": self.rewards.get(i),
                "native_or_queued_cover": node.mandatory,
                "other_held_copy_ids": node.other_held_copies,
                "other_free_copy_ids": node.other_free_copies,
                "decision": "KEEP" if node.key in self.kept else "DROP" if node.eligible else "NATIVE_COVER",
                "reused_grant": node.key in self.granted and node.key not in self.new_admissions,
                "new_admission": node.key in self.new_admissions,
                "drop_reason": ("current_native_shortfall" if node.key in hard_demoted
                                else "forecast_admission" if node.eligible and node.key not in self.kept else None),
            } for i, node in enumerate(self.nodes)],
            "selected_packages": [
                {"tip": tip, "marginal_proxy_work": gain, "additional_physical_copies": count,
                 "proxy_work_per_copy": gain / count}
                for tip, gain, count in self.packages
            ],
            "hard_projection_packages": [
                {"tip": tip, "marginal_proxy_work": gain, "physical_copies": count}
                for tip, gain, count in self.hard_projection_packages
            ],
        }


class NativeValueAdmission:
    def __init__(self, scheduler, hidden_size):
        if not isinstance(hidden_size, int) or hidden_size <= 0:
            raise ValueError("value admission requires the actual model's positive hidden_size")
        self.scheduler = scheduler
        self.hidden_size = hidden_size
        self.rejected = frozenset()
        self._grants = {}
        self._grant_version = 0
        self._grant_snapshot = ()
        self._grant_input = None
        self._grant_input_version = -1
        self._grant_keys = frozenset()
        self._nodes_input = None
        self._nodes_cache = ()
        self._last_binding_input = None
        self.reset_epoch = 0

    def reset(self):
        self._grants.clear()
        self._grant_version += 1
        self._grant_snapshot = ()
        self._grant_input = self._nodes_input = None
        self._last_binding_input = None
        self._grant_keys = self.rejected = frozenset()
        self.reset_epoch += 1

    def _live_granted_keys(self, future, eligible):
        cache = self.scheduler._future_prefix_cache
        live = {(cp, cid) for cp, (consumers, _) in cache.signatures.items() for cid in consumers}
        expired = self._grants.keys() - live
        if expired:
            for key in expired:
                del self._grants[key]
            self._grant_version += 1
            self._grant_snapshot = tuple(sorted(self._grants.items()))
        if not self._grants:
            return frozenset()
        if future is self._grant_input and self._grant_input_version == self._grant_version:
            return self._grant_keys
        limits = {}
        for (cp, _), blocks in self._grants.items():
            limits[cp] = max(limits.get(cp, 0), blocks)
        mapping = self.scheduler.kv_cache_manager.block_pool.cached_block_hash_to_block
        keys = set()
        for cp, limit in limits.items():
            for depth, _, key in cache.entries[cp][0]:
                if depth >= limit or key not in eligible:
                    continue
                copies = mapping._cache[key[1]]
                if isinstance(copies, dict) and any(b.ref_cnt > 0 for b in copies.values()):
                    continue
                keys.add(key)
        self._grant_input = future
        self._grant_input_version = self._grant_version
        self._grant_keys = frozenset(keys)
        return self._grant_keys

    def _admit(self, nodes, selected):
        if not selected:
            return ()
        changed = {}
        for node in nodes:
            if node.key not in selected:
                continue
            for cid in node.consumers:
                cp = self.scheduler.controller.signals.consumers[cid].checkpoint_id
                key = (cp, cid)
                if node.depth + 1 > self._grants.get(key, 0):
                    self._grants[key] = node.depth + 1
                    changed[key] = node.depth + 1
        if changed:
            self._grant_version += 1
            self._grant_snapshot = tuple(sorted(self._grants.items()))
        return tuple(sorted(changed.items()))

    def select(self, future, eligible, queued, free, draw, capacity):
        s = self.scheduler
        commitment = s._running_prefill_commitment(draw)
        capacity = max(0, capacity - commitment["additional_blocks"])
        granted = self._live_granted_keys(future, eligible)
        if len(future) <= capacity:
            self.rejected = frozenset()
            return eligible, ValueDecision(
                s.clock(), self.hidden_size, free, draw, len(queued), capacity, len(future), eligible,
                prefill_commitment=commitment, granted=granted,
                logical_grants=self._grant_snapshot, reset_epoch=self.reset_epoch,
            )
        nodes = self._binding_nodes(future, eligible)
        room = max(0, capacity - len(granted))
        evaluate = len(eligible) > len(granted) and room > 0
        selected, rewards, packages = allocate_prefixes(nodes, room, granted) if evaluate else (set(), {}, [])
        new = frozenset(nodes[i].key for i in selected)
        kept = granted | new if new else granted
        if not new <= eligible:
            raise AssertionError("value selection expanded the fixed candidate universe")
        logical_new = self._admit(nodes, kept) if new or future is not self._last_binding_input else ()
        self._last_binding_input = future
        before = kept
        kept, hard_packages = project_native_preferences(
            nodes, before, max(0, free - draw - len(queued)),
        )
        self.rejected = eligible - kept if len(kept) < len(eligible) else frozenset()
        return kept, ValueDecision(
            s.clock(), self.hidden_size, free, draw, len(queued), capacity, len(future), kept,
            nodes, rewards, tuple(packages), commitment, before, new,
            self._grant_snapshot, evaluate, self.reset_epoch,
            logical_new, before, hard_packages,
        )

    def _binding_nodes(self, future, eligible):
        if future is self._nodes_input:
            return self._nodes_cache
        from vllm.v1.core.kv_cache_utils import make_block_hash_with_group_id
        from vllm.v1.kv_cache_interface import FullAttentionSpec

        s = self.scheduler
        manager = s.kv_cache_manager
        groups = manager.kv_cache_config.kv_cache_groups
        if len(groups) != 1 or not isinstance(groups[0].kv_cache_spec, FullAttentionSpec):
            raise ValueError("value admission requires the pinned dense single-group producer")
        size = groups[0].kv_cache_spec.block_size
        mapping = manager.block_pool.cached_block_hash_to_block
        nodes, indices = [], {}
        for cp, (consumers, required) in s._future_prefix_cache.signatures.items():
            lease = s._checkpoints[cp]
            demands = {
                identity: (s.controller.signals.consumers[identity].parent_prefix_tokens
                           if s.controller.signals.consumers[identity].parent_prefix_tokens is not None
                           else len(lease.checkpoint.logical_token_ids))
                for identity in consumers
            }
            parent = None
            for depth, h in enumerate(lease.block_hashes[:min(required, lease.checkpoint.shared_tokens) // size]):
                grouped = make_block_hash_with_group_id(h, 0)
                block = mapping.get_one_block(grouped)
                if block is None:
                    break
                key = (block.block_id, block.block_hash)
                end, start = (depth + 1) * size, depth * size
                users = {identity for identity, tokens in demands.items() if tokens >= end}
                if key in indices:
                    index = indices[key]
                    nodes[index].consumers.update(users)
                else:
                    entry = mapping._cache[grouped]
                    copies = list(entry.values()) if isinstance(entry, dict) else [entry]
                    others = [b for b in copies if b.block_id != block.block_id]
                    held = tuple(b.block_id for b in others if b.ref_cnt > 0)
                    free_copies = tuple(b.block_id for b in others if b.ref_cnt == 0
                                        and b.prev_free_block is not None and b.next_free_block is not None)
                    index = len(nodes)
                    indices[key] = index
                    nodes.append(ValueNode(
                        key, parent, depth, users, key in eligible, key not in eligible or bool(held), held, free_copies,
                        self.hidden_size * size + (end * (end + 1) - start * (start + 1)) // 2,
                    ))
                parent = index
        self._nodes_input = future
        self._nodes_cache = tuple(nodes)
        return self._nodes_cache
