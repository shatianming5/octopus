"""Application-owned independent cohorts, not a native/global scheduler."""
from __future__ import annotations

from dataclasses import dataclass, replace
from typing import TYPE_CHECKING, Callable, Iterable

from octopus.context import ContextBudgetError, Inheritance

if TYPE_CHECKING:
    from octopus.runtime import Branch, BranchTask, Octopus
    from octopus.backend import Checkpoint


@dataclass(frozen=True, slots=True)
class BranchBudget:
    max_inflight: int
    max_started: int
    max_output_tokens: int

    def __post_init__(self):
        if self.max_inflight < 1 or self.max_started < 0 or self.max_output_tokens < 0:
            raise ValueError("max_inflight must be positive; started/output budgets nonnegative")


@dataclass(frozen=True, slots=True)
class BranchCandidate:
    task: BranchTask
    required: bool = True
    inheritance_options: tuple[Inheritance, ...] = ()


@dataclass(frozen=True, slots=True)
class CompletionEvent:
    verified_branch_ids: tuple[str, ...]
    cancel_candidate_ids: tuple[str, ...]
    reason: str


@dataclass(frozen=True, slots=True)
class PolicyResult:
    status: str
    started: tuple[Branch, ...]
    skipped: dict[str, str]
    verified: tuple[str, ...]
    output_tokens: int
    incomplete_required: tuple[str, ...]


class BranchPolicy:
    def __init__(
        self, runtime: Octopus, checkpoint: Checkpoint,
        candidates: Iterable[BranchCandidate], budget: BranchBudget,
    ):
        self.runtime, self.checkpoint, self.budget = runtime, checkpoint, budget
        runtime._require_no_pending_branches()
        self.candidates = tuple(candidates)
        tasks = []
        # Freeze every projection before accepting any native request.
        for candidate in self.candidates:
            task = candidate.task
            if candidate.inheritance_options:
                errors = []
                for choice in candidate.inheritance_options:
                    try:
                        runtime.prepare_fork(checkpoint, [replace(task, inheritance=choice)])
                    except ContextBudgetError as exc:
                        errors.append(str(exc))
                    else:
                        task = replace(task, inheritance=choice)
                        break
                else:
                    raise ContextBudgetError("; ".join(errors))
            tasks.append(task)
        self.prepared = runtime.prepare_fork(checkpoint, tasks)
        self.required = {p.branch_id for p, c in zip(self.prepared, self.candidates, strict=True) if c.required}
        self.pending = list(self.prepared)
        self.started: list[Branch] = []
        self.skipped: dict[str, str] = {}
        self.verified: set[str] = set()
        self.events: list[CompletionEvent] = []

    @property
    def active(self) -> list[Branch]:
        return [b for b in self.started if b.status in {"QUEUED", "RUNNING"}]

    @property
    def done(self) -> bool:
        return not self.pending and not self.active

    def _skip(self, item, reason: str) -> None:
        self.skipped[item.branch_id] = reason
        consumer_id = item.task.consumer_id
        if consumer_id is not None:
            if not self.runtime.backend.consumer_is_terminal(consumer_id):
                self.runtime.cancel_gpu_consumer(consumer_id)
        self.pending.remove(item)

    def observe(self, event: CompletionEvent) -> None:
        if event in self.events:
            return
        if not event.reason.strip():
            raise ValueError("completion event requires an external verification reason")
        started = {b.branch_id: b for b in self.started}
        known = {p.branch_id for p in self.prepared}
        if set(event.cancel_candidate_ids) - known:
            raise ValueError("unknown cancellation candidate")
        if set(event.cancel_candidate_ids) & self.required:
            raise ValueError("cannot early-cancel a required branch")
        for branch_id in event.verified_branch_ids:
            if branch_id not in started or started[branch_id].status not in {"COMMIT_READY", "COMMITTED"}:
                raise ValueError("external verification requires a completed branch")
        self.events.append(event)
        self.verified.update(event.verified_branch_ids)
        for item in list(self.pending):
            if item.branch_id in event.cancel_candidate_ids:
                self._skip(item, "externally_cancelled")
        for branch in self.active:
            if branch.branch_id in event.cancel_candidate_ids:
                self.runtime.abort(branch)

    def advance(self) -> None:
        backend = self.runtime.backend
        # The logical handle can close while native accepted requests own pages.
        if not backend.checkpoint_is_open(self.checkpoint.checkpoint_id):
            for item in list(self.pending):
                self._skip(item, "parent_released")
        for item in list(self.pending):
            consumer_id = item.task.consumer_id
            if consumer_id is not None and backend.consumer_is_terminal(consumer_id):
                self._skip(item, "consumer_cancelled")
        while self.pending and len(self.active) < self.budget.max_inflight:
            item = self.pending[0]
            spent = sum(len(b.output_token_ids) for b in self.started if b not in self.active)
            reserved = sum(
                p.task.max_new_tokens for p in self.prepared
                if any(b.branch_id == p.branch_id for b in self.active)
            )
            if (len(self.started) >= self.budget.max_started
                    or spent + reserved + item.task.max_new_tokens > self.budget.max_output_tokens):
                if self.active:
                    break
                for remaining in list(self.pending):
                    self._skip(remaining, "budget_exhausted")
                break
            branch = self.runtime.fork_prepared(self.checkpoint, [item])[0]
            self.pending.remove(item)
            self.started.append(branch)
        if self.active:
            self.runtime.step()
            if self.active and not self.runtime.backend.has_unfinished_requests():
                raise RuntimeError("native requests ended without terminal branch outputs")

    def run(
        self, verifier: Callable[[tuple[Branch, ...]], CompletionEvent | None] | None = None,
    ) -> PolicyResult:
        while not self.done:
            self.advance()
            if verifier is not None:
                event = verifier(tuple(self.started))
                if event is not None:
                    self.observe(event)
        incomplete = self.required - {
            b.branch_id for b in self.started if b.status in {"COMMIT_READY", "COMMITTED"}
        }
        reasons = set(self.skipped.values())
        status = (
            "parent_released" if "parent_released" in reasons else
            "budget_exhausted" if "budget_exhausted" in reasons else
            "incomplete" if incomplete or any(b.status == "FAILED" for b in self.started) else "complete"
        )
        return PolicyResult(
            status, tuple(self.started), dict(self.skipped), tuple(sorted(self.verified)),
            sum(len(b.output_token_ids) for b in self.started), tuple(sorted(incomplete)),
        )
