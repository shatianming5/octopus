"""Opt-in single-GPU backend conformance, not performance or quality evidence."""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
from dataclasses import asdict, replace
from pathlib import Path

from octopus import BranchTask, CaseSession, GenerationConfig, Octopus
from octopus.backend import BackendConfig
from octopus.state import Commit, Evidence, Fact


ANSWER_SCHEMA = {
    "type": "object", "required": ["answer"], "additionalProperties": False,
    "properties": {"answer": {"type": "string", "enum": ["ALPHA", "BRAVO"]}},
}


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def require_cache_hit(event):
    require(event.cached_tokens is not None, "native cached-token telemetry is unavailable")
    require(event.cached_tokens > 0, "no actual prefix reuse observed")


def exercise(backend, *, prefix_tokens: int, timeout_seconds: float, report: dict):
    """Run through the same shared-session seam used by real consumers."""
    session = CaseSession(backend, "conformance")
    events = report["events"] = []
    terminals = {}
    deadline = time.monotonic() + timeout_seconds

    def pump():
        require(time.monotonic() < deadline, "conformance request deadline exceeded")
        batch = backend.poll()
        for event in batch:
            events.append(asdict(event))
            if event.finished:
                require(event.error is None, f"generation failed: {event.error}")
                terminals[event.internal_request_id] = event
        session.accept_outputs(batch)

    def brain():
        result = session.take_brain()
        while result is None:
            pump()
            result = session.take_brain()
        return result

    def branches():
        while session.has_pending_branches():
            pump()

    def task(checkpoint, name, answer, *, capture=True):
        suffix = backend.tokenize(
            f"\n\nNew independent task. The marker for this branch is {answer}. "
            'Return JSON {"answer":"<the marker for THIS branch>"} only.\n'
        )
        prepared = session.prepare_fork(checkpoint, [
            BranchTask(tuple(suffix), 64, branch_id=name, capture_checkpoint=capture),
        ])[0]
        return replace(prepared, sampling_params=GenerationConfig(
            64, seed=backend.config.seed, schema_json=json.dumps(ANSWER_SCHEMA),
        ))

    try:
        text = backend.render_chat([{
            "role": "user",
            "content": "This is shared context, not a branch marker. " * (prefix_tokens + 1),
        }], add_generation_prompt=True)
        prompt = backend.tokenize(text)[:prefix_tokens]
        require(len(prompt) == prefix_tokens, "insufficient root prompt tokens")
        session.start_brain(prompt, max_new_tokens=8, ignore_eos=True)
        root = brain()
        require(root.checkpoint.logical_token_ids == (*prompt, *root.output_token_ids),
                "root checkpoint lost generated tail")
        require(len(root.output_token_ids) == 8, "ignore_eos/output limit was not preserved")
        report["root"] = asdict(root.checkpoint)

        prepared = [task(root.checkpoint, "branch-a", "ALPHA"),
                    task(root.checkpoint, "branch-b", "BRAVO")]
        a, b = session.fork_prepared(root.checkpoint, prepared)
        require(backend.is_request_active(a.request_id) and backend.is_request_active(b.request_id),
                "two requests were not concurrently in flight")
        session.release(root.checkpoint)
        try:
            session.prepare_fork(root.checkpoint, [BranchTask((1,), 1)])
        except (ValueError, KeyError):
            pass
        else:
            raise RuntimeError("released parent allowed a new fork")
        branches()
        for branch, item, answer in zip((a, b), prepared, ("ALPHA", "BRAVO"), strict=True):
            require(branch.status == "COMMIT_READY", f"branch did not complete: {branch.error}")
            event = terminals[branch.request_id]
            require_cache_hit(event)
            require(event.prompt_token_ids == item.context.prompt_token_ids, "input IDs changed")
            require(event.prompt_token_ids[:len(root.checkpoint.logical_token_ids)]
                    == root.checkpoint.logical_token_ids, "fork omitted generated tail")
            require(branch.output_checkpoint.logical_token_ids == (*event.prompt_token_ids, *event.token_ids),
                    "captured child is not the complete logical sequence")
            require(json.loads(event.text) == {"answer": answer}, "sibling suffix contaminated output")
        report["released_parent_with_live_children"] = True
        report["root_tail_cache_observations"] = {
            "logical_parent_tokens": len(root.checkpoint.logical_token_ids),
            "branch_cached_tokens": [terminals[x.request_id].cached_tokens for x in (a, b)],
            "meaning": "observed cache hits, not a computed frontier or total-work estimate",
        }

        # Native full flush is controlled eviction, not simulated pressure.
        require(backend.reset_prefix_cache() is True, "native idle cache flush failed")
        item = task(a.output_checkpoint, "recompute", "ALPHA")
        cold = session.fork_prepared(a.output_checkpoint, [item])[0]
        branches()
        require(terminals[cold.request_id].cached_tokens == 0, "flush did not force cold recomputation")
        require(json.loads(cold.text) == {"answer": "ALPHA"}, "cold logical restore changed meaning")
        warm_item = replace(item, branch_id="reused", task=replace(item.task, branch_id="reused"))
        warm = session.fork_prepared(a.output_checkpoint, [warm_item])[0]
        branches()
        require_cache_hit(terminals[warm.request_id])
        require(terminals[cold.request_id].prompt_token_ids == terminals[warm.request_id].prompt_token_ids,
                "warm/cold input IDs differ")
        require(json.loads(warm.text) == json.loads(cold.text), "warm/cold semantic output differs")
        report["eviction"] = "public idle flush; capacity-pressure eviction not measured"

        doomed = session.fork(a.output_checkpoint, [
            BranchTask(tuple(backend.tokenize("\nContinue indefinitely.")), 256,
                       branch_id="abort", ignore_eos=True),
        ])[0]
        survivor = session.fork_prepared(a.output_checkpoint, [
            task(a.output_checkpoint, "abort-sibling", "BRAVO"),
        ])[0]
        session.abort(doomed)
        branches()
        require(doomed.status == "ABORTED", "abort did not terminate its logical branch")
        require(json.loads(survivor.text) == {"answer": "BRAVO"}, "abort killed prefix-named sibling")
        require(not backend.is_request_active(doomed.request_id), "aborted native request remains active")

        parent = survivor.output_checkpoint
        commits = [
            Commit(f"commit-semantic-{i}", f"semantic-{i}", "", (
                Fact(f"fact-{i}", f"marker-{i}", answer, (Evidence("INPUT"),)),
            ), (), (), (), True)
            for i, answer in enumerate(("ALPHA", "BRAVO"))
        ]
        children = session.fork(parent, [
            BranchTask(
                tuple(backend.tokenize("\nReturn exactly this Commit JSON:\n" + json.dumps(c.to_dict()))),
                256, branch_id=c.branch_id, structured_commit=True,
            ) for c in commits
        ])
        try:
            session.start_commit(parent, [], max_new_tokens=64, final_schema_json=json.dumps(ANSWER_SCHEMA))
        except RuntimeError as exc:
            require("all branches" in str(exc), "unexpected Brain barrier error")
        else:
            raise RuntimeError("Brain ran across live branches")
        branches()
        actual = session.collect_commits(children)
        require([c.to_dict() for c in actual] == [c.to_dict() for c in commits],
                "structured Commit generation changed the requested facts")
        session.start_commit(parent, actual, max_new_tokens=64,
                             final_schema_json=json.dumps(ANSWER_SCHEMA))
        final = brain()
        require(all(c.status == "COMMITTED" for c in children), "reducer did not commit branches")
        require(set(session.reducer.state.facts) == {"marker-0", "marker-1"}, "reducer lost facts")
        final_input = terminals[final.request_id].prompt_token_ids
        require(final_input[:len(parent.logical_token_ids)] == parent.logical_token_ids,
                "Brain continuation lost parent tokens")
        require("[OCTOPUS_SEMANTIC_DELTA]" in backend.decode(final_input[len(parent.logical_token_ids):]),
                "continuation bypassed the semantic delta")
        report["semantic_state"] = session.reducer.state.to_dict()
        report["final"] = asdict(final.checkpoint)
        report["completed_checks"] = [
            "exact_root_and_generated_tail", "two_inflight_requests", "actual_prefix_hits",
            "suffix_isolation", "release_with_live_children", "cold_restore_after_native_flush",
            "warm_reuse_after_recompute", "prefix_safe_abort", "structured_commit",
            "brain_barrier_and_semantic_continuation",
        ]
    finally:
        session.close()


def verify_inline_pressure_witness(before, after, update, chosen, other):
    producer_id = update["producer_request_id"]
    require(before["scheduler_pid"] == after["scheduler_pid"] == update["scheduler_pid"],
            "pressure observations came from different scheduler processes")
    require(producer_id in before["running_request_ids"] and producer_id in after["running_request_ids"],
            "native eviction was not observed while the normal producer remained active")
    leaves = before["evictable_leaves"]
    require(leaves, "no reclaimable native leaves at the pressure point")
    oldest = min(leaves, key=lambda node: node["native_lru"])
    require(oldest["priority"][0] == 1, "non-deciding model choice: no preference over the native-LRU victim")
    evictions = [r for r in after["receipts"] if r["kind"] == "evict" and r["sequence"] > update["sequence"]]
    require(evictions, "no real native eviction receipt")
    first = evictions[0]
    require(update["at"] <= before["at"] <= first["at"] <= after["at"],
            "eviction did not follow the acknowledged update and frozen pressure point")
    require(first["node_id"] != oldest["node_id"] and first["priority"][0] == 0
            and first["priority"][3] > oldest["native_lru"],
            "the first native victim did not demonstrably reverse strict LRU order")
    resident = {cp["checkpoint_id"]: cp["resident_prefix_tokens"] for cp in after["checkpoints"]}
    require(resident[chosen] > resident[other], "selected native prefix did not survive better")
    return {"native_lru_first_node": oldest["node_id"], "actual_first_eviction": first}


def exercise_inline_intent(backend, *, prefix_tokens, pressure_tokens, timeout_seconds, report):
    """One deciding pressure point; no forced model choice and no choice prefill."""
    require(backend.capabilities.dynamic_intent, "actual native dynamic intent is not enabled")
    producer = CaseSession(backend, "intent")
    pressure = CaseSession(backend, "pressure")
    deadline = time.monotonic() + timeout_seconds
    events = report["events"] = []

    def pump():
        require(time.monotonic() < deadline, "inline-intent conformance deadline exceeded")
        batch = backend.poll()
        for event in batch:
            events.append(asdict(event))
            require(event.error is None, f"generation failed: {event.error}")
        producer.accept_outputs(batch)
        pressure.accept_outputs(batch)
        return batch

    def await_brain(session):
        result = session.take_brain()
        while result is None:
            pump()
            result = session.take_brain()
        return result

    def exact_prompt(text, count):
        tokens = backend.tokenize(text * (count + 1))[:count]
        require(len(tokens) == count, "insufficient conformance prompt tokens")
        return tokens

    try:
        roots = []
        request_roles = {}
        for label in ("ALPHA critical repair context. ", "BRAVO optional formatting context. "):
            producer.start_brain(exact_prompt(label, prefix_tokens),
                                 max_new_tokens=8, ignore_eos=True)
            root = await_brain(producer)
            request_roles[f"root-{len(roots)}"] = root.request_id
            roots.append(root.checkpoint)
        body = {
            "type": "object", "required": ["dispatch_index", "answer"],
            "additionalProperties": False, "properties": {
                "dispatch_index": {"type": "integer", "enum": [0, 1]},
                "answer": {"const": "Continue the normal reducer analysis while the selected branch is needed. " * 24},
            },
        }
        prompt = backend.render_chat([{
            "role": "user",
            "content": "Choose the next useful branch for a failing repair task. "
                       "Branch 0 has critical repair context; branch 1 has optional formatting context. "
                       "Return your normal dispatch_index and the requested answer body.",
        }], add_generation_prompt=True)
        producer.start_brain(
            backend.tokenize(prompt), max_new_tokens=512, schema_json=json.dumps(body),
            inline_intent_checkpoints=roots,
        )
        update = None
        while update is None:
            if not pump():
                continue
            state = backend.intent_state()
            updates = [r for r in state["receipts"] if r["kind"] == "update" and r.get("producer_request_id")]
            if updates:
                update = updates[-1]
        producer_id = update["producer_request_id"]
        require(producer_id in state["running_request_ids"], "producer ended before the deciding pressure point")
        selected = [r["checkpoint_id"] for r in update["states"]
                    if r["importance"] * r["reuse_likelihood"] > 0]
        require(len(selected) == 1, "normal dispatch did not yield one exact selected checkpoint")
        chosen = selected[0]
        other = next(cp.checkpoint_id for cp in roots if cp.checkpoint_id != chosen)
        leaves = state["evictable_leaves"]
        require(leaves, "no reclaimable native leaves at the pressure point")
        oldest = min(leaves, key=lambda node: node["native_lru"])
        require(oldest["priority"][0] == 1,
                "non-deciding model choice: the selected checkpoint was already the native-LRU survivor")
        report["before_pressure"] = state
        pressure.start_brain(exact_prompt("Independent pressure allocation. ", pressure_tokens),
                             max_new_tokens=8, ignore_eos=True)
        after = None
        while after is None:
            pump()
            candidate = backend.intent_state(since=update["sequence"])
            evictions = [r for r in candidate["receipts"] if r["kind"] == "evict"]
            if evictions:
                report["pressure_witness"] = verify_inline_pressure_witness(
                    state, candidate, update, chosen, other,
                )
                after = candidate
        report["after_pressure_while_producer_active"] = after
        final = await_brain(producer)
        pressure_result = await_brain(pressure)
        require(final.inline_intent is not None and final.inline_intent.applied,
                "normal stream did not retain its applied native receipt")
        require(final.inline_intent.native_receipt == update, "native update receipt changed")
        require(json.loads(final.text) == final.inline_intent.body, "normal model output was rewritten")
        parent = next(cp for cp in roots if cp.checkpoint_id == chosen)
        branch = producer.fork(parent, [BranchTask(
            tuple(backend.tokenize("\nContinue this branch briefly.")), 8, ignore_eos=True,
        )])[0]
        while producer.has_pending_branches():
            pump()
        final_state = backend.intent_state(since=update["sequence"])
        consumed = [r for r in final_state["receipts"]
                    if r["kind"] == "first_scheduled" and r["request_id"] == branch.request_id]
        require(len(consumed) == 1 and consumed[0]["consumed"],
                "next actually scheduled bound use did not consume the hint once")
        report["normal_brain"] = asdict(final)
        report["final_native_state"] = final_state
        request_roles.update(producer=final.request_id, pressure=pressure_result.request_id,
                             bound_use=branch.request_id)
        require({event["internal_request_id"] for event in events} == set(request_roles.values()),
                "generation trace contains an unexpected request")
        report["generation_request_ids_by_role"] = request_roles
        report["completed_checks"] = [
            "normal_stream_exact_output", "native_update_before_producer_terminal",
            "real_victim_changed_while_producer_active", "next_scheduled_use_consumed_once",
        ]
    finally:
        try:
            pressure.close()
        finally:
            producer.close()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--backend", choices=("vllm", "sglang"), required=True)
    parser.add_argument("--check", choices=("foundation", "inline-intent"), default="foundation")
    parser.add_argument("--pressure-tokens", type=int)
    parser.add_argument("--model-path", required=True)
    parser.add_argument("--tokenizer-path")
    parser.add_argument("--worker-python", default=sys.executable)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--max-model-len", type=int, default=4096)
    parser.add_argument("--prefix-tokens", type=int, default=512)
    parser.add_argument("--max-total-tokens", type=int, default=4096)
    parser.add_argument("--memory-fraction", type=float, default=0.8)
    parser.add_argument("--timeout-seconds", type=float, default=180)
    args = parser.parse_args(argv)
    if args.check == "inline-intent" and (
        args.backend != "sglang" or args.pressure_tokens is None or args.pressure_tokens < 1
    ):
        parser.error("inline-intent requires SGLang and an explicitly frozen positive --pressure-tokens budget")
    report = {"status": "failed", "scope": f"backend-{args.check}-native-conformance",
              "arguments": {**vars(args), "output": str(args.output)},
              "quality_performance_or_full_plan_claim": False}
    backend = None
    sibling = subprocess.Popen([sys.executable, "-c", "import time; time.sleep(600)"])
    try:
        if args.backend == "sglang":
            from octopus.sglang_backend import SglangBackend, SglangConfig
            backend = SglangBackend(SglangConfig(
                model_path=args.model_path, tokenizer_path=args.tokenizer_path,
                max_model_len=args.max_model_len, max_total_tokens=args.max_total_tokens,
                mem_fraction_static=args.memory_fraction, python_executable=args.worker_python,
                dynamic_intent=args.check == "inline-intent",
            ))
        else:
            backend = Octopus(BackendConfig(
                model_path=args.model_path, tokenizer_path=args.tokenizer_path,
                max_model_len=args.max_model_len, retention_policy="apc",
                kv_cache_memory_bytes=None, gpu_memory_utilization=args.memory_fraction,
            )).backend
        report["environment"] = backend.environment_metadata()
        if args.check == "inline-intent":
            exercise_inline_intent(
                backend, prefix_tokens=args.prefix_tokens, pressure_tokens=args.pressure_tokens,
                timeout_seconds=args.timeout_seconds, report=report,
            )
        else:
            exercise(backend, prefix_tokens=args.prefix_tokens,
                     timeout_seconds=args.timeout_seconds, report=report)
        report["status"] = "passed"
    except Exception as exc:
        report["error"] = f"{type(exc).__name__}: {exc}"
    finally:
        try:
            if backend is not None:
                backend.close()
            require(sibling.poll() is None, "engine shutdown terminated the unrelated tool sibling")
            report["cleanup"] = "engine closed; sibling tool survived"
        except Exception as exc:
            report["status"] = "failed"
            report["cleanup_error"] = f"{type(exc).__name__}: {exc}"
        finally:
            if sibling.poll() is None:
                sibling.terminate()
            sibling.wait(timeout=5)
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(report, indent=2) + "\n")
    print(f"{args.output}: {report['status']}")
    return 0 if report["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
