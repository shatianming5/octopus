"""Engine-free placement identities; logical demand is not transfer readiness."""
from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass
from enum import Enum


class CacheTier(str, Enum):
    L1 = "L1"
    L2 = "L2"
    L3 = "L3"


@dataclass(frozen=True, slots=True)
class KVLayout:
    dtype: str
    host_layout: str
    page_size: int
    page_shape: tuple[int, ...]
    model_shape: tuple[int, int, int]

    def __post_init__(self):
        if not self.dtype or not self.host_layout:
            raise ValueError("KV layout requires dtype and host layout")
        if (type(self.page_size) is not int or self.page_size < 1
                or not self.page_shape
                or any(type(size) is not int or size < 1 for size in (*self.page_shape, *self.model_shape))):
            raise ValueError("KV page size and dimensions must be positive integers")


@dataclass(frozen=True, slots=True)
class CacheIdentity:
    namespace: str
    model: str
    weight_revision: str
    tokenizer_revision: str
    kv_layout: KVLayout

    def __post_init__(self):
        for value in (self.namespace, self.model, self.weight_revision, self.tokenizer_revision):
            if not isinstance(value, str) or not value:
                raise ValueError("cache identity requires namespace, model, weight and tokenizer revisions")
        if not isinstance(self.kv_layout, KVLayout):
            raise ValueError("cache identity requires an explicit KV layout")

    def to_dict(self):
        return asdict(self)

    @classmethod
    def from_dict(cls, value):
        layout = value["kv_layout"]
        return cls(**{**value, "kv_layout": KVLayout(
            **{**layout, "page_shape": tuple(layout["page_shape"]),
               "model_shape": tuple(layout["model_shape"])},
        )})

    @property
    def storage_namespace(self):
        encoded = json.dumps(self.to_dict(), sort_keys=True, separators=(",", ":")).encode()
        return "octopus-" + hashlib.sha256(encoded).hexdigest()


@dataclass(frozen=True, slots=True)
class PlacementRequest:
    action: str
    target: CacheTier
    identity: CacheIdentity
    prefix_tokens: int | None = None
    consumer_id: str | None = None

    def __post_init__(self):
        if self.action not in {"retain", "demote", "prefetch", "release"}:
            raise ValueError("unsupported cache placement action")
        object.__setattr__(self, "target", CacheTier(self.target))
        if self.prefix_tokens is not None and (
            type(self.prefix_tokens) is not int or self.prefix_tokens < 1
        ):
            raise ValueError("placement prefix must be a positive integer")

    def to_dict(self):
        return asdict(self)


@dataclass(frozen=True, slots=True)
class PlacementResult:
    operation_id: str
    checkpoint_id: str
    generation: int
    identity: CacheIdentity
    action: str
    target: CacheTier
    disposition: str
    readiness: str
    target_tokens: int
    l1_ready_tokens: int
    l2_ready_tokens: int
    l3_confirmed_tokens: int
    native_pending: bool
    memory: dict
    transfers: tuple[dict, ...] = ()
    error: str | None = None

    @classmethod
    def from_dict(cls, value):
        return cls(**{**value, "identity": CacheIdentity.from_dict(value["identity"]),
                      "target": CacheTier(value["target"]),
                      "transfers": tuple(value["transfers"])})
