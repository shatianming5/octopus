"""Scheduler-process, revocable FULL-radix preferences for SGLang 0.5.19.

The pinned source hook owns invocation order. This module never changes locks,
pool capacity, request priority, or session references.
"""
from __future__ import annotations

import os
import time
from array import array
from dataclasses import asdict, dataclass, replace

from octopus.model_intent import ModelIntent
from sglang.srt.mem_cache.unified_radix_cache import UnifiedRadixCache


PROTOCOL = 1
SOURCE_COMMIT = "0bcd822377da7b5718e674eaf9c870d349424dd1"


class IntentRadixCache(UnifiedRadixCache):
    """Use native selection/freeing, with preferences refreshed before its draw."""
    octopus_intent_protocol = PROTOCOL

    def __init__(self, params):
        self.octopus_intents = None
        self._placement_load_index = None
        super().__init__(params)

    def ready_to_load_host_cache(self):
        index = super().ready_to_load_host_cache()
        if self.cache_controller is None:
            return index
        if index >= 0:
            self._placement_load_index = index
        elif self._placement_load_index is not None and not self.is_load_back_event_done(self._placement_load_index):
            return self._placement_load_index
        return index

    def _evict(self, params, available_size_targets=None):
        if self.octopus_intents is not None:
            self.octopus_intents.prepare_octopus_eviction()
        return super()._evict(params, available_size_targets)

    def evict_host(self, num_tokens):
        if self.octopus_intents is not None:
            self.octopus_intents.prepare_octopus_eviction()
        return super().evict_host(num_tokens)

    def _evict_device_leaf(self, node_id, tracker):
        control = self.octopus_intents
        if control is not None:
            node = self.tree_core.node_by_id(node_id)
            tokens = len(node.component_data[control.full].value)
            priority = control.get_priority(node)
        result = super()._evict_device_leaf(node_id, tracker)
        if control is not None:
            control.on_octopus_evict(node_id, tokens, priority)
        return result

    def reset(self):
        super().reset()
        self._placement_load_index = None
        if self.octopus_intents is not None:
            self.octopus_intents.reset_octopus_intents()


def make_cache(ctx):
    from sglang.srt.mem_cache.unified_cache.components import ComponentType
    if (ctx.is_hybrid_swa or ctx.is_hybrid_ssm
            or ctx.disable_radix_cache or ctx.tp_size != 1
            or hasattr(ctx.params.req_to_token_pool, "req_to_c128_sidecar")):
        raise ValueError("Octopus intent supports only single-rank FULL device radix caching")
    params = replace(ctx.params, tree_components=(ComponentType.FULL,))
    cache = IntentRadixCache(params)
    if ctx.enable_hierarchical_cache:
        cache.init_hicache(ctx.server_args, params)
        ctx.tp_worker.register_hicache_layer_transfer_counter(cache.cache_controller.layer_done_counter)
    return cache


def register_backend():
    from sglang.srt.mem_cache.registry import (
        get_radix_cache_factory, register_radix_cache_backend,
    )
    existing = get_radix_cache_factory("octopus-intent")
    if existing is None:
        register_radix_cache_backend("octopus-intent", make_cache)
    elif existing is not make_cache:
        raise ValueError("octopus-intent cache factory is already registered by another implementation")


@dataclass(frozen=True)
class LogicalPrefix:
    owner: str
    checkpoint_id: str
    generation: int
    token_ids: tuple[int, ...]

    @property
    def key(self):
        return self.owner, self.checkpoint_id, self.generation


@dataclass
class BoundUse:
    prefix: LogicalPrefix
    prompt_token_ids: tuple[int, ...]
    scheduled: bool = False
    consumer_id: str | None = None


class NativeIntents:
    def __init__(self, scheduler):
        from sglang.srt.mem_cache.evict_policy import LRUStrategy
        from sglang.srt.mem_cache.unified_cache.components import ComponentType
        cache = scheduler.tree_cache
        if (not isinstance(cache, UnifiedRadixCache)
                or cache.tree_components != (ComponentType.FULL,)
                or cache.enable_session_radix_cache
                or cache.tree_core.is_eagle or cache.disable
                or cache._tree_core_backend != "python"
                or not isinstance(cache.tree_core.eviction_strategy, LRUStrategy)):
            raise ValueError("dynamic intent requires enabled Python Unified FULL radix LRU, without sessions/EAGLE")
        self.scheduler = scheduler
        self.cache = cache
        self.full = ComponentType.FULL
        self.native_strategy = cache.tree_core.eviction_strategy
        self.open: dict[tuple[str, str, int], LogicalPrefix] = {}
        self.generations: dict[tuple[str, str], int] = {}
        self.closed_owners: set[str] = set()
        self.intents: dict[tuple[str, str, int], ModelIntent] = {}
        self.bindings: dict[str, BoundUse] = {}
        self.live_requests: dict[str, object] = {}
        self.receipts: list[dict] = []
        self._queued_prefixes: tuple = ()
        cache.tree_core.eviction_strategy = self
        cache.components[self.full].session_ref_eviction_strategy = self.get_priority
        cache.octopus_intents = self
        self.placement = None
        if cache.tree_core.enable_hicache:
            if (cache.host_memory_mode != "cache" or cache.cache_controller is None
                    or not hasattr(cache.cache_controller, "octopus_cache_identity")):
                raise ValueError("HiCache placement requires explicit bound storage identity and cache-mode host pool")
            from octopus.sglang_placement import NativePlacement
            self.placement = NativePlacement(self)
            cache.octopus_placement = self.placement

    def _record(self, kind, owner=None, **details):
        receipt = {
            "sequence": len(self.receipts) + 1, "kind": kind,
            "at": time.monotonic(), "scheduler_pid": os.getpid(),
            "owner": owner, **details,
        }
        self.receipts.append(receipt)
        return receipt

    def _prefix(self, owner, data):
        if not isinstance(owner, str) or not owner or owner in self.closed_owners:
            raise ValueError("unknown or closed intent owner")
        cp, generation, tokens = data["checkpoint_id"], data["generation"], data["token_ids"]
        if not isinstance(cp, str) or not cp or type(generation) is not int or generation < 1:
            raise ValueError("checkpoint identity requires a positive open generation")
        if not tokens or any(type(token) is not int for token in tokens):
            raise ValueError("checkpoint requires exact integer token IDs")
        prefix = LogicalPrefix(owner, cp, generation, tuple(tokens))
        previous = self.generations.get((owner, cp), 0)
        current = self.open.get(prefix.key)
        if generation < previous or (generation == previous and current is None):
            raise ValueError("checkpoint generation is stale or released")
        if current is not None and current != prefix:
            raise ValueError("checkpoint token identity changed")
        if generation > previous and any(key[:2] == (owner, cp) for key in self.open):
            raise ValueError("previous checkpoint generation is still open")
        return prefix

    def _register(self, prefix):
        self.open[prefix.key] = prefix
        self.generations[(prefix.owner, prefix.checkpoint_id)] = prefix.generation

    def handle(self, payload):
        op, owner = payload["op"], payload["owner"]
        if not isinstance(owner, str) or not owner or owner in self.closed_owners:
            raise ValueError("unknown or closed intent owner")
        if op == "hello":
            return {"protocol": PROTOCOL, "source_commit": SOURCE_COMMIT,
                    "scheduler_pid": os.getpid(), "tree_core_backend": "python",
                    "mechanism": "revocable-full-radix-victim-preference-no-locks",
                    "placement_identity": self.placement.identity.to_dict() if self.placement else None}
        if op in {"place", "placement_status"}:
            if self.placement is None:
                raise ValueError("native HiCache placement is not configured")
            return self.placement.handle(payload)
        if op == "update":
            rows = payload["states"]
            if not rows:
                raise ValueError("intent update requires an exact nonempty batch")
            staged = [(self._prefix(owner, row), ModelIntent(**row["intent"])) for row in rows]
            if len({prefix.checkpoint_id for prefix, _ in staged}) != len(staged):
                raise ValueError("duplicate checkpoint in intent update")
            producer = payload.get("producer_request_id")
            if producer is not None:
                req = self.live_requests.get(producer)
                if req is None or req.finished():
                    raise ValueError("inline producer is not actively scheduled; late update rejected")
            for prefix, intent in staged:
                self._register(prefix)
                if intent.expected_importance > 0:
                    self.intents[prefix.key] = intent
                else:
                    self.intents.pop(prefix.key, None)
            self.prepare_octopus_eviction()
            return self._record(
                "update", owner, producer_request_id=producer,
                states=[{"checkpoint_id": p.checkpoint_id, "generation": p.generation,
                         **asdict(intent)} for p, intent in staged],
            )
        if op == "bind":
            prefix = self._prefix(owner, payload["checkpoint"])
            rid, prompt = payload["request_id"], tuple(payload["prompt_token_ids"])
            if rid in self.bindings or prompt[:len(prefix.token_ids)] != prefix.token_ids:
                raise ValueError("duplicate request or non-canonical checkpoint binding")
            self._register(prefix)
            self.bindings[rid] = BoundUse(prefix, prompt, consumer_id=payload.get("consumer_id"))
            return self._record("bind", owner, request_id=rid,
                                checkpoint_id=prefix.checkpoint_id, generation=prefix.generation)
        if op in {"release", "cancel"}:
            prefix = self._prefix(owner, payload["checkpoint"])
            self._register(prefix)
            self.intents.pop(prefix.key, None)
            if op == "release":
                if self.placement is not None:
                    self.placement.release_checkpoint(prefix.key)
                del self.open[prefix.key]
            elif self.placement is not None:
                self.placement.release_consumer(prefix.key, payload.get("consumer_id"))
            return self._record(op, owner, checkpoint_id=prefix.checkpoint_id,
                                generation=prefix.generation)
        if op == "finish":
            rid = payload["request_id"]
            binding = self.bindings.get(rid)
            if binding is not None and binding.prefix.owner != owner:
                raise ValueError("request belongs to a different intent owner")
            self.live_requests.pop(rid, None)
            self.bindings.pop(rid, None)
            if binding is not None and payload["failed"]:
                self.intents.pop(binding.prefix.key, None)
            if binding is not None and self.placement is not None:
                self.placement.release_consumer(binding.prefix.key, binding.consumer_id)
            return self._record("finish", owner, request_id=rid, failed=payload["failed"])
        if op == "snapshot":
            return self.snapshot(owner, payload.get("since", 0))
        if op == "close":
            keys = [key for key in self.open if key[0] == owner]
            for key in keys:
                if self.placement is not None:
                    self.placement.release_checkpoint(key)
                self.open.pop(key)
                self.intents.pop(key, None)
            for rid, binding in list(self.bindings.items()):
                if binding.prefix.owner == owner:
                    self.bindings.pop(rid)
            self.closed_owners.add(owner)
            return self._record("close", owner)
        raise ValueError(f"unsupported native intent operation {op!r}")

    def first_scheduled(self, requests):
        requests = tuple(requests)
        for req in requests:
            binding = self.bindings.get(req.rid)
            if binding is not None and not binding.scheduled:
                if tuple(req.origin_input_ids) != binding.prompt_token_ids:
                    raise ValueError("native request changed the bound canonical input IDs")
        self.live_requests = {rid: req for rid, req in self.live_requests.items() if not req.finished()}
        for req in requests:
            self.live_requests[req.rid] = req
            binding = self.bindings.get(req.rid)
            if binding is None or binding.scheduled:
                continue
            binding.scheduled = True
            consumed = self.intents.pop(binding.prefix.key, None) is not None
            self._record(
                "first_scheduled", binding.prefix.owner, request_id=req.rid,
                checkpoint_id=binding.prefix.checkpoint_id,
                generation=binding.prefix.generation, consumed=consumed,
            )

    def abort_request(self, rid, abort_all=False):
        if not rid and not abort_all:
            return
        for request_id, binding in list(self.bindings.items()):
            if abort_all or request_id.startswith(rid):
                self.intents.pop(binding.prefix.key, None)
                if self.placement is not None:
                    self.placement.release_consumer(binding.prefix.key, binding.consumer_id)
                self.bindings.pop(request_id)
                self._record("abort", binding.prefix.owner, request_id=request_id,
                             checkpoint_id=binding.prefix.checkpoint_id,
                             generation=binding.prefix.generation)

    def reset_octopus_intents(self):
        self.intents.clear()
        if self.placement is not None:
            self.placement.reset()
        self._record("reset")

    def _queues(self):
        return (*self.scheduler.waiting_queue, *self.scheduler.grammar_manager.grammar_queue)

    def prepare_octopus_eviction(self):
        self._queued_prefixes = tuple(
            ((*req.origin_input_ids, *req.output_ids), req.extra_key, req.cache_salt)
            for req in self._queues() if not req.finished()
        )
        for key in self.intents:
            self._split_boundary(self.open[key].token_ids, None, None)
        if self.placement is not None:
            for demand, operation_id in self.placement.demands.items():
                prefix = self.open.get(demand[:3])
                if prefix is not None:
                    count = self.placement.moves[operation_id].target_tokens
                    self._split_boundary(prefix.token_ids[:count], None, None)
        for tokens, extra, salt in self._queued_prefixes:
            self._split_boundary(tokens, extra, salt)

    def _split_boundary(self, tokens, extra, salt):
        from sglang.srt.mem_cache.radix_cache import RadixKey
        core = self.cache.tree_core
        remaining = RadixKey(array("q", tokens), extra_key=extra, cache_salt=salt).page_aligned(core.page_size)
        node = core.root_node
        while len(remaining):
            child = node.children.get(remaining.child_key(core.page_size))
            if child is None or (child.evicted and not child.backuped):
                return
            count = child.key.match(remaining, page_size=core.page_size)
            if count < len(child.key):
                # Use native split bookkeeping without making the hint a cache hit.
                previous_time = child.last_access_time
                parent, action = core._split_node(child.key, child, count)
                if action is not None:
                    self.cache._apply_cache_action(action)
                parent.last_access_time = child.last_access_time = previous_time
                return
            remaining = remaining[count:]
            node = child

    @staticmethod
    def _node_prefix(node):
        parts = []
        current = node
        while current.parent is not None:
            parts.append(tuple(current.key))
            current = current.parent
        return tuple(token for part in reversed(parts) for token in part)

    def get_priority(self, node):
        return self._priority(node, "L1")

    def get_host_priority(self, node):
        return self._priority(node, "L2")

    def _priority(self, node, tier):
        tokens = self._node_prefix(node)
        suffix = self.native_strategy.get_priority(node)
        for prompt, extra, salt in self._queued_prefixes:
            if (node.key.extra_key == extra and node.key.cache_salt == salt
                    and prompt[:len(tokens)] == tokens):
                return 2, False, 0.0, suffix
        best = (0, False, 0.0)
        if self.placement is not None and self.placement.preference(node, tier):
            best = (1, False, 0.0)
        if node.key.extra_key is None and node.key.cache_salt is None:
            for key, intent in self.intents.items():
                if self.open[key].token_ids[:len(tokens)] == tokens:
                    best = max(best, (1, intent.criticality, intent.expected_importance))
        return *best, suffix

    def on_octopus_evict(self, node_id, tokens, priority):
        self._record("evict", node_id=node_id, tokens=tokens, priority=priority)

    def _resident_prefix(self, prefix):
        from sglang.srt.mem_cache.radix_cache import RadixKey
        core = self.cache.tree_core
        remaining = RadixKey(array("q", prefix.token_ids)).page_aligned(core.page_size)
        node, count = core.root_node, 0
        while len(remaining):
            child = node.children.get(remaining.child_key(core.page_size))
            if child is None or child.component_data[self.full].value is None:
                break
            length = child.key.match(remaining, page_size=core.page_size)
            count += length
            if length < len(child.key):
                break
            remaining = remaining[length:]
            node = child
        return count

    def snapshot(self, owner, since=0):
        return {
            "protocol": PROTOCOL, "scheduler_pid": os.getpid(),
            "at": time.monotonic(),
            "intents": [
                {"checkpoint_id": key[1], "generation": key[2], **asdict(intent)}
                for key, intent in self.intents.items() if key[0] == owner
            ],
            "checkpoints": [
                {"checkpoint_id": p.checkpoint_id, "generation": p.generation,
                 "resident_prefix_tokens": self._resident_prefix(p)}
                for p in self.open.values() if p.owner == owner
            ],
            "running_request_ids": [rid for rid, req in self.live_requests.items() if not req.finished()],
            "evictable_leaves": [
                {"node_id": node.id, "native_lru": self.native_strategy.get_priority(node),
                 "priority": self.get_priority(node),
                 "tokens": len(node.component_data[self.full].value)}
                for node in self.cache.tree_core.evictable_device_leaves
            ],
            "receipts": [r for r in self.receipts if r["sequence"] > since and r["owner"] in (owner, None)],
            "full_evictable_tokens": self.cache.full_evictable_size(),
        }


def handle_native_intent(scheduler, payload):
    if (getattr(type(scheduler), "octopus_intent_protocol", None) != PROTOCOL
            or not isinstance(scheduler.tree_cache, IntentRadixCache)):
        raise ValueError("complete pinned Octopus scheduler/cache source extension is not loaded")
    control = getattr(scheduler, "_octopus_intents", None)
    if control is None:
        if payload.get("op") != "hello":
            raise ValueError("native intent protocol must be initialized first")
        control = NativeIntents(scheduler)
        scheduler._octopus_intents = control
    return control.handle(payload)
