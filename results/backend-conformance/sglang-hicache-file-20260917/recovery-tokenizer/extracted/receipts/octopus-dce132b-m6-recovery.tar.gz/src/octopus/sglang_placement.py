"""FULL HiCache placement integration, separate from model-intent ranking."""
from __future__ import annotations

import time
from array import array
from dataclasses import asdict, dataclass, field, replace
from pathlib import Path

from octopus.cache_placement import CacheIdentity, CacheTier, KVLayout, PlacementRequest, PlacementResult


def storage_identity(declaration, *, model_path, tokenizer_path, host_pool):
    if Path(model_path).name != declaration["weight_revision"]:
        raise ValueError("weight revision differs from the loaded immutable snapshot path")
    if Path(tokenizer_path or model_path).name != declaration["tokenizer_revision"]:
        raise ValueError("tokenizer revision differs from the loaded immutable snapshot path")
    page = host_pool.get_data_page(0)
    layout = KVLayout(
        str(page.dtype), host_pool.layout, host_pool.page_size, tuple(page.shape),
        (host_pool.layer_num, host_pool.head_num, host_pool.head_dim),
    )
    return CacheIdentity(**declaration, kv_layout=layout)


def bind_storage_config(controller, config, *, model_path, tokenizer_path):
    declaration = (config.extra_config or {}).get("octopus_cache_identity")
    if declaration is None:
        return config
    identity = storage_identity(
        declaration, model_path=model_path, tokenizer_path=tokenizer_path,
        host_pool=controller.storage_host_pool,
    )
    controller.octopus_cache_identity = identity
    return replace(config, model_name=identity.storage_namespace)


@dataclass
class _Move:
    operation_id: str
    key: tuple[str, str, int]
    request: PlacementRequest
    target_tokens: int
    start_sequence: int
    disposition: str = "accepted"
    readiness: str = "pending"
    error: str | None = None
    storage_operations: set[int] = field(default_factory=set)
    prefetch: object | None = None
    confirmed_l3: int = 0


class NativePlacement:
    """Serialize logical demands with the native cache's transfer lifecycle."""
    def __init__(self, intents):
        self.intents = intents
        self.cache = intents.cache
        self.identity = self.cache.cache_controller.octopus_cache_identity
        self.moves: dict[str, _Move] = {}
        self.demands: dict[tuple, str] = {}
        self.transfers: list[dict] = []
        self.storage_results: dict[int, dict] = {}
        self.confirmed_hashes: set[str] = set()

    def record_transfer(self, direction, *, payload_bytes, nodes=(), confirmed_tokens=0,
                        actual_bytes=None, error=None):
        self.transfers.append({
            "sequence": len(self.transfers) + 1, "direction": direction, "at": time.monotonic(),
            "native_node_ids": list(nodes), "payload_bytes": payload_bytes,
            "actual_bytes": actual_bytes, "confirmed_tokens": confirmed_tokens, "error": error,
            "scope": "native transfer; may serve multiple logical owners",
        })

    def storage_complete(self, operation):
        expected = len(operation.hash_value) * self.cache.page_size
        completed = operation.completed_tokens
        error = operation.error
        if error is None and completed != expected:
            error = f"native storage write confirmed {completed}/{expected} tokens"
        self.storage_results[operation.id] = {
            "completed": completed, "error": error, "hashes": tuple(operation.hash_value),
            "sequence": len(self.transfers) + 1,
        }
        self.confirmed_hashes.update(operation.hash_value[:completed // self.cache.page_size])
        size = self.cache.cache_controller.mem_pool_host.size_per_token
        self.record_transfer("L2->L3", payload_bytes=completed * size,
                             confirmed_tokens=completed, error=error)

    def _nodes(self, prefix, count):
        from sglang.srt.mem_cache.radix_cache import RadixKey
        core = self.cache.tree_core
        self.intents._split_boundary(prefix.token_ids[:count], None, None)
        remaining = RadixKey(array("q", prefix.token_ids[:count])).page_aligned(core.page_size)
        node, nodes = core.root_node, []
        while len(remaining):
            child = node.children.get(remaining.child_key(core.page_size))
            if child is None:
                break
            matched = child.key.match(remaining, page_size=core.page_size)
            if matched != len(child.key):
                break
            nodes.append(child)
            node, remaining = child, remaining[matched:]
        return nodes

    def _ready_counts(self, nodes):
        l1 = l2 = 0
        pending_load_nodes = self._pending_load_nodes()
        device_contiguous = host_contiguous = True
        for node in nodes:
            data = node.component_data[self.intents.full]
            device_contiguous &= data.value is not None and node.id not in pending_load_nodes
            host_contiguous &= data.host_value is not None and node.write_through_pending_id is None
            if device_contiguous:
                l1 += len(node.key)
            if host_contiguous:
                l2 += len(node.key)
        return l1, l2

    def _pending_load_nodes(self):
        pending = set()
        core = self.cache.tree_core
        for anchor in self.cache.ongoing_load_back:
            node = core.node_by_id(anchor)
            while node is not core.root_node:
                pending.add(node.id)
                node = node.parent
        return pending

    def _demand_key(self, move):
        return (*move.key, move.request.consumer_id, move.request.target.value)

    def handle(self, payload):
        owner, operation_id = payload["owner"], payload["operation_id"]
        if payload["op"] == "placement_status":
            move = self.moves[operation_id]
            if move.key[0] != owner:
                raise ValueError("placement operation belongs to a different owner")
            return self.status(move)
        data = payload["request"]
        request = PlacementRequest(
            **{**data, "identity": CacheIdentity.from_dict(data["identity"])},
        )
        if request.identity != self.identity:
            raise ValueError("placement model/weight/tokenizer/layout/namespace mismatch")
        prefix = self.intents._prefix(owner, payload["checkpoint"])
        if operation_id in self.moves:
            raise ValueError("placement operation identity already exists")
        count = request.prefix_tokens
        if count is None:
            counts = self._ready_counts(self._nodes(prefix, len(prefix.token_ids)))
            count = max(counts)
        if not count or count > len(prefix.token_ids) or count % self.cache.page_size:
            raise ValueError("placement requires a positive materialized, page-aligned logical prefix")
        self.intents._register(prefix)
        move = _Move(operation_id, prefix.key, request, count, len(self.transfers))
        self.moves[operation_id] = move
        demand = self._demand_key(move)
        previous = self.demands.pop(demand, None)
        if previous is not None:
            self._cancel(self.moves[previous])
        if request.action == "release":
            move.readiness = "ready"
        else:
            self.demands[demand] = operation_id
        return self.status(move)

    def _cancel(self, move):
        if move.prefetch is not None and move.operation_id in self.cache.ongoing_prefetch:
            self.cache.release_aborted_request(move.operation_id)
        move.readiness = "cancelled"

    def release_checkpoint(self, key):
        for demand, operation_id in list(self.demands.items()):
            if demand[:3] == key:
                self.demands.pop(demand)
                self._cancel(self.moves[operation_id])

    def release_consumer(self, key, consumer_id):
        if consumer_id is None:
            return
        for demand, operation_id in list(self.demands.items()):
            if demand[:3] == key and demand[3] == consumer_id:
                self.demands.pop(demand)
                self._cancel(self.moves[operation_id])

    def reset(self):
        for move in self.moves.values():
            if move.readiness == "pending":
                move.readiness, move.error = "failed", "native cache reset invalidated the transfer"
        self.confirmed_hashes.clear()
        self.demands.clear()

    def preference(self, node, tier):
        tokens = self.intents._node_prefix(node)
        return any(
            demand[-1] == tier
            and (prefix := self.intents.open.get(demand[:3])) is not None
            and prefix.token_ids[:len(tokens)] == tokens
            for demand in self.demands
        )

    def _pending(self, move, nodes):
        pending_load_nodes = self._pending_load_nodes()
        return bool(
            any(n.write_through_pending_id is not None or n.id in pending_load_nodes for n in nodes)
            or any(op in self.cache.ongoing_backup for op in move.storage_operations)
            or (move.prefetch is not None and not move.prefetch.io_completed)
        )

    def status(self, move):
        self.cache.check_hicache_events()
        prefix = self.intents.open.get(move.key)
        if prefix is None:
            if move.readiness == "pending":
                self._cancel(move)
            nodes = []
        else:
            nodes = self._nodes(prefix, move.target_tokens)
        l1, l2 = self._ready_counts(nodes)
        if move.readiness == "pending":
            self._advance(move, prefix, nodes, l1, l2)
            nodes = self._nodes(prefix, move.target_tokens) if prefix is not None else []
            l1, l2 = self._ready_counts(nodes)
        return asdict(PlacementResult(
            move.operation_id, move.key[1], move.key[2], self.identity,
            move.request.action, move.request.target, move.disposition, move.readiness,
            move.target_tokens, l1, l2, move.confirmed_l3,
            self._pending(move, nodes), self.memory(),
            tuple(self.transfers[move.start_sequence:]), move.error,
        ))

    def memory(self):
        cc = self.cache.cache_controller
        size = cc.mem_pool_host.size_per_token
        return {
            "device_capacity_tokens": cc.mem_pool_device.size,
            "device_free_tokens": self.cache._component_available_size(self.intents.full),
            "host_capacity_tokens": cc.mem_pool_host.size,
            "host_free_tokens": cc.mem_pool_host.available_size(),
            "host_bytes_per_token": size,
            "host_capacity_bytes": size * cc.mem_pool_host.size,
            "prefetch_occupied_tokens": cc.prefetch_tokens_occupied,
        }

    def _advance(self, move, prefix, nodes, l1, l2):
        from sglang.srt.mem_cache.unified_cache.cache_action import BackupKV
        if prefix is None:
            self._cancel(move)
            return
        if move.prefetch is not None:
            if move.prefetch.io_error is not None:
                move.readiness, move.error = "failed", move.prefetch.io_error
                return
            if move.prefetch.io_completed:
                completed = move.prefetch.completed_tokens
                move.confirmed_l3 = max(move.confirmed_l3, completed)
                if completed < move.target_tokens:
                    move.readiness, move.error = "failed", f"native L3 read returned {completed}/{move.target_tokens} tokens"
                    return
            elif move.operation_id not in self.cache.ongoing_prefetch and move.prefetch.host_indices is None:
                move.readiness, move.error = "failed", "native L3 lookup produced no transferable prefix"
                return
        for operation_id in move.storage_operations:
            result = self.storage_results.get(operation_id)
            if result is not None and result["error"] is not None:
                move.readiness, move.error = "failed", result["error"]
                return
        if move.request.target == CacheTier.L3:
            hashes = {key for node in nodes for key in (node.hash_value or [])}
            for result in self.storage_results.values():
                if (result["sequence"] > move.start_sequence and result["error"] is not None
                        and hashes.intersection(result["hashes"])):
                    move.readiness, move.error = "failed", result["error"]
                    return
        if move.request.target == CacheTier.L1 and l1 >= move.target_tokens:
            move.readiness = "ready"
            return
        if move.request.target == CacheTier.L2 and l2 >= move.target_tokens:
            if move.request.action == "demote":
                if not self._demote_device(nodes):
                    move.disposition = "deferred"
                    return
            move.readiness = "ready"
            return
        if move.request.target == CacheTier.L3:
            hashes = [key for node in nodes for key in (node.hash_value or [])]
            if hashes and len(hashes) * self.cache.page_size >= move.target_tokens and set(hashes) <= self.confirmed_hashes:
                move.confirmed_l3 = move.target_tokens
                if move.request.action == "demote" and not self._demote_device(nodes):
                    move.disposition = "deferred"
                    return
                move.readiness = "ready"
                return
        if l2 < move.target_tokens and l1 >= move.target_tokens:
            missing = [node.id for node in nodes
                       if node.component_data[self.intents.full].host_value is None]
            if missing and not self.cache._execute_and_commit_kv_backup(BackupKV(missing)):
                move.disposition = "deferred"
            return
        if l2 >= move.target_tokens:
            if move.request.target == CacheTier.L3:
                for node in nodes:
                    existing = [op for op, (node_id, _) in self.cache.ongoing_backup.items() if node_id == node.id]
                    if existing:
                        move.storage_operations.update(existing)
                    elif not set(node.hash_value or []) <= self.confirmed_hashes:
                        operation_id = self.cache.write_backup_storage(node.id)
                        if operation_id is not None:
                            move.storage_operations.add(operation_id)
                return
            if move.request.target == CacheTier.L1:
                cc = self.cache.cache_controller
                if cc.ack_load_queue or cc.load_queue:
                    move.disposition = "deferred"
                    return
                if self.cache.load_back(nodes[-1].id, mem_quota=move.target_tokens):
                    self.cache.ready_to_load_host_cache()
                else:
                    move.disposition = "deferred"
                return
        pending_load_nodes = self._pending_load_nodes()
        if any(n.write_through_pending_id is not None or n.id in pending_load_nodes for n in nodes):
            return
        if move.prefetch is None:
            self.cache.prefetch_from_storage(
                move.operation_id, self.cache.tree_core.root_node.id,
                array("q", prefix.token_ids[:move.target_tokens]), extra_key=None, cache_salt=None,
            )
            pending = self.cache.ongoing_prefetch.get(move.operation_id)
            if pending is None:
                move.disposition = "deferred"
            else:
                move.prefetch = pending[3]

    def _demote_device(self, nodes):
        for node in reversed(nodes):
            if node.component_data[self.intents.full].value is None:
                continue
            if node not in self.cache.tree_core.evictable_device_leaves or self.preference(node, "L1"):
                return False
            self.cache._demote(node.id, {self.intents.full: 0})
        return True
