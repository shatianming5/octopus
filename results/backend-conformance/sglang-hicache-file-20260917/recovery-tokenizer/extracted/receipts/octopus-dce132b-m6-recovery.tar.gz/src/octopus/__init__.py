from octopus.state import (
    COMMIT_JSON_SCHEMA,
    Commit,
    Evidence,
    Fact,
    StateReducer,
    WorldState,
)
from octopus.backend import (
    BackendConfig, Checkpoint, GenerationConfig, GenerationEvent,
    InferenceBackend, BackendCapabilities, UnsupportedBackendFeature,
)
from octopus.cache_placement import CacheIdentity, CacheTier, KVLayout, PlacementRequest, PlacementResult
from octopus.admission import Calibration, Controller
from octopus.model_intent import (
    ModelIntent, model_intent_schema, parse_model_intents,
    checkpoint_choice_schema, parse_checkpoint_choice, choice_intent_payload,
    InlineIntentResult, InlineIntentStream, inline_intent_schema,
)
from octopus.context import (
    CompiledContext, ContextBudgetError, Inheritance, InheritanceMode, compile_context,
)
from octopus.branch_policy import BranchBudget, BranchCandidate, BranchPolicy, CompletionEvent, PolicyResult
from octopus.signals import (
    CheckpointIntent, ConsumerIntent, Event, GPUConsumer, ReadinessEstimate,
    Requirement, Signals,
)

__all__ = [
    "BranchBudget",
    "BranchCandidate",
    "BranchPolicy",
    "CompletionEvent",
    "PolicyResult",
    "CompiledContext",
    "ContextBudgetError",
    "Inheritance",
    "InheritanceMode",
    "compile_context",
    "BackendConfig",
    "CacheIdentity",
    "CacheTier",
    "KVLayout",
    "PlacementRequest",
    "PlacementResult",
    "HiCacheConfig",
    "SglangConfig",
    "SglangBackend",
    "GenerationConfig",
    "GenerationEvent",
    "InferenceBackend",
    "BackendCapabilities",
    "UnsupportedBackendFeature",
    "Calibration",
    "Controller",
    "ModelIntent",
    "model_intent_schema",
    "parse_model_intents",
    "checkpoint_choice_schema",
    "parse_checkpoint_choice",
    "choice_intent_payload",
    "InlineIntentResult",
    "InlineIntentStream",
    "inline_intent_schema",
    "Event",
    "GPUConsumer",
    "ReadinessEstimate",
    "Signals",
    "CheckpointIntent",
    "ConsumerIntent",
    "Requirement",
    "Branch",
    "BranchStatus",
    "BranchTask",
    "COMMIT_JSON_SCHEMA",
    "Checkpoint",
    "Commit",
    "Evidence",
    "Fact",
    "Octopus",
    "CaseSession",
    "StateReducer",
    "WorldState",
]


def __getattr__(name: str):
    if name in {"SglangConfig", "SglangBackend", "HiCacheConfig"}:
        from octopus import sglang_backend

        return getattr(sglang_backend, name)
    if name in {"Branch", "BranchStatus", "BranchTask", "Octopus", "CaseSession"}:
        from octopus import runtime

        return getattr(runtime, name)
    raise AttributeError(name)
