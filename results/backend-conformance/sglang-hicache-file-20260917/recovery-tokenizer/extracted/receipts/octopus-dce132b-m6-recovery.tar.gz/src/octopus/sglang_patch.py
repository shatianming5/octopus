"""Apply the bounded intent patch only to an owned, pinned source checkout."""
from __future__ import annotations

import argparse
import subprocess
from pathlib import Path

from octopus.sglang_worker import RELEASE_COMMIT


def apply_source_patch(source: Path, *, apply: bool = False, hicache: bool = False):
    source = source.resolve()
    def git(*args):
        return subprocess.check_output(["git", "-C", str(source), *args], text=True).strip()
    if Path(git("rev-parse", "--show-toplevel")).resolve() != source:
        raise ValueError("source must be the root of an owned SGLang git checkout, not an installed package")
    if git("rev-parse", "HEAD") != RELEASE_COMMIT:
        raise ValueError(f"source must be pinned to SGLang v0.5.19 commit {RELEASE_COMMIT}")
    patch = Path(__file__).with_name("sglang-hicache-v0519.patch" if hicache else "sglang-intent-v0519.patch")
    git("apply", "--check", str(patch))
    if apply:
        git("apply", str(patch))
    return {"source": str(source), "commit": RELEASE_COMMIT, "applied": apply,
            "patch": str(patch)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--hicache", action="store_true", help="apply the cumulative M5+M6 patch to a fresh owned checkout")
    args = parser.parse_args()
    print(apply_source_patch(args.source, apply=args.apply, hicache=args.hicache))


if __name__ == "__main__":
    main()
