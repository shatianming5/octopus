"""Owned-process SGLang v0.5.19 driver. Only this process imports the engine."""
from __future__ import annotations

import argparse
import asyncio
import importlib
import importlib.metadata
import json
import socket
import traceback


RELEASE = "0.5.19"
RELEASE_COMMIT = "0bcd822377da7b5718e674eaf9c870d349424dd1"


def create_engine(options):
    try:
        version = importlib.metadata.version("sglang")
    except importlib.metadata.PackageNotFoundError as exc:
        raise ImportError(
            "SGLang is not installed in the selected worker Python. "
            "Use an isolated `uv sync --extra sglang` environment."
        ) from exc
    if version != RELEASE:
        raise RuntimeError(f"requires sglang=={RELEASE}; selected worker has {version}")
    from sglang import Engine
    return Engine(**options)


async def serve(engine, connection, options, intent_owner=None, control_timeout=90):
    reader, writer = await asyncio.open_connection(sock=connection)
    tasks: dict[str, asyncio.Task] = {}
    controls: set[asyncio.Task] = set()
    manager = engine.tokenizer_manager
    native_lock = asyncio.Lock()
    native_failure = None

    async def native_control(payload):
        nonlocal native_failure
        if intent_owner is None:
            raise ValueError("native dynamic intent is not enabled")
        async def exchange():
            async with native_lock:
                if native_failure is not None:
                    raise RuntimeError(native_failure)
                response = await manager.octopus_intent({**payload, "owner": intent_owner})
                if native_failure is not None:
                    raise RuntimeError(native_failure)
                return response
        try:
            return await asyncio.wait_for(exchange(), timeout=control_timeout)
        except asyncio.TimeoutError as exc:
            # Released FanOutCommunicator has no request IDs. After a
            # cancelled waiter, a late reply must never satisfy a new call.
            native_failure = "native intent transport is unusable after a control timeout; close this backend"
            raise RuntimeError(native_failure) from exc

    async def send(message):
        data = json.dumps(message).encode()
        writer.write(len(data).to_bytes(4, "big") + data)
        await writer.drain()

    async def generate(message):
        rid = message["rid"]
        tokens, text = [], ""
        terminal = False
        try:
            if intent_owner is not None and message.get("checkpoint") is not None:
                await native_control({
                    "op": "bind", "checkpoint": message["checkpoint"],
                    "request_id": rid, "prompt_token_ids": message["input_ids"],
                    "consumer_id": message.get("consumer_id"),
                })
            stream = await engine.async_generate(
                input_ids=message["input_ids"], sampling_params=message["sampling"],
                stream=True, rid=rid,
            )
            async for output in stream:
                ids, chunk = output["output_ids"], output["text"]
                if manager.incremental_streaming_output:
                    tokens.extend(ids)
                    text += chunk
                else:
                    tokens, text = list(ids), chunk
                meta = output["meta_info"]
                reason = meta["finish_reason"]
                terminal = reason is not None
                kind = reason["type"] if terminal else None
                event = {
                    "type": "event", "rid": rid, "token_ids": tokens, "text": text,
                    "finished": terminal, "finish_reason": kind,
                    "error": reason.get("message") if kind == "abort" else None,
                    "cached_tokens": meta.get("cached_tokens"),
                }
                if not terminal:
                    await send(event)
            if not terminal:
                raise RuntimeError("SGLang stream ended without a terminal event")
            if intent_owner is not None:
                await native_control({"op": "finish", "request_id": rid,
                                      "failed": event["finish_reason"] == "abort"})
            await send(event)
        except Exception as exc:
            manager.abort_request(rid)
            error = f"{type(exc).__name__}: {exc}"
            if intent_owner is not None:
                try:
                    await native_control({"op": "finish", "request_id": rid, "failed": True})
                except Exception as cleanup_error:
                    error += f"; native cleanup failed: {cleanup_error}"
            await send({
                "type": "event", "rid": rid, "token_ids": tokens, "text": text,
                "finished": True, "finish_reason": "error",
                "error": error, "cached_tokens": None,
            })
        finally:
            tasks.pop(rid, None)

    async def abort(rid):
        task = tasks.get(rid)
        if task is None:
            return
        # Tokenization can yield before registration; abort_request is a no-op
        # in that interval. Do not cancel the generator and leak native work.
        while not task.done() and rid not in manager.rid_to_state:
            await asyncio.sleep(0.001)
        if not task.done():
            manager.abort_request(rid)
        await task

    async def control(message):
        try:
            op = message["op"]
            if op == "abort":
                await abort(message["rid"])
                value = None
            elif op == "intent":
                value = await native_control(message["payload"])
            elif op == "tokenize":
                value = manager.tokenizer.encode(message["text"], add_special_tokens=False)
            elif op == "decode":
                value = manager.tokenizer.decode(message["token_ids"])
            elif op == "render_chat":
                value = manager.tokenizer.apply_chat_template(
                    message["messages"], tools=message["tools"], tokenize=False,
                    add_generation_prompt=message["add_generation_prompt"],
                )
            elif op == "flush_cache":
                if tasks:
                    raise RuntimeError("cache reset requires no in-flight requests")
                value = (await manager.flush_cache(timeout_s=control_timeout)).success
            else:
                raise ValueError(f"unknown worker operation {op!r}")
            await send({"type": "reply", "id": message["id"], "value": value})
        except Exception as exc:
            await send({"type": "reply", "id": message["id"],
                        "error": f"{type(exc).__name__}: {exc}"})

    handshake = await native_control({"op": "hello"}) if intent_owner is not None else None
    await send({
        "type": "ready", "child_pids": engine.get_all_child_pids(),
        "engine_options": {key: getattr(engine.server_args, key) for key in options},
        "intent_handshake": handshake,
    })
    try:
        while True:
            try:
                size = int.from_bytes(await reader.readexactly(4), "big")
            except asyncio.IncompleteReadError:
                return
            message = json.loads(await reader.readexactly(size))
            if message["op"] == "submit":
                rid = message["rid"]
                tasks[rid] = asyncio.create_task(generate(message))
            elif message["op"] == "close":
                await asyncio.gather(*(abort(rid) for rid in tuple(tasks)))
                await asyncio.gather(*controls)
                if intent_owner is not None:
                    await native_control({"op": "close"})
                return
            else:
                task = asyncio.create_task(control(message))
                controls.add(task)
                task.add_done_callback(controls.discard)
    finally:
        await asyncio.gather(*(abort(rid) for rid in tuple(tasks)))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--fd", type=int, required=True)
    parser.add_argument("--factory", default="octopus.sglang_worker:create_engine")
    parser.add_argument("--intent-owner")
    parser.add_argument("--control-timeout", type=float, default=90)
    args = parser.parse_args()
    connection = socket.socket(fileno=args.fd)
    engine = None
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        def receive_exact(size):
            data = bytearray()
            while len(data) < size:
                part = connection.recv(size - len(data))
                if not part:
                    raise EOFError("owner disconnected before configuration")
                data.extend(part)
            return data
        size = int.from_bytes(receive_exact(4), "big")
        options = json.loads(receive_exact(size))
        module, name = args.factory.split(":")
        if args.intent_owner is not None and args.factory == "octopus.sglang_worker:create_engine":
            try:
                from sglang.srt.managers.io_struct import OCTOPUS_INTENT_PROTOCOL
            except ImportError as exc:
                raise ImportError(
                    "Dynamic intent requires the pinned source patch in an owned checkout; "
                    "use `python -m octopus.sglang_patch --source PATH --apply`, "
                    "then select that checkout via the worker PYTHONPATH. Do not patch a shared installation."
                ) from exc
            if OCTOPUS_INTENT_PROTOCOL != 1:
                raise RuntimeError("incompatible native intent source protocol")
            if options.get("enable_hierarchical_cache"):
                from sglang.srt.managers.io_struct import OCTOPUS_HICACHE_PROTOCOL
                if OCTOPUS_HICACHE_PROTOCOL != 1:
                    raise RuntimeError("native HiCache placement source extension is not loaded")
        engine = getattr(importlib.import_module(module), name)(options)
        if engine.loop is not loop:
            loop.close()
            loop = engine.loop
        loop.run_until_complete(serve(engine, connection, options, args.intent_owner, args.control_timeout))
    except Exception as exc:
        traceback.print_exc()
        data = json.dumps({"type": "fatal", "error": f"{type(exc).__name__}: {exc}"}).encode()
        connection.sendall(len(data).to_bytes(4, "big") + data)
        raise
    finally:
        if engine is not None:
            engine.shutdown()
        connection.close()
        loop.close()


if __name__ == "__main__":
    main()
