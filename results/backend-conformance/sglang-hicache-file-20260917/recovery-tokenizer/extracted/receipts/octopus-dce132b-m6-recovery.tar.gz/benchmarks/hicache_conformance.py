"""Opt-in HiCache placement proof; requires explicitly provisioned storage/GPU."""
from __future__ import annotations

import argparse
import json
import sys
import time
import uuid
from dataclasses import asdict, replace
from pathlib import Path

from octopus import CacheTier, Octopus, PlacementRequest
from octopus.sglang_backend import HiCacheConfig, SglangBackend, SglangConfig


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def wait_ready(adapter, receipt, deadline):
    while receipt.readiness == "pending":
        require(time.monotonic() < deadline, "native placement deadline exceeded")
        receipt = adapter.placement_status(receipt.operation_id)
        if receipt.readiness == "pending":
            time.sleep(.01)
    require(receipt.readiness == "ready", f"placement did not complete: {receipt}")
    require(not receipt.native_pending, "target claimed ready with its native transfers pending")
    return receipt


def verify_restore(receipt, *, from_l3):
    require(receipt.l1_ready_tokens == receipt.target_tokens, "restored L1 is incomplete")
    require(any(t["direction"] == "L2->L1" and t["actual_bytes"] > 0
                for t in receipt.transfers), "missing completed native L2-to-L1 transfer")
    if from_l3:
        require(receipt.l3_confirmed_tokens == receipt.target_tokens, "L3 read was not confirmed")
        require(any(t["direction"] == "L3->L2" and t["confirmed_tokens"] >= receipt.target_tokens
                    for t in receipt.transfers), "metadata/cache existence is not an L3 read")


def run(config, report, *, root_tokens, deadline):
    # Two independent owned engine instances, sequential on the approved GPU.
    with Octopus(backend=SglangBackend(config)) as owner:
        adapter = owner.backend
        report["writer_environment"] = adapter.environment_metadata()
        prompt = adapter.tokenize("Preserve this immutable context for a later task. " * root_tokens)[:root_tokens]
        require(len(prompt) == root_tokens, "root prompt is too short")
        root = owner.run_brain(prompt, max_new_tokens=8, ignore_eos=True)
        cp, identity = root.checkpoint, adapter.cache_identity
        stored = wait_ready(adapter, adapter.place_checkpoint(
            cp, PlacementRequest("retain", CacheTier.L3, identity),
        ), deadline)
        require(stored.l3_confirmed_tokens == stored.target_tokens, "native write did not confirm all L3 tokens")
        count = stored.target_tokens
        report["stored"] = asdict(stored)
        descriptor = adapter.export_checkpoint(cp)
        second_handle = adapter.import_checkpoint(descriptor)
        owner.declare_gpu_consumer(second_handle, consumer_id="shared-use")
        held = adapter.place_checkpoint(second_handle, PlacementRequest(
            "retain", CacheTier.L1, identity, count, "shared-use",
        ))
        require(held.readiness == "ready", "shared source was not resident")
        demote = adapter.place_checkpoint(cp, PlacementRequest("demote", CacheTier.L2, identity, count))
        require(demote.disposition == "deferred" and demote.l1_ready_tokens == count,
                "one owner demoted another owner's live demand")
        owner.cancel_gpu_consumer("shared-use")
        demoted = wait_ready(adapter, demote, deadline)
        require(demoted.l1_ready_tokens == 0 and demoted.l2_ready_tokens == count,
                "L1 was not evicted after completed L2 backup")
        report["demoted"] = asdict(demoted)
        restored = wait_ready(adapter, adapter.place_checkpoint(
            cp, PlacementRequest("prefetch", CacheTier.L1, identity, count),
        ), deadline)
        verify_restore(restored, from_l3=False)
        report["l2_restore"] = asdict(restored)
        mismatch = replace(identity, tokenizer_revision=identity.tokenizer_revision + "-wrong")
        try:
            adapter.place_checkpoint(cp, PlacementRequest("prefetch", CacheTier.L1, mismatch, count))
        except ValueError:
            report["identity_mismatch_rejected"] = True
        else:
            raise RuntimeError("tokenizer mismatch was admitted")
        owner.release(cp)
        owner.release(second_handle)
    report["writer_closed_before_reader"] = True
    with Octopus(backend=SglangBackend(config)) as owner:
        adapter = owner.backend
        report["reader_environment"] = adapter.environment_metadata()
        require(report["writer_environment"]["worker_pid"] != report["reader_environment"]["worker_pid"],
                "L3 test reused the writer engine instance")
        cp = adapter.import_checkpoint(descriptor)
        receipt = adapter.place_checkpoint(cp, PlacementRequest("prefetch", CacheTier.L1, adapter.cache_identity, count))
        require(receipt.l1_ready_tokens == 0, "reader already had the writer's device cache")
        restored = wait_ready(adapter, receipt, deadline)
        verify_restore(restored, from_l3=True)
        report["l3_independent_instance_restore"] = asdict(restored)
        owner.release(cp)
    if config.hicache.storage_backend == "file":
        fault_config = replace(config, hicache=replace(
            config.hicache, namespace=config.hicache.namespace + "-io-failure-" + uuid.uuid4().hex,
        ))
        with Octopus(backend=SglangBackend(fault_config)) as owner:
            adapter = owner.backend
            fault_identity = adapter.cache_identity
            source_suffix = f"_{identity.storage_namespace}_0_1.bin"
            target_suffix = f"_{fault_identity.storage_namespace}_0_1.bin"
            created = []
            try:
                for source in Path(config.hicache.storage_path).glob(f"*{source_suffix}"):
                    target = source.with_name(source.name.removesuffix(source_suffix) + target_suffix)
                    # New namespace only: never corrupt or overwrite shared source objects.
                    with target.open("xb"):
                        pass
                    created.append(target)
                require(created, "no source objects available for isolated file IO failure test")
                imported = adapter.import_checkpoint({**descriptor, "identity": fault_identity.to_dict()})
                failed = adapter.place_checkpoint(imported, PlacementRequest("prefetch", CacheTier.L1, fault_identity, count))
                while failed.readiness == "pending":
                    require(time.monotonic() < deadline, "IO failure receipt deadline exceeded")
                    failed = adapter.placement_status(failed.operation_id)
                require(failed.readiness == "failed" and "Short read" in (failed.error or ""),
                        "actual native short-read failure was not surfaced")
                require(failed.l1_ready_tokens == failed.l2_ready_tokens == 0,
                        "failed IO was advertised as restored residency")
                report["isolated_file_io_failure"] = asdict(failed)
                owner.release(imported)
            finally:
                for path in created:
                    path.unlink()
    else:
        report["io_failure_gate"] = "pending externally provisioned Mooncake failure injection; not a full B5 pass"
    report["completed_checks"] = [
        "identity_bound_native_l3_write", "shared_owner_demand_preserved",
        "consumer_cancel_unblocks_demotion", "completed_l2_before_l1_eviction",
        "actual_l2_restore", "independent_instance_reads_writer_l3", "identity_mismatch_rejected",
    ]
    if "isolated_file_io_failure" in report:
        report["completed_checks"].append("native_short_read_failure_without_residency")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model-path", required=True)
    parser.add_argument("--tokenizer-path", required=True)
    parser.add_argument("--worker-python", default=sys.executable)
    parser.add_argument("--storage-config", type=Path, required=True, help="HiCacheConfig JSON with provisioned file or Mooncake storage")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--max-model-len", type=int, default=4096)
    parser.add_argument("--max-total-tokens", type=int, default=4096)
    parser.add_argument("--root-tokens", type=int, default=512)
    parser.add_argument("--timeout-seconds", type=float, default=300)
    args = parser.parse_args(argv)
    storage = HiCacheConfig(**json.loads(args.storage_config.read_text()))
    config = SglangConfig(
        args.model_path, tokenizer_path=args.tokenizer_path, python_executable=args.worker_python,
        max_model_len=args.max_model_len, max_total_tokens=args.max_total_tokens,
        hicache=storage,
    )
    report = {
        "status": "failed", "scope": "native-hicache-placement-conformance",
        "storage_backend": storage.storage_backend,
        "topology_claim": "same-host independent engine instances; not cross-machine/distributed proof",
        "arguments": {**vars(args), "storage_config": str(args.storage_config), "output": str(args.output)},
        "quality_performance_claim": False, "actual_bytes_note": "L3 payload bytes are not measured network bytes",
    }
    try:
        run(config, report, root_tokens=args.root_tokens, deadline=time.monotonic()+args.timeout_seconds)
        report["status"] = "passed"
    except Exception as exc:
        report["error"] = f"{type(exc).__name__}: {exc}"
    finally:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(report, indent=2) + "\n")
    print(f"{args.output}: {report['status']}")
    return int(report["status"] != "passed")


if __name__ == "__main__":
    raise SystemExit(main())
